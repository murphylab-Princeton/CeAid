package com.example.swiperawesome

//TODO Should close all db or cursor?, when application is paused

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log
import android.widget.Toast

class ExpDatabaseHandler(myContext: Context) :
    SQLiteOpenHelper(myContext, DATABASE_NAME,null, DATABASE_VERSION) {
    var mContext = myContext
    private val lifeSpan = mContext.getString(R.string.LS_assay)
    private val lifeSpanXX = mContext.getString(R.string.LS_assayXX)
    private val reproductiveSpan = mContext.getString(R.string.RS_assay)
    private val progenyProduction  = mContext.getString(R.string.ProgenyAssay)
    private val choiceAssay = mContext.getString(R.string.ChoiceAssay)
    //----------------------------------------------------------------------------------------------
    override fun onCreate(db: SQLiteDatabase?) {
        //SQL - Structured Query Language
        var tmpText = "CREATE TABLE " + TABLE_NAME + "(" + KEY_ID + " INTEGER PRIMARY KEY," +
                KEY_EXP_NAME + " TEXT," + KEY_EXP_DATE + " TEXT," + KEY_EXP_TYPE + " TEXT," +
                KEY_EXP_Column_POINTER + " TEXT," + KEY_EXP_NUMBERING_STYLE_POINTER + " TEXT,"
        //---------------------------------------------------------
        for (xConditions in 1..TOTAL_NUM_CONDITIONS) {
            tmpText += "$CONDITION_NAME_X$xConditions TEXT,"
            tmpText += "$CONDITION_RANGE_X$xConditions TEXT,"
        }
        //---------------------------------------------------------
        tmpText += MyUtility.addTextToDatabaseHeader(NUMBER_OF_DAYS_LS, LS_DAY_X)
        tmpText += MyUtility.addTextToDatabaseHeader(NUMBER_OF_DAYS_LS, LS1_DAY_X)
        tmpText += MyUtility.addTextToDatabaseHeader(NUMBER_OF_DAYS_LS, LS2_DAY_X)
        tmpText += MyUtility.addTextToDatabaseHeader(NUMBER_OF_DAYS_LS, LS3_DAY_X)
        tmpText += MyUtility.addTextToDatabaseHeader(NUMBER_OF_DAYS_RS, RS_DAY_X)
        tmpText += MyUtility.addTextToDatabaseHeader(NUMBER_OF_DAYS_RS_COUNT, RS_COUNT_DAY_X)
        tmpText += MyUtility.addTextToDatabaseHeader(NUMBER_OF_DAYS_RS_COUNT, RS_UNHATCHED_DAY_X)
        tmpText += MyUtility.addTextToDatabaseHeader(NUMBER_OF_DAYS_RS_COUNT, RS_UNFERTILIZED_DAY_X)
        tmpText += MyUtility.addTextToDatabaseHeader(NUMBER_OF_Column_CHOICE_ASSAY, CHOICE_ASSAY_PREFERENCE_X)
        //---------------------------------------------------------
        val createMyAssayTable = tmpText.dropLast(1) + ");"
        db?.execSQL(createMyAssayTable)
    }
    //----------------------------------------------------------------------------------------------
    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db?.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
        onCreate(db)
    }
    // CRUD - Create, Read, Update, Delete
    //----------------------------------------------------------------------------------------------
    fun createExpInfo (myExp: Experiment) {
        val db:SQLiteDatabase = writableDatabase
        var myValues = ContentValues()
        myValues.put(KEY_EXP_NAME, myExp.name)
        myValues.put(KEY_EXP_DATE, myExp.startDate)
        myValues.put(KEY_EXP_Column_POINTER, myExp.dayPointer)
        myValues.put(KEY_EXP_NUMBERING_STYLE_POINTER, myExp.numberingStyle)
        myValues.put(KEY_EXP_TYPE, myExp.type)
        //----------------------------------------------
        for (ii in 1..myExp.testConditionName.size) {
            myValues.put(CONDITION_NAME_X+ii, myExp.testConditionName[ii-1])
            myValues.put(CONDITION_RANGE_X+ii, myExp.testConditionRange[ii-1])
        }
        //----------------------------------------------
        myValues = MyUtility.puttingNoInputValueInByteArray(myValues, myExp, NUMBER_OF_DAYS_LS, LS_DAY_X)
        myValues = MyUtility.puttingNoInputValueInByteArray(myValues, myExp, NUMBER_OF_DAYS_LS, LS1_DAY_X)
        myValues = MyUtility.puttingNoInputValueInByteArray(myValues, myExp, NUMBER_OF_DAYS_LS, LS2_DAY_X)
        myValues = MyUtility.puttingNoInputValueInByteArray(myValues, myExp, NUMBER_OF_DAYS_LS, LS3_DAY_X)
        myValues = MyUtility.puttingNoInputValueInByteArray(myValues, myExp, NUMBER_OF_DAYS_RS, RS_DAY_X)
        myValues = MyUtility.puttingNoInputValueInByteArray(myValues, myExp, NUMBER_OF_DAYS_RS_COUNT, RS_COUNT_DAY_X)
        myValues = MyUtility.puttingNoInputValueInByteArray(myValues, myExp, NUMBER_OF_DAYS_RS_COUNT, RS_UNHATCHED_DAY_X)
        myValues = MyUtility.puttingNoInputValueInByteArray(myValues, myExp, NUMBER_OF_DAYS_RS_COUNT, RS_UNFERTILIZED_DAY_X)
        myValues = MyUtility.puttingNoInputValueInByteArray(myValues, myExp, NUMBER_OF_Column_CHOICE_ASSAY, CHOICE_ASSAY_PREFERENCE_X)
        //---------------------------------------------
        db.insert(TABLE_NAME, null, myValues)
        db.close()
        Toast.makeText(mContext,"Saved to Database",Toast.LENGTH_SHORT).show()
    }
    //----------------------------------------------------------------------------------------------
    fun updateOneCellAtOneColumn(expNum: Int, columnNum:Int, chamberNum:Int, WantToLoadThisValue:Byte) {
        val dailyReportByteArray = readByteArrayAtOneColumn(expNum, columnNum)
        val db:SQLiteDatabase = writableDatabase
        val myValues = ContentValues()
        dailyReportByteArray!![chamberNum-1] = WantToLoadThisValue
        var columnTitle:String? = null
        val expClassInfo = readOneExpInfo(expNum)
        when (expClassInfo.type) {
            lifeSpanXX -> {columnTitle = LS_DAY_X}
            reproductiveSpan -> {columnTitle = RS_DAY_X}
            choiceAssay -> {columnTitle = CHOICE_ASSAY_PREFERENCE_X}
        }
        myValues.put("$columnTitle$columnNum", dailyReportByteArray)
        db.update(TABLE_NAME, myValues, "$KEY_ID=?", arrayOf(expNum.toString()))
        db.close()
    }
    //----------------------------------------------------------------------------------------------
    fun updateByteArrayAtOneColumn(expNum: Int, ColumnNum:Int, WantToLoadThisArray:ByteArray) {
        val db:SQLiteDatabase = writableDatabase
        val myValues = ContentValues()
        var columnTitle:String? = null
        val expClassInfo = readOneExpInfo(expNum)
        when (expClassInfo.type) {
            lifeSpanXX -> {columnTitle = LS_DAY_X}
            reproductiveSpan -> {columnTitle = RS_DAY_X}
            choiceAssay -> {columnTitle = CHOICE_ASSAY_PREFERENCE_X}
        }
        myValues.put("$columnTitle$ColumnNum", WantToLoadThisArray)
        db.update(TABLE_NAME, myValues, "$KEY_ID=?", arrayOf(expNum.toString()))
        db.close()
    }
    //----------------------------------------------------------------------------------------------
    fun readByteArrayAtOneColumn(expNum:Int, columnNum:Int) : ByteArray? {
        val db:SQLiteDatabase = readableDatabase
        var thisByteArray:ByteArray? = null
        var myCursor: Cursor? = null

        var dayX:String? = null
        val expClassInfo = readOneExpInfo(expNum)
        when (expClassInfo.type) {
            lifeSpan -> {dayX= LS1_DAY_X}
            lifeSpanXX -> {dayX= LS_DAY_X}
            reproductiveSpan -> {dayX = RS_DAY_X}
            progenyProduction -> {dayX = RS_COUNT_DAY_X}
            choiceAssay -> {dayX = CHOICE_ASSAY_PREFERENCE_X}
        }
        myCursor = db.query(TABLE_NAME, arrayOf(KEY_ID, "$dayX$columnNum"), "$KEY_ID=?", arrayOf(expNum.toString()), null, null, null, null)
        myCursor.moveToFirst()
        thisByteArray= myCursor.getBlob(myCursor.getColumnIndex("$dayX$columnNum"))
        myCursor!!.close()
        db.close()
        return thisByteArray
    }
    //----------------------------------------------------------------------------------------------
    fun updateOneCellAtColumns(expNum: Int, columnNum:Int, chamberNum:Int, WantToLoadThisValue:Byte, ArrayListID:Int) {
        val arrayListOfByteArray = readByteArrayAtColumns(expNum, columnNum)
        val db:SQLiteDatabase = writableDatabase
        val myValues = ContentValues()
        arrayListOfByteArray!![ArrayListID-1][chamberNum-1] = WantToLoadThisValue
        var myKeyArray:Array<String>? = null
        val expClassInfo = readOneExpInfo(expNum)
        when (expClassInfo.type) {
            lifeSpan -> {myKeyArray = arrayOf(KEY_ID, "$LS1_DAY_X$columnNum","$LS2_DAY_X$columnNum","$LS3_DAY_X$columnNum")}
            progenyProduction -> {myKeyArray = arrayOf(KEY_ID, "$RS_COUNT_DAY_X$columnNum","$RS_UNHATCHED_DAY_X$columnNum","$RS_UNFERTILIZED_DAY_X$columnNum")}
        }
        for(ii in 1 until myKeyArray!!.size) {
            myValues.put(myKeyArray[ii], arrayListOfByteArray[ii-1])
        }
        db.update(TABLE_NAME, myValues, "$KEY_ID=?", arrayOf(expNum.toString()))
        db.close()
    }
    //----------------------------------------------------------------------------------------------
    fun updateByteArrayAtColumns(expNum: Int, columnNum:Int, WantToLoadThisArray:ArrayList<ByteArray>) {
        val db:SQLiteDatabase = writableDatabase
        val myValues = ContentValues()
        var myKeyArray:Array<String>? = null
        val expClassInfo = readOneExpInfo(expNum)
        when (expClassInfo.type) {
            lifeSpan -> {myKeyArray = arrayOf(KEY_ID, "$LS1_DAY_X$columnNum","$LS2_DAY_X$columnNum","$LS3_DAY_X$columnNum")}
            progenyProduction -> {myKeyArray = arrayOf(KEY_ID, "$RS_COUNT_DAY_X$columnNum","$RS_UNHATCHED_DAY_X$columnNum","$RS_UNFERTILIZED_DAY_X$columnNum")}
        }
        for(ii in 1 until myKeyArray!!.size) {
            myValues.put(myKeyArray[ii], WantToLoadThisArray[ii-1])
        }
        db.update(TABLE_NAME, myValues, "$KEY_ID=?", arrayOf(expNum.toString()))
        db.close()
    }
    //----------------------------------------------------------------------------------------------
    fun readByteArrayAtColumns(expNum:Int, columnNum:Int) : ArrayList<ByteArray>? {
        val db:SQLiteDatabase = readableDatabase
        val arrayListOfByteArray= ArrayList<ByteArray>()
        var myCursor: Cursor? = null
        var myKeyArray:Array<String>? = null
        val expClassInfo = readOneExpInfo(expNum)
        when (expClassInfo.type) {
            lifeSpan -> {myKeyArray = arrayOf(KEY_ID, "$LS1_DAY_X$columnNum","$LS2_DAY_X$columnNum","$LS3_DAY_X$columnNum")}
            progenyProduction -> {myKeyArray = arrayOf(KEY_ID, "$RS_COUNT_DAY_X$columnNum","$RS_UNHATCHED_DAY_X$columnNum","$RS_UNFERTILIZED_DAY_X$columnNum")}
        }
        myCursor = db.query(TABLE_NAME,myKeyArray,"$KEY_ID=?", arrayOf(expNum.toString()), null, null, null, null)
        myCursor.moveToFirst()
        for(ii in 1 until myKeyArray!!.size) {arrayListOfByteArray.add(myCursor.getBlob(myCursor.getColumnIndex(myKeyArray[ii])))}
        myCursor!!.close()
        db.close()
        return arrayListOfByteArray
    }
    //----------------------------------------------------------------------------------------------
    fun readOneExpInfo(myID:Int): Experiment {
        val db: SQLiteDatabase = readableDatabase
        var myCursor:Cursor? = null
        val myKeyList = arrayListOf(KEY_ID, KEY_EXP_NAME, KEY_EXP_TYPE, KEY_EXP_DATE, KEY_EXP_Column_POINTER, KEY_EXP_NUMBERING_STYLE_POINTER)
        for (xConditions in 1..TOTAL_NUM_CONDITIONS) {
            myKeyList.add(CONDITION_NAME_X+xConditions)
            myKeyList.add(CONDITION_RANGE_X+xConditions)
        }
        val myKeyArray = arrayOfNulls<String>(myKeyList.size)
        myKeyList.toArray(myKeyArray)
        myCursor = db.query(TABLE_NAME, myKeyArray, "$KEY_ID=?", arrayOf(myID.toString()), null, null, null, null)

        myCursor.moveToFirst()
        val currentExp = Experiment()
        currentExp.id = myCursor.getInt(myCursor.getColumnIndex(KEY_ID))
        currentExp.name = myCursor.getString(myCursor.getColumnIndex(KEY_EXP_NAME))
        currentExp.type = myCursor.getString(myCursor.getColumnIndex(KEY_EXP_TYPE))
        currentExp.startDate = myCursor.getString(myCursor.getColumnIndex(KEY_EXP_DATE))
        currentExp.dayPointer = myCursor.getInt(myCursor.getColumnIndex(KEY_EXP_Column_POINTER))
        currentExp.numberingStyle = myCursor.getInt(myCursor.getColumnIndex(KEY_EXP_NUMBERING_STYLE_POINTER))

        for (ss in 1..TOTAL_NUM_CONDITIONS) {
            if(myCursor.getString(myCursor.getColumnIndex(CONDITION_NAME_X+ss))!=null) {
                currentExp.testConditionName.add(ss-1, myCursor.getString(myCursor.getColumnIndex(CONDITION_NAME_X+ss)))
                currentExp.testConditionRange.add(ss-1, myCursor.getInt(myCursor.getColumnIndex(CONDITION_RANGE_X+ss)))
            }
        }
        myCursor.close()
        return currentExp
    }
    //----------------------------------------------------------------------------------------------
    fun readAllExpInfo(): ArrayList<Experiment> {
        val db: SQLiteDatabase = readableDatabase
        var cursor:Cursor? = null
        val list: ArrayList<Experiment> = ArrayList()
        val selectAll = "SELECT * FROM $TABLE_NAME"
        cursor = db.rawQuery(selectAll, null)
        //------------------------------------------------------------ loop through our experiments
        if (cursor.moveToFirst()) {
            do {
                val myExp = Experiment()
                myExp.id = cursor.getInt(cursor.getColumnIndex(KEY_ID))
                myExp.name = cursor.getString(cursor.getColumnIndex(KEY_EXP_NAME))
                myExp.type = cursor.getString(cursor.getColumnIndex(KEY_EXP_TYPE))
                myExp.startDate = cursor.getString(cursor.getColumnIndex(KEY_EXP_DATE))
                myExp.dayPointer = cursor.getInt(cursor.getColumnIndex(KEY_EXP_Column_POINTER))
                myExp.numberingStyle = cursor.getInt(cursor.getColumnIndex(KEY_EXP_NUMBERING_STYLE_POINTER))

                for (ss in 1..TOTAL_NUM_CONDITIONS) {
                    if (cursor.getString(cursor.getColumnIndex(CONDITION_NAME_X+ss))!=null) {
                        myExp.testConditionName.add(ss-1, cursor.getString(cursor.getColumnIndex(CONDITION_NAME_X+ss)))
                        myExp.testConditionRange.add(ss-1, cursor.getInt(cursor.getColumnIndex(CONDITION_RANGE_X+ss)))
                    }
                }
                list.add(myExp)
            } while (cursor.moveToNext())
        }
        cursor.close()
        return list
    }
    //----------------------------------------------------------------------------------------------
    fun updateExpInfo(updatedExp: Experiment) {
        val db:SQLiteDatabase = writableDatabase
        val myUpdatedValues = ContentValues()
        myUpdatedValues.put(KEY_EXP_NAME,updatedExp.name)
        myUpdatedValues.put(KEY_EXP_DATE,updatedExp.startDate)
        myUpdatedValues.put(KEY_EXP_TYPE, updatedExp.type)
        for (ii in 1..updatedExp.testConditionName.size) {
            myUpdatedValues.put(CONDITION_NAME_X+ii, updatedExp.testConditionName[ii-1])
            myUpdatedValues.put(CONDITION_RANGE_X+ii, updatedExp.testConditionRange[ii-1])
        }
        db.update(TABLE_NAME, myUpdatedValues, "$KEY_ID=?", arrayOf(updatedExp.id.toString()))
        db.close()
    }
    //----------------------------------------------------------------------------------------------
    fun readColumnPointerForEachExperiment(expNum:Int) : Int {
        val db:SQLiteDatabase = readableDatabase
        val myCursor: Cursor = db.query(TABLE_NAME, arrayOf(KEY_ID, KEY_EXP_Column_POINTER), "$KEY_ID=?", arrayOf(expNum.toString()), null, null, null, null)
        myCursor.moveToFirst()
        val thisExpColumnPointer = myCursor.getInt(myCursor.getColumnIndex(KEY_EXP_Column_POINTER))
        myCursor.close()
        db.close()
        return thisExpColumnPointer
    }
    //----------------------------------------------------------------------------------------------
    fun updateDayPointerForEachExperiment(expNum:Int, myDayPointer: Int) {
        val db:SQLiteDatabase = writableDatabase
        val myUpdatedValues = ContentValues()
        myUpdatedValues.put(KEY_EXP_Column_POINTER,myDayPointer)
        db.update(TABLE_NAME, myUpdatedValues, "$KEY_ID=?", arrayOf(expNum.toString()))
        db.close()
    }
    //----------------------------------------------------------------------------------------------
    fun readNumberingStylePointerForEachExperiment(expNum:Int) : Int {
        val db:SQLiteDatabase = readableDatabase
        val myCursor: Cursor = db.query(TABLE_NAME, arrayOf(KEY_ID, KEY_EXP_NUMBERING_STYLE_POINTER), "$KEY_ID=?", arrayOf(expNum.toString()), null, null, null, null)
        myCursor.moveToFirst()
        val thisExpColumnPointer = myCursor.getInt(myCursor.getColumnIndex(KEY_EXP_NUMBERING_STYLE_POINTER))
        myCursor.close()
        db.close()
        return thisExpColumnPointer
    }
    //----------------------------------------------------------------------------------------------
    fun updateNumberingStylePointerForEachExperiment(expNum:Int, myNumberingStyle: Int) {
        val db:SQLiteDatabase = writableDatabase
        val myUpdatedValues = ContentValues()
        myUpdatedValues.put(KEY_EXP_NUMBERING_STYLE_POINTER,myNumberingStyle)
        db.update(TABLE_NAME, myUpdatedValues, "$KEY_ID=?", arrayOf(expNum.toString()))
        db.close()
    }
    //----------------------------------------------------------------------------------------------
    fun deleteExpInfo (selectedID:Int) {
        val db:SQLiteDatabase = writableDatabase
        db.delete(TABLE_NAME, "$KEY_ID=?", arrayOf(selectedID.toString()))
        db.close()
    }
    //----------------------------------------------------------------------------------------------
    fun getExpCount ():Int{
        val myCountQuery = "SELECT * FROM $TABLE_NAME"
        val db:SQLiteDatabase = readableDatabase
        val myCursor:Cursor = db.rawQuery(myCountQuery,null)
        val expCount = myCursor.count
        myCursor.close()
        return expCount
    }
    //----------------------------------------------------------------------------------------------
}