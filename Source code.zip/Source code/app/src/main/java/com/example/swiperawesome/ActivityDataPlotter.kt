package com.example.swiperawesome

import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.interfaces.datasets.IBarDataSet
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet
import kotlinx.android.synthetic.main.activity_data_plotter.*


class ActivityDataPlotter : AppCompatActivity() {

    var whichDataSetToShow:Int?=null
    var maxNumOfDataSetToShow:Int?=null
    var mNumGroupToCandleStick:Int?=null
    var myToasterObject:Toast? = null
    var mConditionArray:ArrayList<Condition>? = null
    var set1:CandleDataSet? = null
    var data:CandleData?=null


    @RequiresApi(Build.VERSION_CODES.M)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_data_plotter)

        val myExpID = intent.extras?.get("KeyForExpID") as Int
        val myExpDataHandler = ExpDatabaseHandler(this)
        val expClassInfo = myExpDataHandler.readOneExpInfo(myExpID)
        val myToProcessData = DataProcessor()
        //------------------------------------------------------------------------------------------
        mConditionArray = myToProcessData.readAndCreateConditionClassInfo (myExpID, this)
        XaxisLabel.visibility = View.GONE
        YaxisLabel.visibility = View.GONE
        myLineChart.visibility = View.GONE
        myCandleStickChart!!.visibility = View.GONE
        myGroupedBarChart.visibility=View.GONE
        //------------------------------------------------------------------------------------------
        when (expClassInfo.type) {
            getString(R.string.LS_assay) -> {
                for (ij in 1..mConditionArray!!.size) {
                    mConditionArray!![ij-1] = myToProcessData.lifeSpanCalculator(mConditionArray!![ij-1])
                    mConditionArray!![ij-1] = myToProcessData.survivalAxisCalculator(mConditionArray!![ij-1])
                }
            }
            getString(R.string.LS_assayXX)->{
                for (ij in 1..mConditionArray!!.size) {
                    mConditionArray!![ij-1] = myToProcessData.lifeSpanCalculatorXX(mConditionArray!![ij-1])
                    mConditionArray!![ij-1] = myToProcessData.aliveDeadCensorCalculator(mConditionArray!![ij-1])
                    mConditionArray!![ij-1] = myToProcessData.survivalAxisCalculator(mConditionArray!![ij-1])
                }
            }
            getString(R.string.RS_assay) -> {
                for (ij in 1..mConditionArray!!.size) {
                    mConditionArray!![ij-1] = myToProcessData.reproductiveSpanCalculator(mConditionArray!![ij-1])
                    mConditionArray!![ij-1] = myToProcessData.aliveDeadCensorCalculator(mConditionArray!![ij-1])
                    mConditionArray!![ij-1] = myToProcessData.survivalAxisCalculator(mConditionArray!![ij-1])
                }
            }
            getString(R.string.ProgenyAssay) -> {
                for (ij in 1..mConditionArray!!.size) {
                    mConditionArray!![ij-1] = myToProcessData.broodSizeCalculator(mConditionArray!![ij-1])
                }
            }
            getString(R.string.ChoiceAssay) -> {
                for (kk in 1..mConditionArray!!.size) {
                    mConditionArray!![kk-1] = myToProcessData.choiceAssayCalculator(mConditionArray!![kk-1])
                    mConditionArray!![kk-1] = myToProcessData.candleStickCalculator(mConditionArray!![kk-1])
                }
            }
        }
        //-------------------------------------------------- swipe left/right for another graph init
        when (expClassInfo.type) {
            getString(R.string.ChoiceAssay) -> {
                whichDataSetToShow = 1
                val myNameStringArray = expClassInfo.name!!.split(",", ignoreCase = true, limit = 0)
                mNumGroupToCandleStick = if (myNameStringArray.size>1) myNameStringArray.last().toInt() else 2
                maxNumOfDataSetToShow = mConditionArray!!.size/mNumGroupToCandleStick!!
            }
            getString(R.string.ProgenyAssay) -> {
                whichDataSetToShow = 1
                maxNumOfDataSetToShow = 3
            }
        }
        //------------------------------------------------------------------------------------------
        when(expClassInfo.type) {
            getString(R.string.LS_assayXX), getString(R.string.LS_assay), getString(R.string.RS_assay) -> {
                XaxisLabel.visibility = View.VISIBLE
                YaxisLabel.visibility = View.VISIBLE
                myLineChart.visibility = View.VISIBLE
                val myLines = ArrayList<LineDataSet>()
                for (jj in 1..mConditionArray!!.size) {
                    val entries = ArrayList<Entry>()
                    for (sDay in 1..mConditionArray!![jj-1].survivalXAxis!!.size) {
                        entries.add(Entry(mConditionArray!![jj-1].survivalXAxis!![sDay-1]!!,mConditionArray!![jj-1].survivalYAxis!![sDay-1]!!))

                        if (sDay<mConditionArray!![jj-1].survivalXAxis!!.size) {
                            if(mConditionArray!![jj-1].survivalYAxis!![sDay-1]!=mConditionArray!![jj-1].survivalYAxis!![sDay]) {
                                entries.add(Entry(mConditionArray!![jj-1].survivalXAxis!![sDay]!!,mConditionArray!![jj-1].survivalYAxis!![sDay-1]!!))
                            }
                        }
                    }
                    myLines.add(LineDataSet(entries, mConditionArray!![jj - 1].name))
                }
                var maximumOfAxis = 0f
                for (jj in 1..mConditionArray!!.size) {
                    if (maximumOfAxis<mConditionArray!![jj-1].survivalXAxis!!.last()!!+1f) {
                        maximumOfAxis = mConditionArray!![jj-1].survivalXAxis!!.last()!!+1f
                    }
                }
                myLineChart.data = LineData(myLines as List<ILineDataSet>?)
                PlotSpecs.specsForSurvivalPlot(mConditionArray!!, myLines, myLineChart, applicationContext, XaxisLabel, YaxisLabel, maximumOfAxis)
            }
            //-------------------------------------------------
            getString(R.string.ChoiceAssay) -> {
                YaxisLabel.visibility = View.VISIBLE
                myCandleStickChart!!.visibility = View.VISIBLE
                plotThisChoiceAssay()
            }
            //-------------------------------------------------
            getString(R.string.ProgenyAssay) -> {
                YaxisLabel.visibility = View.VISIBLE
                myGroupedBarChart.visibility=View.VISIBLE
                groupedBarChartThisProgenyAssay()
            }
            //-------------------------------------------------
        }
        //------------------------------------------------------------------------------------------
        myViewGestureControlID.setOnTouchListener(object : OnSwipeTouchListener(this@ActivityDataPlotter) {
            //---------------------------
            override fun onSwipeDown() {}
            override fun onSwipeUp() {}
            override fun onSwipeLeft() {
                if (whichDataSetToShow!! <maxNumOfDataSetToShow!!){
                    whichDataSetToShow=whichDataSetToShow?.plus(1)
                    when(expClassInfo.type) {
                        getString(R.string.ChoiceAssay)-> {plotThisChoiceAssay()}
                        getString(R.string.ProgenyAssay)-> {groupedBarChartThisProgenyAssay()}
                    }
                } else toastMe("DataSetNum$whichDataSetToShow")
            }
            override fun onSwipeRight() {

                if(whichDataSetToShow!!>1) {
                    whichDataSetToShow=whichDataSetToShow?.minus(1)
                    when(expClassInfo.type) {
                        getString(R.string.ChoiceAssay)-> {plotThisChoiceAssay()}
                        getString(R.string.ProgenyAssay)-> {groupedBarChartThisProgenyAssay()}
                    }
                } else toastMe("DataSetNum$whichDataSetToShow")
            }
            override fun onDoubleTouch() {}
            override fun onLongTouch() {}
            override fun onSingleTouch() {}
            //-----------------------------
        })
        //------------------------------------------------------------------------------------------
    }
    //----------------------------------------------------------------------------------------------
    @RequiresApi(Build.VERSION_CODES.M)
    fun plotThisChoiceAssay() {

        val yValuesCandleStick = ArrayList<CandleEntry>()
        var myLabelString=""
        for (kk in 1..mConditionArray!!.size) {
            yValuesCandleStick.add(CandleEntry((kk-1).toFloat(), mConditionArray!![kk-1].candleStickErrorH!!, mConditionArray!![kk-1].candleStickErrorL!!,
                mConditionArray!![kk-1].candleStickHighY!!,mConditionArray!![kk-1].candleStickLowY!!))
            myLabelString =myLabelString+","+mConditionArray!![kk-1].name!!.split(",", ignoreCase = true, limit = 0)[0]
        }
        //mNumGroupToCandleStick
        //whichDataSetToShow
        set1 = CandleDataSet(yValuesCandleStick, myLabelString.drop(1))
        data = CandleData(set1)
        myCandleStickChart!!.data = data
        PlotSpecs.specsForChoiceAssay(this, set1!!, data!!, myCandleStickChart!!,  YaxisLabel, whichDataSetToShow!!, mNumGroupToCandleStick!!)
        toastMe("DataSetNum$whichDataSetToShow")
    }
    //----------------------------------------------------------------------------------------------
    fun toastMe(useThis:String) {myToasterObject?.cancel()
        myToasterObject = Toast.makeText(this@ActivityDataPlotter, useThis, Toast.LENGTH_SHORT)
        myToasterObject?.show()
    }
    //----------------------------------------------------------------------------------------------
    @RequiresApi(Build.VERSION_CODES.M)
    fun groupedBarChartThisProgenyAssay() {

        val myColorList = arrayOf(R.color.Red, R.color.Green, R.color.Blue, R.color.Yellow, R.color.Magenta, R.color.Gray, R.color.Orange, R.color.Violet, R.color.Violet, R.color.Aqua, R.color.Bisque, R.color.Crimson)
        val myBarsForConditions = ArrayList<BarDataSet>()
        val myXAxisString = ArrayList<String>()
        var maxYAxisValue = 0f
        var mDayCounts = 0

        for (jj in 1..mConditionArray!!.size) {
            for (dayNum in 1..mConditionArray!![jj - 1].numColumnTotal!!) {
                when(whichDataSetToShow){
                    1-> {if (mConditionArray!![jj-1].broodSizePerDay!![dayNum-1]>0 && mDayCounts<dayNum){mDayCounts=dayNum;myXAxisString.add("D$dayNum")}}
                    2-> {if (mConditionArray!![jj-1].unhatchedEggs!![dayNum-1]>0 && mDayCounts<dayNum){mDayCounts=dayNum;myXAxisString.add("D$dayNum")}}
                    3-> {if (mConditionArray!![jj-1].unfertilizedOocytes!![dayNum-1]>0 && mDayCounts<dayNum){mDayCounts=dayNum;myXAxisString.add("D$dayNum")}}
                }
            }
        }
        for (jj in 1..mConditionArray!!.size) {
            val myYAxisValues = ArrayList<BarEntry>()
            for (dayNum in 1..mDayCounts) {
                when(whichDataSetToShow){
                    1-> {   myYAxisValues.add(BarEntry(dayNum.toFloat(),mConditionArray!![jj - 1].broodSizePerDay!![dayNum-1]))
                            if (maxYAxisValue<mConditionArray!![jj-1].broodSizePerDay!![dayNum-1]) {maxYAxisValue = mConditionArray!![jj-1].broodSizePerDay!![dayNum-1]}}
                    2-> {   myYAxisValues.add(BarEntry(dayNum.toFloat(),mConditionArray!![jj - 1].unhatchedEggs!![dayNum-1]))
                            if (maxYAxisValue<mConditionArray!![jj-1].unhatchedEggs!![dayNum-1]) {maxYAxisValue = mConditionArray!![jj-1].unhatchedEggs!![dayNum-1]}}
                    3-> {   myYAxisValues.add(BarEntry(dayNum.toFloat(),mConditionArray!![jj - 1].unfertilizedOocytes!![dayNum-1]))
                            if (maxYAxisValue<mConditionArray!![jj-1].unfertilizedOocytes!![dayNum-1]) {maxYAxisValue = mConditionArray!![jj-1].unfertilizedOocytes!![dayNum-1]}}
                }
            }
            myBarsForConditions.add(BarDataSet(myYAxisValues, mConditionArray!![jj-1].name))
            myBarsForConditions[jj-1].color = this.getColor(myColorList[jj-1])
        }
        //Log.d("xAxisString", myXAxisString.toString())
        //Log.d("maxYaxisValue", maxYAxisValue.toString())
        val myFinalDataList = BarData(myBarsForConditions as List<IBarDataSet>?)
        myGroupedBarChart.data = myFinalDataList
        PlotSpecs.specsForProgenyAssay(this,myGroupedBarChart, myXAxisString, maxYAxisValue, mConditionArray!!.size)
        //----------------------------------------------
        when (whichDataSetToShow) {
             1 -> {YaxisLabel.text = "Progeny Number"}
             2 -> {YaxisLabel.text = "Unhatched eggs"}
             3 -> {YaxisLabel.text = "Unfertilized Oocytes"}
        }
        toastMe("DataSetNum$whichDataSetToShow")
    }
    //----------------------------------------------------------------------------------------------
}

