package com.example.swiperawesome

import android.content.Intent
import android.graphics.Paint
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.TextToSpeech.OnInitListener
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.RequiresApi
import kotlinx.android.synthetic.main.activity_life_span_feeder_x_x.*
import java.util.*

class ActivityLifeSpanFeederXX : AppCompatActivity() {

    //----------------------------------------------------------------------------------------------
    private var mTts: TextToSpeech? = null
    var myExpClass:Experiment? = null
    var thisExpID:Int? = null
    var columnID:Int? = null
    var dayToCheck:Int? = null
    var chamberID:Int? = null
    var myTestDataHandler:ExpDatabaseHandler? = null
    private var totNumChambers:Int? = null
    private var foundExperimentDayNum:Int? = null
    var myToasterObject: Toast? = null
    private var myShapeOfChambersArray:Array<Int?>? = null
    private var textArrayOfConditionName:Array<String?>? = null
    //----------------------------------------------------------------------------------------------
    @RequiresApi(Build.VERSION_CODES.M)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_life_span_feeder_x_x)
        //-----------------------------------------
        val checkIntent = Intent()
        checkIntent.action = TextToSpeech.Engine.ACTION_CHECK_TTS_DATA
        startActivityForResult(checkIntent, MY_DATA_CHECK_CODE)
        //---------------------------------------
        this.thisExpID = intent.extras?.get("KeyForExpID") as Int
        this.chamberID = intent.extras?.get("KeyForChamberID") as Int
        myTestDataHandler = ExpDatabaseHandler(this)
        myExpClass = myTestDataHandler!!.readOneExpInfo(thisExpID!!)
        this.columnID = myExpClass!!.dayPointer
        this.totNumChambers = myExpClass!!.testConditionRange.last().toInt()
        this.foundExperimentDayNum = MyUtility.findNumberOfColumns(this, myExpClass!!.type!!)
        myShapeOfChambersArray = MyUtility.shapeOfChamberIdentifier(myExpClass!!)
        textArrayOfConditionName = MyUtility.textOfConditionIdentifier(myExpClass!!)
        initialStatusDetermination()
        makePreWormNoInput()
        //---------------------------------------
        viewForDataFeederLSXX.setOnTouchListener(object : OnSwipeTouchListener(this@ActivityLifeSpanFeederXX) {
            //---------------------------------------------
            override fun onSwipeDown() {userInputDead()}
            override fun onSwipeUp() {userInputAlive()}
            override fun onSwipeLeft() {goToNextColumn()}
            override fun onSwipeRight() {goToPreviousColumn()}
            override fun onDoubleTouch() {gotoNextChamber()}
            override fun onLongTouch() {gotoPreviousChamber()}
            override fun onSingleTouch() {userInputCensored("Censored", CensorRed) }
            //---------------------------------------------
        })
        //-------------------------------------------------------------------
        censoredBaggedButtonLSXX.setOnClickListener { userInputCensored("Bagged", CensorBagged) }
        censorDriedButtonLSXX.setOnClickListener { userInputCensored("Dried", CensorDried) }
        censorExplodedButtonLSXX.setOnClickListener { userInputCensored("Exploded", CensorExploded) }
        censorLostButtonLSXX.setOnClickListener { userInputCensored("Lost", CensorLost) }
        censorUnidentifiedButtonLSXX.setOnClickListener { userInputCensored("Unidentified", CensorUnidentified) }
        //-------------------------------------------------------------------
    }
    //----------------------------------------------------------------------------------------------
    @RequiresApi(Build.VERSION_CODES.M)
    private fun initialStatusDetermination() {
        val myTestDataHandler = ExpDatabaseHandler(this@ActivityLifeSpanFeederXX)
        val statusOfChamberAtDayX = myTestDataHandler.readByteArrayAtOneColumn(thisExpID!!,columnID!!)?.get(chamberID!!-1)

        ShowDayAtFeederLSXX.text = "Day $columnID"
        MyUtility.backGroundIconFinder(textViewForChamberIDLSXX, myShapeOfChambersArray?.get(chamberID!!-1)!!)
        ShowConditionAtFeederLSXX.text = textArrayOfConditionName?.get(chamberID!!-1)!!
        ShowConditionAtFeederLSXX.paintFlags = ShowConditionAtFeederLSXX.paintFlags or Paint.UNDERLINE_TEXT_FLAG

        val updatedChamberID = MyUtility.findProperNumberUsingProperNumberingStyle(this, thisExpID!!, chamberID!!)
        when (statusOfChamberAtDayX) {
            AliveGreen -> {MyUtility.makeBoxGreen(textViewForChamberIDLSXX,applicationContext);       textViewForChamberIDLSXX.text = "#$updatedChamberID";
                ReportLifeSpanStatusTextView.text="Alive"; LS_PreviousDataBox4.text="Al"; LS_PreviousDataBox4.setTextColor(getColor(R.color.Green))}
            DeadBlue -> {MyUtility.makeBoxBlue(textViewForChamberIDLSXX,applicationContext);       textViewForChamberIDLSXX.text = "#$updatedChamberID";
                ReportLifeSpanStatusTextView.text="Dead"; LS_PreviousDataBox4.text="De"; LS_PreviousDataBox4.setTextColor(getColor(R.color.Blue))}
            NoInputGray -> {MyUtility.makeBoxGray(textViewForChamberIDLSXX,applicationContext);         textViewForChamberIDLSXX.text = "#$updatedChamberID";
                ReportLifeSpanStatusTextView.text="Ready"; LS_PreviousDataBox4.text="NA"; LS_PreviousDataBox4.setTextColor(getColor(R.color.DarkGray))}
            CensorRed -> {initCensored("Censored"); LS_PreviousDataBox4.text="C"}
            CensorBagged -> {initCensored("Bagged"); LS_PreviousDataBox4.text="CB"}
            CensorDried -> {initCensored("Dried"); LS_PreviousDataBox4.text="CD"}
            CensorExploded -> {initCensored("Exploded"); LS_PreviousDataBox4.text="CE"}
            CensorLost -> {initCensored("Lost"); LS_PreviousDataBox4.text="CL"}
            CensorUnidentified -> {initCensored("Unidentified"); LS_PreviousDataBox4.text="CU"}
        }
        fillPreviousAndNextDayData()
    }
    //----------------------------------------------------------------------------------------------
    private fun updateStatus (dataByte:Byte) {myTestDataHandler!!.updateOneCellAtOneColumn(thisExpID!!, columnID!!, chamberID!!, dataByte)}
    private fun speakUp (sayThis:String) {if (!myBooleanMute) {mTts!!.speak(sayThis, TextToSpeech.QUEUE_FLUSH, null, null)} }
    private fun speakUpAfterPreviousDone (sayThis:String) { if (!myBooleanMute) {mTts!!.speak(sayThis, TextToSpeech.QUEUE_ADD, null, null)} }
    private fun toastMe(useThis:String) {   myToasterObject?.cancel()
        myToasterObject = Toast.makeText(this@ActivityLifeSpanFeederXX, useThis, Toast.LENGTH_SHORT)
        myToasterObject?.show()
    }
    fun userInputDead() {
        MyUtility.makeBoxBlue(PreWormDisplayIDLSXX,applicationContext)
        val updatedChamberID = MyUtility.findProperNumberUsingProperNumberingStyle(this, thisExpID!!, chamberID!!)
        PreWormDisplayIDLSXX.text = "#$updatedChamberID -> Dead"
        updateStatus(DeadBlue)
        makeWormFollowingDaysDeadOrCensoredOrNoInput(DeadBlue)
        speakUp("$updatedChamberID Dead")
        gotoNextChamber()
    }
    private fun userInputCensored(textMassage:String, byteValue:Byte){
        MyUtility.makeBoxRed(PreWormDisplayIDLSXX,applicationContext)
        val updatedChamberID = MyUtility.findProperNumberUsingProperNumberingStyle(this, thisExpID!!, chamberID!!)
        PreWormDisplayIDLSXX.text = "#$updatedChamberID -> $textMassage"
        updateStatus(byteValue)
        makeWormFollowingDaysDeadOrCensoredOrNoInput(byteValue)
        speakUp("$updatedChamberID $textMassage")
        gotoNextChamber()
    }
    @RequiresApi(Build.VERSION_CODES.M)
    private fun initCensored(textMassage:String){
        MyUtility.makeBoxRed(textViewForChamberIDLSXX,applicationContext);
        val updatedChamberID = MyUtility.findProperNumberUsingProperNumberingStyle(this, thisExpID!!, chamberID!!)
        textViewForChamberIDLSXX.text = "#$updatedChamberID"
        ReportLifeSpanStatusTextView.text=textMassage
        LS_PreviousDataBox4.setTextColor(getColor(R.color.Red))
    }
    private fun makePreWormNoInput(){
        PreWormDisplayIDLSXX.text = "Last Input NA"
        MyUtility.makeBoxGray(PreWormDisplayIDLSXX,applicationContext)
    }
    fun userInputAlive() {
        MyUtility.makeBoxGreen(PreWormDisplayIDLSXX,applicationContext)
        val updatedChamberID = MyUtility.findProperNumberUsingProperNumberingStyle(this, thisExpID!!, chamberID!!)
        PreWormDisplayIDLSXX.text = "#$updatedChamberID -> Alive"
        updateStatus(AliveGreen)
        makeWormFollowingDaysDeadOrCensoredOrNoInput(NoInputGray)
        speakUp("$updatedChamberID Alive")
        gotoNextChamber()
    }
    //----------------------------------------------------------------------------------------------
    private fun makeWormFollowingDaysDeadOrCensoredOrNoInput(dataByte:Byte) {
        var daysFollowing = columnID
        while (daysFollowing!!<foundExperimentDayNum!!) {
            daysFollowing = daysFollowing.plus(1)
            myTestDataHandler!!.updateOneCellAtOneColumn(thisExpID!!, daysFollowing, chamberID!!, dataByte)
        }
    }
    //----------------------------------------------------------------------------------------------
    private fun nextWormIsCensoredOrDead ():Boolean {
        val myTestDataHandler = ExpDatabaseHandler(this@ActivityLifeSpanFeederXX)
        val statusOfChamberAtDayX = myTestDataHandler.readByteArrayAtOneColumn(thisExpID!!,columnID!!)?.get(chamberID!!-1)
        var mDecision = false
        when (statusOfChamberAtDayX) {
            CensorRed, CensorBagged, CensorDried, CensorExploded, CensorLost, CensorUnidentified, DeadBlue -> {mDecision=true}}
        return mDecision
    }
    //----------------------------------------------------------------------------------------------
    @RequiresApi(Build.VERSION_CODES.M)
    fun gotoNextChamber() {
        if (chamberID!!<totNumChambers!!) {
            chamberID = chamberID!!.plus(1)
            //===========================
            //if (columnID!!>1) {dayToCheck = columnID!!-1; while (!makeDecisionAboutChamberToShow()){chamberID = chamberID!!.plus(1)} }
            if (nextWormIsCensoredOrDead()){gotoNextChamber()}
            else {
                initialStatusDetermination()
                val updatedChamberID = MyUtility.findProperNumberUsingProperNumberingStyle(this, thisExpID!!, chamberID!!)
                speakUpAfterPreviousDone("$updatedChamberID ready")
            }
            //===========================
        } else {
            toastMe("Next Chamber Not available!")
            speakUp("last worm")
        }
    }
    @RequiresApi(Build.VERSION_CODES.M)
    fun gotoPreviousChamber() {
        if (chamberID!!>1) {
            chamberID = chamberID!!.minus(1)
            initialStatusDetermination()
            val updatedChamberID = MyUtility.findProperNumberUsingProperNumberingStyle(this, thisExpID!!, chamberID!!)
            speakUpAfterPreviousDone("$updatedChamberID ready")
        } else {
            toastMe("Previous Worm Not available!")
            speakUp("first worm")
        }
        makePreWormNoInput()
    }
    @RequiresApi(Build.VERSION_CODES.M)
    fun goToPreviousColumn() {
        if (columnID!!>1){
            columnID = columnID!!.minus(1)
            initialStatusDetermination()
            val updatedChamberID = MyUtility.findProperNumberUsingProperNumberingStyle(this, thisExpID!!, chamberID!!)
            speakUp("$updatedChamberID at day $columnID")
        } else {
            toastMe("Previous Day Not available!")
            speakUp("Previous day is not available")
        }
        makePreWormNoInput()
    }
    @RequiresApi(Build.VERSION_CODES.M)
    fun goToNextColumn() {
        if (columnID!!<foundExperimentDayNum!!){
            columnID = columnID!!.plus(1)
            initialStatusDetermination()
            val updatedChamberID = MyUtility.findProperNumberUsingProperNumberingStyle(this, thisExpID!!, chamberID!!)
            speakUp("$updatedChamberID at day $columnID")
        } else {
            toastMe("Next Day Not available!")
            speakUp("Next day is not available")
        }
        makePreWormNoInput()
    }
    private fun readPreviousDayInfo():Byte? {
        val myTestDataHandler = ExpDatabaseHandler(this@ActivityLifeSpanFeederXX)
        return myTestDataHandler.readByteArrayAtOneColumn(thisExpID!!,dayToCheck!!)?.get(chamberID!!-1)
    }
    private fun makeDecisionAboutChamberToShow ():Boolean {
        var mDecision = false
        when (readPreviousDayInfo()) {
            AliveGreen -> {mDecision=true}
            DeadBlue -> {mDecision=false}
            NoInputGray -> {
                dayToCheck = dayToCheck?.minus(1)
                mDecision = makeDecisionAboutChamberToShow()
            }
            CensorBagged -> {mDecision=false}
            CensorDried -> {mDecision=false}
            CensorExploded -> {mDecision=false}
            CensorLost -> {mDecision=false}
            CensorUnidentified -> {mDecision=false}
        }
        return mDecision
    }

    //----------------------------------------------------------------------------------------------
    //----------------------------------------------------------------------------------------------
    @RequiresApi(Build.VERSION_CODES.M)
    private fun fillPreviousAndNextDayData() {
        val myTestDataHandler = ExpDatabaseHandler(this@ActivityLifeSpanFeederXX)
        var statusOfChamberAtDayX:Byte? = null
        var dayNumValue:Int? = null

        dayNumValue =columnID!!-1
        if (dayNumValue>0 && dayNumValue<=foundExperimentDayNum!!) {
            statusOfChamberAtDayX = myTestDataHandler.readByteArrayAtOneColumn(thisExpID!!,dayNumValue )?.get(chamberID!!-1)
            fillPreNextAccordingly(statusOfChamberAtDayX!!, LS_PreviousDataBox3)
        }else {fillPreNextAccordingly(NoInputGray, LS_PreviousDataBox3)}

        dayNumValue =columnID!!-2
        if (dayNumValue>0 && dayNumValue<=foundExperimentDayNum!!) {
            statusOfChamberAtDayX = myTestDataHandler.readByteArrayAtOneColumn(thisExpID!!,dayNumValue )?.get(chamberID!!-1)
            fillPreNextAccordingly(statusOfChamberAtDayX!!, LS_PreviousDataBox2)}
        else {fillPreNextAccordingly(NoInputGray, LS_PreviousDataBox2)}

        dayNumValue =columnID!!-3
        if (dayNumValue>0 && dayNumValue<=foundExperimentDayNum!!) {
            statusOfChamberAtDayX = myTestDataHandler.readByteArrayAtOneColumn(thisExpID!!,dayNumValue)?.get(chamberID!!-1)
            fillPreNextAccordingly(statusOfChamberAtDayX!!, LS_PreviousDataBox1)}
        else {fillPreNextAccordingly(NoInputGray, LS_PreviousDataBox1)}

        dayNumValue =columnID!!+1
        if (dayNumValue>0 && dayNumValue<=foundExperimentDayNum!!) {
            statusOfChamberAtDayX = myTestDataHandler.readByteArrayAtOneColumn(thisExpID!!,dayNumValue)?.get(chamberID!!-1)
            fillPreNextAccordingly(statusOfChamberAtDayX!!, LS_PreviousDataBox5)}
        else {fillPreNextAccordingly(NoInputGray, LS_PreviousDataBox5)}
    }
    @RequiresApi(Build.VERSION_CODES.M)
    private fun fillPreNextAccordingly(statusOfChamber:Byte, myTextView: TextView){
        when (statusOfChamber) {
            AliveGreen -> {myTextView.text="Al"; myTextView.backgroundTintList = getColorStateList(R.color.SeaGreen)}
            DeadBlue -> {myTextView.text="De"; myTextView.backgroundTintList = getColorStateList(R.color.DeepSkyBlue)}
            NoInputGray -> {myTextView.text="NA"; myTextView.backgroundTintList = getColorStateList(R.color.DarkGray)}
            CensorRed -> {myTextView.text="C"; myTextView.backgroundTintList = getColorStateList(R.color.IndianRed)}
            CensorBagged -> {myTextView.text="CB"; myTextView.backgroundTintList = getColorStateList(R.color.IndianRed)}
            CensorDried -> {myTextView.text="CD"; myTextView.backgroundTintList = getColorStateList(R.color.IndianRed)}
            CensorExploded -> {myTextView.text="CE"; myTextView.backgroundTintList = getColorStateList(R.color.IndianRed)}
            CensorLost -> {myTextView.text="CL"; myTextView.backgroundTintList = getColorStateList(R.color.IndianRed)}
            CensorUnidentified -> {myTextView.text="CU"; myTextView.backgroundTintList = getColorStateList(R.color.IndianRed)}
            }
    }
    //----------------------------------------------------------------------------------------------
    //----------------------------------------------------------------------------------------------
    override fun onDestroy() {
        mTts!!.stop()
        mTts!!.shutdown()
        super.onDestroy()
    }
    //----------------------------------------------------------------------------------------------
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == MY_DATA_CHECK_CODE) {
            if (resultCode == TextToSpeech.Engine.CHECK_VOICE_DATA_PASS) {

                mTts = TextToSpeech(this@ActivityLifeSpanFeederXX, OnInitListener { })
                mTts!!.language = Locale.US
                mTts!!.setSpeechRate(TextToSpeechSpeedValue)
            } else {
                toastMe("Missing Text to Speech Package")
                val installIntent = Intent()
                installIntent.action = TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA
                startActivity(installIntent)
            }
        }
    }
    //----------------------------------------------------------------------------------------------
}
