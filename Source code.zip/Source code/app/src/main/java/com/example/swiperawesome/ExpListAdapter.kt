package com.example.swiperawesome

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.gun0912.tedpermission.PermissionListener
import com.gun0912.tedpermission.TedPermission
import jxl.Workbook
import jxl.WorkbookSettings
import jxl.write.Label
import jxl.write.WritableWorkbook
import jxl.write.WriteException
import jxl.write.biff.RowsExceededException
import java.io.File
import java.io.IOException
import java.util.*


class ExpListAdapter(var list: ArrayList<Experiment>, val mContext: Context): RecyclerView.Adapter<ExpListAdapter.ViewHolder>() {

    var myDatabaseHandler:ExpDatabaseHandler? = null
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ExpListAdapter.ViewHolder {
        val rowsView = LayoutInflater.from(mContext).inflate(R.layout.list_rows_recycler,parent, false)
        return ViewHolder(rowsView)
    }
    //----------------------------------------------------------------------------------------------
    override fun getItemCount(): Int {return list.size}
    //----------------------------------------------------------------------------------------------
    override fun onBindViewHolder(holder: ExpListAdapter.ViewHolder, position: Int) {
        holder.bindMyViews(list[position])
    }
    //----------------------------------------------------------------------------------------------
    inner class ViewHolder(myItemView: View):RecyclerView.ViewHolder(myItemView), View.OnClickListener {
        var myExperimentName = myItemView.findViewById(R.id.myExpName) as TextView
        var myStartDate = myItemView.findViewById(R.id.myExpStartDate) as TextView
        var myExperimentType = myItemView.findViewById(R.id.myExpType) as TextView
        var myNumCondition = myItemView.findViewById(R.id.myNumCondition) as TextView
        var myDeleteButton = myItemView.findViewById(R.id.deleteButtonExp) as Button
        var myEditButton = myItemView.findViewById(R.id.editButtonExp) as Button
        var myGoIntoExpButton = myItemView.findViewById(R.id.imageInCardID) as ImageView
        var mySaveButtonForExp = myItemView.findViewById(R.id.saveButtonExp) as Button
        var myPlotThisDataExp = myItemView.findViewById(R.id.plotThisExpButton) as Button
        //------------------------------------------------------------------------------------------
        fun bindMyViews(myExperiment:Experiment){

            myExperimentName.text = myExperiment.name
            myStartDate.text = myExperiment.startDate
            myNumCondition.text = myExperiment.testConditionName.size.toString() + " conditions"

            when(myExperiment.type) {
                mContext.getString(R.string.LS_assay) -> {
                    myGoIntoExpButton.setImageDrawable(ContextCompat.getDrawable(mContext,R.drawable.ic_lifespan))
                    myExperimentType.text = "Lifespan assay"}
                mContext.getString(R.string.LS_assayXX) -> {
                    myGoIntoExpButton.setImageDrawable(ContextCompat.getDrawable(mContext,R.drawable.ic_ls_separate))
                    myExperimentType.text = "Ind. worm LS"}
                mContext.getString(R.string.RS_assay) -> {
                    myGoIntoExpButton.setImageDrawable(ContextCompat.getDrawable(mContext,R.drawable.ic_rs_assay))
                    myExperimentType.text = "Reprod. span assay"}
                mContext.getString(R.string.ProgenyAssay) -> {
                    myGoIntoExpButton.setImageDrawable(ContextCompat.getDrawable(mContext,R.drawable.ic_progeny_assay))
                    myExperimentType.text = "Brood size assay"}
                mContext.getString(R.string.ChoiceAssay) -> {
                    myGoIntoExpButton.setImageDrawable(ContextCompat.getDrawable(mContext,R.drawable.ic_choice_assay))
                    myExperimentType.text = "Choice assay"}
            }
            //--------------------------------------------------------------------------------------------------
            myDeleteButton.setOnClickListener(this)
            myEditButton.setOnClickListener(this)
            myGoIntoExpButton.setOnClickListener(this)
            mySaveButtonForExp.setOnClickListener(this)
            myPlotThisDataExp.setOnClickListener (this)
        }
        //------------------------------------------------------------------------------------------
        @RequiresApi(Build.VERSION_CODES.M)
        override fun onClick(v_row: View?) {
            val myPositionInDatabase: Int? = list[adapterPosition].id
            when (v_row!!.id){
                myDeleteButton.id -> { deleteSpecificExperiment(myPositionInDatabase!!)}
                myEditButton.id -> {editSpecificExperiment(myPositionInDatabase!!)}
                myGoIntoExpButton.id -> {openUpExperimentData(myPositionInDatabase!!)}
                mySaveButtonForExp.id -> {exportMyExpToExcel(myPositionInDatabase!!)}
                myPlotThisDataExp.id -> {openActivityForGraph(myPositionInDatabase!!)}
            }
        }
        //------------------------------------------------------------------------------------------
        private fun deleteSpecificExperiment(myPositionInDatabase:Int) {

            if (myDeleteButton.backgroundTintList == mContext.getColorStateList(R.color.Red)) {
                myDatabaseHandler = ExpDatabaseHandler(mContext)
                myDatabaseHandler!!.deleteExpInfo(myPositionInDatabase)
                list.removeAt(adapterPosition)
                notifyItemRemoved(adapterPosition)
            } else if (myDeleteButton.backgroundTintList== mContext.getColorStateList(R.color.Orange)) {
                myDeleteButton.backgroundTintList = mContext.getColorStateList(R.color.Red)
            } else {
                myDeleteButton.backgroundTintList = mContext.getColorStateList(R.color.Orange)
            }
        }
        //------------------------------------------------------------------------------------------
        @RequiresApi(Build.VERSION_CODES.M)
        fun editSpecificExperiment(myPositionInDatabase:Int) {
            myDeleteButton.backgroundTintList = mContext.getColorStateList(R.color.Black)
            val myView = LayoutInflater.from(mContext).inflate(R.layout.popup_add_exp,null)
            list = NewExpPopup.runningPopup(true, adapterPosition, myView,list, mContext, this@ExpListAdapter)!!
        }
        //------------------------------------------------------------------------------------------
        private fun openUpExperimentData(myPositionInDatabase: Int) {
            myDeleteButton.backgroundTintList = mContext.getColorStateList(R.color.Black)
            val myIntent = Intent( mContext,ActivityChamberGallery::class.java )
            myDatabaseHandler = ExpDatabaseHandler(mContext)
            val myCurrentExp = myDatabaseHandler!!.readOneExpInfo(myPositionInDatabase)
            myIntent.putExtra("KeyForExpID", myPositionInDatabase)
            myIntent.putExtra("KeyForNumChambers", myCurrentExp.testConditionRange.last().toInt())
            mContext.startActivity(myIntent)
        }
        //------------------------------------------------------------------------------------------
        private fun exportMyExpToExcel(myPosition: Int) {
            myDeleteButton.backgroundTintList = mContext.getColorStateList(R.color.Black)
            ExcelSave.permitAccessWriteRead(mContext)
            ExcelSave.fillingTheExcel(myPosition, mContext)
        }
        //------------------------------------------------------------------------------------------
        private fun openActivityForGraph (myPosition: Int) {
            myDeleteButton.backgroundTintList = mContext.getColorStateList(R.color.Black)
            val myIntent = Intent( mContext,ActivityDataPlotter::class.java )
            myIntent.putExtra("KeyForExpID", myPosition)
            mContext.startActivity(myIntent)
        }
        //------------------------------------------------------------------------------------------
    }
}