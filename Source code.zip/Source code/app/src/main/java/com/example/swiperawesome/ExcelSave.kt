package com.example.swiperawesome

import android.Manifest
import android.content.Context
import android.text.format.DateFormat
import android.widget.Toast
import com.gun0912.tedpermission.PermissionListener
import com.gun0912.tedpermission.TedPermission
import jxl.CellView
import jxl.Workbook
import jxl.WorkbookSettings
import jxl.format.Alignment
import jxl.format.Border
import jxl.format.BorderLineStyle
import jxl.format.Colour
import jxl.write.Label
import jxl.write.WritableCellFormat
import jxl.write.WritableWorkbook
import jxl.write.WriteException
import jxl.write.biff.RowsExceededException
import java.io.File
import java.io.IOException
import java.util.*

object ExcelSave {

    fun permitAccessWriteRead(thisContext: Context) {
        //--------------------------------------------------------------------------------------
        val permissionListener: PermissionListener = object : PermissionListener {
            override fun onPermissionGranted() {
                //Toast.makeText(thisContext, "Permission Granted", Toast.LENGTH_SHORT).show()
            }

            override fun onPermissionDenied(deniedPermissions: List<String>) {
                Toast.makeText(thisContext, "Permission Denied\n$deniedPermissions", Toast.LENGTH_SHORT).show()
            }
        }
        TedPermission.with(thisContext).setPermissionListener(permissionListener).setDeniedMessage("If you reject permission,you can not use this service\n\nPlease turn on permissions at [Setting] > [Permission]").setPermissions(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE).check()
    }

    //----------------------------------------------------------------------------------------------
    fun fillingTheExcel(myPosition: Int, mContext: Context) {

        val myDatabaseHandler = ExpDatabaseHandler(mContext)
        val expInfoForExcel = myDatabaseHandler.readOneExpInfo(myPosition)
        val mDateTime = Calendar.getInstance().time
        val mDay = DateFormat.format("dd", mDateTime) as String // 20
        val mMonth = DateFormat.format("MMM", mDateTime) as String // Jun
        val mYear = DateFormat.format("yyyy", mDateTime) as String // 2013
        val fileName = "${expInfoForExcel.name}@${expInfoForExcel.startDate}_saved@$mDay$mMonth$mYear.xls"

        //val directory = File(mContext.filesDir.absolutePath.toString())
        val directory = File(mContext.getExternalFilesDir(null)!!.absolutePath)
        if (!directory.isDirectory) {
            directory.mkdirs()
        }
        val file = File(directory, fileName)
        //Log.d("address",sdCard?.absolutePath.toString())
        val wbSettings = WorkbookSettings()
        wbSettings.locale = Locale("en", "EN")
        val workbook: WritableWorkbook
        try {
            workbook = Workbook.createWorkbook(file, wbSettings)
            for (ii in 1..workbook.numberOfSheets) workbook.removeSheet(ii)
            try {
                when (expInfoForExcel.type) {
                    mContext.getString(R.string.LS_assay) -> {
                        writeExcelLifeSpanAssay(expInfoForExcel, mContext, workbook)
                    }
                    mContext.getString(R.string.LS_assayXX) -> {
                        writeExcelLifeSpanAssayXX(expInfoForExcel, mContext, workbook)
                    }
                    mContext.getString(R.string.RS_assay) -> {
                        writeExcelReproductiveSpanAssay(expInfoForExcel, mContext, workbook)
                    }
                    mContext.getString(R.string.ProgenyAssay) -> {
                        writeExcelBroodSizeAssay(expInfoForExcel, mContext, workbook)
                    }
                    mContext.getString(R.string.ChoiceAssay) -> {
                        writeExcelChoiceAssay(expInfoForExcel, mContext, workbook)
                    }
                }
                Toast.makeText(mContext, "Successfully Saved!", Toast.LENGTH_SHORT).show()
            } catch (e: RowsExceededException) {
                e.printStackTrace()
            } catch (e: WriteException) {
                e.printStackTrace()
            }
            workbook.write()
            try {
                workbook.close()
            } catch (e: WriteException) {
                e.printStackTrace()
            }
        } catch (e: IOException) {
            e.printStackTrace()
        }
        //----------------------------------------------
    }

    //----------------------------------------------------------------------------------------------
    private fun writeExcelChoiceAssay(expInfoForExcel: Experiment, mContext: Context, workbook: WritableWorkbook) {

        val sheet = workbook.createSheet(expInfoForExcel.type, 0)
        val expCellColor = WritableCellFormat(); expCellColor.setBackground(Colour.GRAY_25); expCellColor.setBorder(Border.ALL, BorderLineStyle.THICK)
        sheet.addCell(Label(0, 0, "Experiment: ${expInfoForExcel.name}", expCellColor))
        sheet.addCell(Label(0, 1, "Experiment conducted ${expInfoForExcel.startDate}", expCellColor))
        sheet.mergeCells(0, 0, 10, 0)
        sheet.mergeCells(0, 1, 10, 1)
        val myToProcessData = DataProcessor()
        val mConditionArray = myToProcessData.readAndCreateConditionClassInfo(expInfoForExcel.id!!, mContext)
        //----------------------------------------------
        val leftC1 = 0;
        val rightC1 = 1;
        val choiceI1 = 2
        val leftC2 = 4;
        val rightC2 = 5;
        val choiceI2 = 6
        var rowID = 4
        var rowFlip = 0

        val yellowCellColor = WritableCellFormat(); yellowCellColor.setBackground(Colour.YELLOW);
        yellowCellColor.setBorder(Border.ALL, BorderLineStyle.THICK); yellowCellColor.alignment = Alignment.CENTRE

        val conditionCellColor = WritableCellFormat(); //conditionCellColor.setBackground(Colour.YELLOW);
        conditionCellColor.setBorder(Border.ALL, BorderLineStyle.THIN); conditionCellColor.alignment = Alignment.CENTRE

        val greenCellColor = WritableCellFormat(); greenCellColor.setBackground(Colour.GREEN);
        greenCellColor.setBorder(Border.BOTTOM, BorderLineStyle.THIN); greenCellColor.alignment = Alignment.CENTRE

        val blueCellColor = WritableCellFormat(); blueCellColor.setBackground(Colour.BLUE);
        blueCellColor.setBorder(Border.BOTTOM, BorderLineStyle.THIN); blueCellColor.alignment = Alignment.CENTRE

        val redCellColor = WritableCellFormat(); redCellColor.setBackground(Colour.RED);
        redCellColor.setBorder(Border.ALL, BorderLineStyle.THIN); redCellColor.alignment = Alignment.CENTRE

        sheet.setColumnView(leftC1, 8); sheet.setColumnView(rightC1, 8); sheet.setColumnView(choiceI1, 12)
        sheet.setColumnView(leftC2, 8); sheet.setColumnView(rightC2, 8); sheet.setColumnView(choiceI2, 12)

        for (mC in 1..mConditionArray.size) {
            mConditionArray[mC - 1] = myToProcessData.choiceAssayCalculator(mConditionArray[mC - 1])

            when (mC % 2) {
                1 -> {
                    if (rowFlip < rowID) rowFlip = rowID; else rowID = rowFlip
                    sheet.addCell(Label(leftC1, rowID, mConditionArray[mC - 1].name!!.split(",", ignoreCase = true, limit = 0)[0], yellowCellColor));
                    sheet.mergeCells(leftC1, rowID, choiceI1, rowID); rowID += 1
                    sheet.addCell(Label(leftC1, rowID, mConditionArray[mC - 1].name!!.split(",", ignoreCase = true, limit = 0)[1], conditionCellColor))
                    sheet.addCell(Label(rightC1, rowID, mConditionArray[mC - 1].name!!.split(",", ignoreCase = true, limit = 0)[2], conditionCellColor))
                    sheet.addCell(Label(choiceI1, rowID, "Choice Index", conditionCellColor)); rowID += 1

                    for (ii in 1..mConditionArray[mC - 1].totalC!!) {
                        sheet.addCell(Label(leftC1, rowID, mConditionArray[mC - 1].dataMatrix!![ii - 1][0].toString(), greenCellColor))
                        sheet.addCell(Label(rightC1, rowID, mConditionArray[mC - 1].dataMatrix!![ii - 1][1].toString(), blueCellColor))
                        sheet.addCell(Label(choiceI1, rowID, mConditionArray[mC - 1].choiceIndex!![ii - 1].toString(), redCellColor)); rowID += 1
                    }
                    rowID += 1
                }
                0 -> {
                    sheet.addCell(Label(leftC2, rowFlip, mConditionArray[mC - 1].name!!.split(",", ignoreCase = true, limit = 0)[0], yellowCellColor));
                    sheet.mergeCells(leftC2, rowFlip, choiceI2, rowFlip); rowFlip += 1
                    sheet.addCell(Label(leftC2, rowFlip, mConditionArray[mC - 1].name!!.split(",", ignoreCase = true, limit = 0)[1], conditionCellColor))
                    sheet.addCell(Label(rightC2, rowFlip, mConditionArray[mC - 1].name!!.split(",", ignoreCase = true, limit = 0)[2], conditionCellColor))
                    sheet.addCell(Label(choiceI2, rowFlip, "Choice Index", conditionCellColor)); rowFlip += 1

                    for (ii in 1..mConditionArray[mC - 1].totalC!!) {
                        sheet.addCell(Label(leftC2, rowFlip, mConditionArray[mC - 1].dataMatrix!![ii - 1][0].toString(), greenCellColor))
                        sheet.addCell(Label(rightC2, rowFlip, mConditionArray[mC - 1].dataMatrix!![ii - 1][1].toString(), blueCellColor))
                        sheet.addCell(Label(choiceI2, rowFlip, mConditionArray[mC - 1].choiceIndex!![ii - 1].toString(), redCellColor)); rowFlip += 1
                    }
                    rowFlip += 1
                }
            }
        }
        //----------------------------------------------
    }

    //----------------------------------------------------------------------------------------------
    private fun writeExcelLifeSpanAssay(expInfoForExcel: Experiment, mContext: Context, workbook: WritableWorkbook) {

        val sheet = workbook.createSheet(expInfoForExcel.type, 0)
        val expCellColor = WritableCellFormat(); expCellColor.setBackground(Colour.GRAY_25); expCellColor.setBorder(Border.ALL, BorderLineStyle.THICK)
        sheet.addCell(Label(0, 0, "Experiment: ${expInfoForExcel.name}", expCellColor))
        sheet.addCell(Label(0, 1, "Experiment conducted ${expInfoForExcel.startDate}", expCellColor))
        sheet.mergeCells(0, 0, 10, 0)
        sheet.mergeCells(0, 1, 10, 1)
        val myToProcessData = DataProcessor()
        val mConditionArray = myToProcessData.readAndCreateConditionClassInfo(expInfoForExcel.id!!, mContext)
        //----------------------------------------------
        val dayNum = 0;
        val cAlive = 2;
        val cDead = 3;
        val cCensored = 4
        var columnCounter = 0
        var columnAlive = 0;
        var columnDead = 0;
        var columnCensored = 0
        var tmpValueAlive = 0;
        var tmpValueDead = 0;
        var tmpValueCensored = 0
        var flagAlive = false;
        var flagDead = false;
        var flagCensored = false

        val conditionCellColor = WritableCellFormat(); //conditionCellColor.setBackground(Colour.YELLOW);
        conditionCellColor.setBorder(Border.ALL, BorderLineStyle.THIN); conditionCellColor.alignment = Alignment.CENTRE

        val yellowCellColor = WritableCellFormat(); yellowCellColor.setBackground(Colour.YELLOW);
        yellowCellColor.setBorder(Border.ALL, BorderLineStyle.THICK); yellowCellColor.alignment = Alignment.CENTRE

        val greenCellColor = WritableCellFormat(); greenCellColor.setBackground(Colour.GREEN);
        greenCellColor.setBorder(Border.ALL, BorderLineStyle.THIN); greenCellColor.alignment = Alignment.CENTRE

        val blueCellColor = WritableCellFormat(); blueCellColor.setBackground(Colour.BLUE);
        blueCellColor.setBorder(Border.ALL, BorderLineStyle.THIN); blueCellColor.alignment = Alignment.CENTRE

        val redCellColor = WritableCellFormat(); redCellColor.setBackground(Colour.RED);
        redCellColor.setBorder(Border.ALL, BorderLineStyle.THIN); redCellColor.alignment = Alignment.CENTRE

        for (mC in 1..mConditionArray.size) {

            columnAlive = columnCounter + cAlive
            columnDead = columnCounter + cDead
            columnCensored = columnCounter + cCensored
            var rowID = 4
            sheet.addCell(Label(columnAlive, rowID, mConditionArray[mC - 1].name!!, yellowCellColor))
            sheet.mergeCells(columnAlive, rowID, columnCensored, rowID)
            rowID += 1
            sheet.addCell(Label(dayNum, rowID, "day#", conditionCellColor))
            sheet.addCell(Label(columnAlive, rowID, "Alive", conditionCellColor))
            sheet.addCell(Label(columnDead, rowID, "Dead", conditionCellColor))
            sheet.addCell(Label(columnCensored, rowID, "Censored", conditionCellColor));
            sheet.setColumnView(dayNum, 4)
            sheet.setColumnView(columnAlive, 8)
            sheet.setColumnView(columnDead, 8)
            sheet.setColumnView(columnCensored, 8)
            sheet.setColumnView(columnCensored+1, 4)

            rowID += 1
            for (dayInt in 1..mConditionArray[mC - 1].numColumnTotal!!) {
                tmpValueAlive = 0; tmpValueDead = 0; tmpValueCensored = 0
                flagAlive = false; flagDead = false; flagCensored = false
                for (replicate in 1..mConditionArray[mC - 1].totalC!!) {
                    if (mConditionArray[mC - 1].dataMatrix3dim!![0][dayInt - 1][replicate - 1] < MyUtility.byte2Int(MaxOfAvailableIntInByteArray)) {
                        tmpValueAlive += mConditionArray[mC - 1].dataMatrix3dim!![0][dayInt - 1][replicate - 1]
                        flagAlive = true
                    }
                    if (mConditionArray[mC - 1].dataMatrix3dim!![1][dayInt - 1][replicate - 1] < MyUtility.byte2Int(MaxOfAvailableIntInByteArray)) {
                        tmpValueDead += mConditionArray[mC - 1].dataMatrix3dim!![1][dayInt - 1][replicate - 1]
                        flagDead = true
                    }
                    if (mConditionArray[mC - 1].dataMatrix3dim!![2][dayInt - 1][replicate - 1] < MyUtility.byte2Int(MaxOfAvailableIntInByteArray)) {
                        tmpValueCensored += mConditionArray[mC - 1].dataMatrix3dim!![2][dayInt - 1][replicate - 1]
                        flagCensored = true
                    }
                }
                if (flagAlive) {
                    sheet.addCell(Label(columnAlive, rowID, tmpValueAlive.toString(), greenCellColor))
                }
                if (flagDead) {
                    sheet.addCell(Label(columnDead, rowID, tmpValueDead.toString(), blueCellColor))
                }
                if (flagCensored) {
                    sheet.addCell(Label(columnCensored, rowID, tmpValueCensored.toString(), redCellColor))
                }
                if (mC == 1) {
                    sheet.addCell(Label(dayNum, rowID, dayInt.toString(), conditionCellColor))
                }
                rowID += 1
            }
            columnCounter = +4
        }
    }

    //----------------------------------------------------------------------------------------------
    private fun writeExcelBroodSizeAssay(expInfoForExcel: Experiment, mContext: Context, workbook: WritableWorkbook) {

        val sheet = workbook.createSheet(expInfoForExcel.type, 0)
        val expCellColor = WritableCellFormat(); expCellColor.setBackground(Colour.GRAY_25); expCellColor.setBorder(Border.ALL, BorderLineStyle.THICK)
        sheet.addCell(Label(0, 0, "Experiment: ${expInfoForExcel.name}", expCellColor))
        sheet.addCell(Label(0, 1, "Conducted at ${expInfoForExcel.startDate}", expCellColor))
        sheet.mergeCells(0, 0, 10, 0)
        sheet.mergeCells(0, 1, 10, 1)
        val myToProcessData = DataProcessor()
        val mConditionArray = myToProcessData.readAndCreateConditionClassInfo(expInfoForExcel.id!!, mContext)
        //----------------------------------------------
        val columnSpace = 2
        val cProgeny = 1
        val cUnhatched = cProgeny + columnSpace + mConditionArray[0].numColumnTotal!!
        val cUnfertilized = cUnhatched + columnSpace + mConditionArray[0].numColumnTotal!!
        var rowID = 4
        var rowMain = rowID
        var cPointer = 0

        val conditionCellColor = WritableCellFormat(); //conditionCellColor.setBackground(Colour.YELLOW);
        conditionCellColor.setBorder(Border.ALL, BorderLineStyle.THIN); conditionCellColor.alignment = Alignment.CENTRE

        val yellowCellColor = WritableCellFormat(); yellowCellColor.setBackground(Colour.YELLOW);
        yellowCellColor.setBorder(Border.ALL, BorderLineStyle.THICK); yellowCellColor.alignment = Alignment.CENTRE

        val greenCellColor = WritableCellFormat(); greenCellColor.setBackground(Colour.GREEN);
        greenCellColor.setBorder(Border.ALL, BorderLineStyle.THIN); greenCellColor.alignment = Alignment.CENTRE

        val blueCellColor = WritableCellFormat(); blueCellColor.setBackground(Colour.BLUE);
        blueCellColor.setBorder(Border.ALL, BorderLineStyle.THIN); blueCellColor.alignment = Alignment.CENTRE

        val redCellColor = WritableCellFormat(); redCellColor.setBackground(Colour.RED);
        redCellColor.setBorder(Border.ALL, BorderLineStyle.THIN); redCellColor.alignment = Alignment.CENTRE

        for (mC in 1..mConditionArray.size) {

            sheet.addCell(Label(cProgeny, rowID, mConditionArray[mC - 1].name!!, yellowCellColor))
            sheet.mergeCells(cProgeny, rowID, cProgeny + mConditionArray[mC - 1].numColumnTotal!! - 1, rowID)
            sheet.addCell(Label(cUnhatched, rowID, mConditionArray[mC - 1].name!!, yellowCellColor))
            sheet.mergeCells(cUnhatched, rowID, cUnhatched + mConditionArray[mC - 1].numColumnTotal!! - 1, rowID)
            sheet.addCell(Label(cUnfertilized, rowID, mConditionArray[mC - 1].name!!, yellowCellColor))
            sheet.mergeCells(cUnfertilized, rowID, cUnfertilized + mConditionArray[mC - 1].numColumnTotal!! - 1, rowID)
            rowID += 1
            sheet.addCell(Label(cProgeny, rowID, "Brood size", conditionCellColor))
            sheet.mergeCells(cProgeny, rowID, cProgeny + mConditionArray[mC - 1].numColumnTotal!! - 1, rowID)
            sheet.addCell(Label(cUnhatched, rowID, "Unhatched eggs", conditionCellColor))
            sheet.mergeCells(cUnhatched, rowID, cUnhatched + mConditionArray[mC - 1].numColumnTotal!! - 1, rowID)
            sheet.addCell(Label(cUnfertilized, rowID, "Unfertilized Oocytes", conditionCellColor))
            sheet.mergeCells(cUnfertilized, rowID, cUnfertilized + mConditionArray[mC - 1].numColumnTotal!! - 1, rowID)
            rowID += 1
            sheet.addCell(Label(cProgeny - 1, rowID, "No.", conditionCellColor))
            for (dayInt in 1..mConditionArray[mC - 1].numColumnTotal!!) {
                sheet.addCell(Label(cProgeny + dayInt - 1, rowID, "d$dayInt", redCellColor))
                sheet.setColumnView(cProgeny + dayInt - 1, 4)
            }
            sheet.addCell(Label(cUnhatched - 1, rowID, "No.", conditionCellColor))
            for (dayInt in 1..mConditionArray[mC - 1].numColumnTotal!!) {
                sheet.addCell(Label(cUnhatched + dayInt - 1, rowID, "d$dayInt", redCellColor))
                sheet.setColumnView(cUnhatched + dayInt - 1, 4)
            }
            sheet.addCell(Label(cUnfertilized - 1, rowID, "No."))
            for (dayInt in 1..mConditionArray[mC - 1].numColumnTotal!!) {
                sheet.addCell(Label(cUnfertilized + dayInt - 1, rowID, "d$dayInt", redCellColor))
                sheet.setColumnView(cUnfertilized + dayInt - 1, 4)
            }
            rowMain = rowID

            for (mItem in 1..mConditionArray[mC - 1].numDimMatrixData!!) {
                when (mItem) {
                    1 -> {
                        cPointer = cProgeny
                    }; 2 -> {
                    cPointer = cUnhatched
                }; 3 -> {
                    cPointer = cUnfertilized
                }
                }
                rowID = rowMain
                for (replicate in 1..mConditionArray[mC - 1].totalC!!) {
                    rowID += 1
                    sheet.addCell(Label(cPointer - 1, rowID, "$replicate", conditionCellColor))
                    sheet.setColumnView(cPointer-1, 4)
                    if (cPointer-1>0) {sheet.setColumnView(cPointer-2, 3)}
                    for (dayInt in 1..mConditionArray[mC - 1].numColumnTotal!!) {
                        if (mConditionArray[mC - 1].dataMatrix3dim!![mItem - 1][dayInt - 1][replicate - 1] < MyUtility.byte2Int(MaxOfAvailableIntInByteArray)) {
                            sheet.addCell(Label(cPointer + dayInt - 1, rowID, mConditionArray[mC - 1].dataMatrix3dim!![mItem - 1][dayInt - 1][replicate - 1].toString(), greenCellColor))
                        }
                    }
                }
            }
            rowID += 3
        }
    }

    //----------------------------------------------------------------------------------------------
    private fun writeExcelReproductiveSpanAssay(expInfoForExcel: Experiment, mContext: Context, workbook: WritableWorkbook) {

        val sheet = workbook.createSheet(expInfoForExcel.type, 0)
        val expCellColor = WritableCellFormat(); expCellColor.setBackground(Colour.GRAY_25); expCellColor.setBorder(Border.ALL, BorderLineStyle.THICK)
        sheet.addCell(Label(0, 0, "Experiment: ${expInfoForExcel.name}", expCellColor))
        sheet.addCell(Label(0, 1, "Conducted at ${expInfoForExcel.startDate}", expCellColor))
        sheet.mergeCells(0, 0, 10, 0)
        sheet.mergeCells(0, 1, 10, 1)

        val myToProcessData = DataProcessor()
        val mConditionArray = myToProcessData.readAndCreateConditionClassInfo(expInfoForExcel.id!!, mContext)
        //----------------------------------------------
        val replicateColumn = 0
        val dayStopColumn = 1
        val censorBColumn = 2
        val cRep = 4
        var rowID = 4

        val strainCellColor = WritableCellFormat(); strainCellColor.setBackground(Colour.YELLOW);
        strainCellColor.setBorder(Border.ALL, BorderLineStyle.THIN); strainCellColor.alignment = Alignment.CENTRE

        val conditionCellColor = WritableCellFormat(); //conditionCellColor.setBackground(Colour.YELLOW);
        conditionCellColor.setBorder(Border.ALL, BorderLineStyle.THIN); conditionCellColor.alignment = Alignment.CENTRE

        val rsCellColor = WritableCellFormat(); rsCellColor.setBackground(Colour.AQUA);
        rsCellColor.setBorder(Border.ALL, BorderLineStyle.THIN); rsCellColor.alignment = Alignment.CENTRE

        val dayCellColor = WritableCellFormat(); dayCellColor.setBackground(Colour.GRAY_25);
        dayCellColor.setBorder(Border.ALL, BorderLineStyle.THICK); dayCellColor.alignment = Alignment.CENTRE

        val greenCellColor = WritableCellFormat(); greenCellColor.setBackground(Colour.GREEN);
        greenCellColor.setBorder(Border.BOTTOM, BorderLineStyle.THIN); greenCellColor.alignment = Alignment.CENTRE

        val blueCellColor = WritableCellFormat(); blueCellColor.setBackground(Colour.BLUE);
        blueCellColor.setBorder(Border.ALL, BorderLineStyle.THIN); blueCellColor.alignment = Alignment.CENTRE

        val redCellColor = WritableCellFormat(); redCellColor.setBackground(Colour.RED);
        redCellColor.setBorder(Border.ALL, BorderLineStyle.THIN); redCellColor.alignment = Alignment.CENTRE

        sheet.setColumnView(0, 5); sheet.setColumnView(1, 5); sheet.setColumnView(2, 5); sheet.setColumnView(3, 4)
        for (mC in 1..mConditionArray.size) {
            mConditionArray[mC - 1] = myToProcessData.reproductiveSpanCalculator(mConditionArray[mC - 1])
        }

        for (mC in 1..mConditionArray.size) {

            sheet.addCell(Label(cRep, rowID, mConditionArray[mC - 1].name!!, strainCellColor))
            sheet.mergeCells(cRep, rowID, cRep + mConditionArray[mC - 1].numColumnTotal!! - 1, rowID)
            rowID += 1
            sheet.addCell(Label(replicateColumn + 1, rowID, mConditionArray[mC - 1].name!!, strainCellColor))
            sheet.mergeCells(replicateColumn + 1, rowID, replicateColumn + 2, rowID)
            sheet.addCell(Label(cRep, rowID, "Reproductive Span assay", conditionCellColor))
            sheet.mergeCells(cRep, rowID, cRep + mConditionArray[mC - 1].numColumnTotal!! - 1, rowID)
            rowID += 1
            sheet.addCell(Label(replicateColumn, rowID, "No."))
            sheet.addCell(Label(dayStopColumn, rowID, "RS", conditionCellColor))
            sheet.addCell(Label(censorBColumn, rowID, "0/1", conditionCellColor))
            for (dayInt in 1..mConditionArray[mC - 1].numColumnTotal!!) {
                sheet.addCell(Label(cRep + dayInt - 1, rowID, "d$dayInt", dayCellColor))
                sheet.setColumnView(cRep + dayInt - 1, 6)
            }

            for (replicate in 1..mConditionArray[mC - 1].totalC!!) {
                rowID += 1
                sheet.addCell(Label(replicateColumn, rowID, "$replicate"))
                sheet.addCell(Label(dayStopColumn, rowID, mConditionArray[mC - 1].dayStop?.get(replicate - 1)?.toString(), rsCellColor))
                if (mConditionArray[mC - 1].censorB?.get(replicate - 1)!!) {
                    sheet.addCell(Label(censorBColumn, rowID, 1.toString(), rsCellColor))
                } else {
                    sheet.addCell(Label(censorBColumn, rowID, 0.toString(), rsCellColor))
                }

                for (dayInt in 1..mConditionArray[mC - 1].numColumnTotal!!) {
                    when (MyUtility.int2Byte(mConditionArray[mC - 1].dataMatrix!![replicate - 1][dayInt - 1])) {
                        ProgenyGreen -> {
                            sheet.addCell(Label(cRep + dayInt - 1, rowID, "Re", greenCellColor))
                        }
                        NoProgenyBlue -> {
                            sheet.addCell(Label(cRep + dayInt - 1, rowID, "NP", blueCellColor))
                        }
                        CensorRed -> {
                            sheet.addCell(Label(cRep + dayInt - 1, rowID, "C", redCellColor))
                        }
                        CensorBagged -> {
                            sheet.addCell(Label(cRep + dayInt - 1, rowID, "CB", redCellColor))
                        }
                        CensorDeadReproductive -> {
                            sheet.addCell(Label(cRep + dayInt - 1, rowID, "CD", redCellColor))
                        }
                        CensorExploded -> {
                            sheet.addCell(Label(cRep + dayInt - 1, rowID, "CE", redCellColor))
                        }
                        CensorLost -> {
                            sheet.addCell(Label(cRep + dayInt - 1, rowID, "CL", redCellColor))
                        }

                        MyUtility.int2Byte(MyUtility.byte2Int(ProgenyGreen) - MyUtility.byte2Int(HintNoMaleReproductive)) -> {
                            sheet.addCell(Label(cRep + dayInt - 1, rowID, "Re_NM", greenCellColor))
                        }
                        MyUtility.int2Byte(MyUtility.byte2Int(NoProgenyBlue) - MyUtility.byte2Int(HintNoMaleReproductive)) -> {
                            sheet.addCell(Label(cRep + dayInt - 1, rowID, "NP_NM", blueCellColor))
                        }
                        MyUtility.int2Byte(MyUtility.byte2Int(CensorRed) - MyUtility.byte2Int(HintNoMaleReproductive)) -> {
                            sheet.addCell(Label(cRep + dayInt - 1, rowID, "C_NM", redCellColor))
                        }
                        MyUtility.int2Byte(MyUtility.byte2Int(CensorBagged) - MyUtility.byte2Int(HintNoMaleReproductive)) -> {
                            sheet.addCell(Label(cRep + dayInt - 1, rowID, "CB_NM", redCellColor))
                        }
                        MyUtility.int2Byte(MyUtility.byte2Int(CensorDeadReproductive) - MyUtility.byte2Int(HintNoMaleReproductive)) -> {
                            sheet.addCell(Label(cRep + dayInt - 1, rowID, "CD_NM", redCellColor))
                        }
                        MyUtility.int2Byte(MyUtility.byte2Int(CensorExploded) - MyUtility.byte2Int(HintNoMaleReproductive)) -> {
                            sheet.addCell(Label(cRep + dayInt - 1, rowID, "CE_NM", redCellColor))
                        }
                        MyUtility.int2Byte(MyUtility.byte2Int(CensorLost) - MyUtility.byte2Int(HintNoMaleReproductive)) -> {
                            sheet.addCell(Label(cRep + dayInt - 1, rowID, "CL_NM", redCellColor))
                        }

                        MyUtility.int2Byte(MyUtility.byte2Int(ProgenyGreen) - MyUtility.byte2Int(HintFewMaleReproductive)) -> {
                            sheet.addCell(Label(cRep + dayInt - 1, rowID, "Re_FM", greenCellColor))
                        }
                        MyUtility.int2Byte(MyUtility.byte2Int(NoProgenyBlue) - MyUtility.byte2Int(HintFewMaleReproductive)) -> {
                            sheet.addCell(Label(cRep + dayInt - 1, rowID, "NP_FM", blueCellColor))
                        }
                        MyUtility.int2Byte(MyUtility.byte2Int(CensorRed) - MyUtility.byte2Int(HintFewMaleReproductive)) -> {
                            sheet.addCell(Label(cRep + dayInt - 1, rowID, "C_FM", redCellColor))
                        }
                        MyUtility.int2Byte(MyUtility.byte2Int(CensorBagged) - MyUtility.byte2Int(HintFewMaleReproductive)) -> {
                            sheet.addCell(Label(cRep + dayInt - 1, rowID, "CB_FM", redCellColor))
                        }
                        MyUtility.int2Byte(MyUtility.byte2Int(CensorDeadReproductive) - MyUtility.byte2Int(HintFewMaleReproductive)) -> {
                            sheet.addCell(Label(cRep + dayInt - 1, rowID, "CD_FM", redCellColor))
                        }
                        MyUtility.int2Byte(MyUtility.byte2Int(CensorExploded) - MyUtility.byte2Int(HintFewMaleReproductive)) -> {
                            sheet.addCell(Label(cRep + dayInt - 1, rowID, "CE_FM", redCellColor))
                        }
                        MyUtility.int2Byte(MyUtility.byte2Int(CensorLost) - MyUtility.byte2Int(HintFewMaleReproductive)) -> {
                            sheet.addCell(Label(cRep + dayInt - 1, rowID, "CL_FM", redCellColor))
                        }
                    }
                }
            }
            rowID += 3
        }
    }

    //----------------------------------------------------------------------------------------------
    private fun writeExcelLifeSpanAssayXX(expInfoForExcel: Experiment, mContext: Context, workbook: WritableWorkbook) {

        val sheet = workbook.createSheet(expInfoForExcel.type, 0)

        val expCellColor = WritableCellFormat(); expCellColor.setBackground(Colour.GRAY_25);
        expCellColor.setBorder(Border.ALL, BorderLineStyle.THIN)
        sheet.addCell(Label(0, 0, "Experiment: ${expInfoForExcel.name}", expCellColor))
        sheet.addCell(Label(0, 1, "Conducted at ${expInfoForExcel.startDate}", expCellColor))
        sheet.mergeCells(0, 0, 10, 0)
        sheet.mergeCells(0, 1, 10, 1)

        val myToProcessData = DataProcessor()
        val mConditionArray = myToProcessData.readAndCreateConditionClassInfo(expInfoForExcel.id!!, mContext)
        //----------------------------------------------
        val replicateColumn = 0
        val dayStopColumn = 1
        val censorBColumn = 2
        val cRep = 4
        var rowID = 4
        var dayCounter = 0

        val strainCellColor = WritableCellFormat(); strainCellColor.setBackground(Colour.YELLOW);
        strainCellColor.setBorder(Border.ALL, BorderLineStyle.THIN); strainCellColor.alignment = Alignment.CENTRE

        val lsCellColor = WritableCellFormat(); lsCellColor.setBackground(Colour.AQUA);
        lsCellColor.setBorder(Border.ALL, BorderLineStyle.THIN); lsCellColor.alignment = Alignment.CENTRE

        val conditionCellColor = WritableCellFormat(); //conditionCellColor.setBackground(Colour.YELLOW);
        conditionCellColor.setBorder(Border.ALL, BorderLineStyle.THIN); conditionCellColor.alignment = Alignment.CENTRE

        val dayCellColor = WritableCellFormat(); dayCellColor.setBackground(Colour.GRAY_25);
        dayCellColor.setBorder(Border.ALL, BorderLineStyle.THICK); dayCellColor.alignment = Alignment.CENTRE

        val greenCellColor = WritableCellFormat(); greenCellColor.setBackground(Colour.GREEN);
        greenCellColor.setBorder(Border.BOTTOM, BorderLineStyle.THIN); greenCellColor.alignment = Alignment.CENTRE

        val blueCellColor = WritableCellFormat(); blueCellColor.setBackground(Colour.BLUE);
        blueCellColor.setBorder(Border.ALL, BorderLineStyle.THIN); blueCellColor.alignment = Alignment.CENTRE

        val redCellColor = WritableCellFormat(); redCellColor.setBackground(Colour.RED);
        redCellColor.setBorder(Border.ALL, BorderLineStyle.THIN); redCellColor.alignment = Alignment.CENTRE

        sheet.setColumnView(0, 5); sheet.setColumnView(1, 5); sheet.setColumnView(2, 5); sheet.setColumnView(3, 4)
        for (mC in 1..mConditionArray.size) {
            mConditionArray[mC - 1] = myToProcessData.lifeSpanCalculatorXX(mConditionArray[mC - 1])
        }

        for (mC in 1..mConditionArray.size) {
            val flagRecord = BooleanArray(mConditionArray[mC - 1].numColumnTotal!!) { false }

            sheet.addCell(Label(cRep, rowID, mConditionArray[mC - 1].name!!, strainCellColor))
            val rowIDX1 = rowID
            rowID += 1
            sheet.addCell(Label(replicateColumn + 1, rowID, mConditionArray[mC - 1].name!!, strainCellColor))
            sheet.mergeCells(replicateColumn + 1, rowID, replicateColumn + 2, rowID)
            sheet.addCell(Label(cRep, rowID, "Life Span assay", conditionCellColor))
            val rowIDX2 = rowID
            rowID += 1
            sheet.addCell(Label(replicateColumn + 1, rowID, "LS", conditionCellColor))
            sheet.addCell(Label(replicateColumn + 2, rowID, "0/1", conditionCellColor))
            sheet.addCell(Label(replicateColumn, rowID, "No."))


            for (dayInt in 1..mConditionArray[mC - 1].numColumnTotal!!) {
                for (replicate in 1..mConditionArray[mC - 1].totalC!!) {
                    if (MyUtility.int2Byte(mConditionArray[mC - 1].dataMatrix!![replicate - 1][dayInt - 1]) != NoInputGray) {
                        flagRecord[dayInt - 1] = true
                    }
                }
            }

            dayCounter = 0
            for (dayInt in 1..mConditionArray[mC - 1].numColumnTotal!!) {
                if (flagRecord[dayInt - 1]) {
                    sheet.addCell(Label(cRep + dayCounter, rowID, "d$dayInt", dayCellColor))
                    sheet.setColumnView(cRep + dayCounter, 4)
                    dayCounter += 1
                }
            }
            sheet.mergeCells(cRep, rowIDX1, cRep + dayCounter - 1, rowIDX1)
            sheet.mergeCells(cRep, rowIDX2, cRep + dayCounter - 1, rowIDX2)

            for (replicate in 1..mConditionArray[mC - 1].totalC!!) {
                rowID += 1
                sheet.addCell(Label(replicateColumn, rowID, "$replicate"))
                sheet.addCell(Label(dayStopColumn, rowID, mConditionArray[mC - 1].dayStop?.get(replicate - 1)?.toString(), lsCellColor))
                if (mConditionArray[mC - 1].censorB?.get(replicate - 1)!!) {
                    sheet.addCell(Label(censorBColumn, rowID, 1.toString(), lsCellColor))
                } else {
                    sheet.addCell(Label(censorBColumn, rowID, 0.toString(), lsCellColor))
                }

                dayCounter = 0
                for (dayInt in 1..mConditionArray[mC - 1].numColumnTotal!!) {
                    if (flagRecord[dayInt - 1]) {
                        when (MyUtility.int2Byte(mConditionArray[mC - 1].dataMatrix!![replicate - 1][dayInt - 1])) {
                            AliveGreen -> {
                                sheet.addCell(Label(cRep + dayCounter, rowID, "Al", greenCellColor))
                            }
                            DeadBlue -> {
                                sheet.addCell(Label(cRep + dayCounter, rowID, "De", blueCellColor))
                            }
                            CensorRed -> {
                                sheet.addCell(Label(cRep + dayCounter, rowID, "C", redCellColor))
                            }
                            CensorBagged -> {
                                sheet.addCell(Label(cRep + dayCounter, rowID, "CB", redCellColor))
                            }
                            CensorDried -> {
                                sheet.addCell(Label(cRep + dayCounter, rowID, "CD", redCellColor))
                            }
                            CensorExploded -> {
                                sheet.addCell(Label(cRep + dayCounter, rowID, "CE", redCellColor))
                            }
                            CensorLost -> {
                                sheet.addCell(Label(cRep + dayCounter, rowID, "CL", redCellColor))
                            }
                            CensorUnidentified -> {
                                sheet.addCell(Label(cRep + dayCounter, rowID, "CU", redCellColor))
                            }
                        }
                        dayCounter += 1
                    }
                }
            }
            rowID += 3
        }
    }
    //----------------------------------------------------------------------------------------------
}