package com.example.swiperawesome

class Condition() {

    var name:String? = null
    var type:String? = null
    var numColumnTotal:Int? = null
    var startRange:Int? = null
    var endRange:Int? = null
    var totalC:Int? = null
    var dataMatrix: Array<IntArray>? = null
    var dataMatrix3dim: Array<Array<IntArray>>? = null
    var numDimMatrixData: Int? = null
    var dayStop:Array<Int?>? = null
    var censorB:Array<Boolean?>? = null
    var survivalXAxis:Array<Float?>? = null
    var survivalYAxis:Array<Float?>? = null
    var alivePerDay :IntArray? = null
    var deadPerDay:IntArray? = null
    var censorPerDay:IntArray? = null
    var choiceIndex:FloatArray? = null
    var candleStickHighY:Float? = null
    var candleStickLowY:Float? = null
    var candleStickErrorH:Float? = null
    var candleStickErrorL:Float? = null
    var broodSizePerDay:FloatArray? = null
    var unhatchedEggs:FloatArray? = null
    var unfertilizedOocytes:FloatArray? = null

    constructor(my_name:String, myType:String, myNumColumnTotal:Int, myStartRange:Int, myEndRange:Int,
                myTotalChamberPerCondition:Int, myDataMatrix:Array<IntArray>, myDataMatrix3dim: Array<Array<IntArray>>,
                myDayStp:Array<Int?>, myCensor:Array<Boolean?>, myChoiceIndex:FloatArray, myCandleStickHighY:Float,
                myCandleStickLowY:Float, myCandleStickErrorH: Float, myCandleStickErrorL:Float, myNumDimMatrixData:Int,
                myBroodSizePerDay:FloatArray, myUnhatchedEggs:FloatArray, myUnfertilizedOocytes:FloatArray,mySurvivalXAxis:Array<Float?>,
                mySurvivalYAxis:Array<Float?>, myAlivePerDay:IntArray, myDeadPerDay:IntArray,
                myCensorPerDay:IntArray):this(){

        this.name = my_name
        this.type = myType
        this.numColumnTotal = myNumColumnTotal
        this.startRange = myStartRange
        this.endRange = myEndRange
        this.totalC = myTotalChamberPerCondition
        this.dataMatrix = myDataMatrix
        this.dataMatrix3dim = myDataMatrix3dim
        this.numDimMatrixData = myNumDimMatrixData
        this.dayStop = myDayStp
        this.censorB = myCensor
        this.survivalXAxis = mySurvivalXAxis
        this.survivalYAxis = mySurvivalYAxis
        this.alivePerDay = myAlivePerDay
        this.deadPerDay = myDeadPerDay
        this.censorPerDay = myCensorPerDay
        this.choiceIndex = myChoiceIndex
        this.candleStickHighY = myCandleStickHighY
        this.candleStickLowY = myCandleStickLowY
        this.candleStickErrorH = myCandleStickErrorH
        this.candleStickErrorL = myCandleStickErrorL
        this.broodSizePerDay = myBroodSizePerDay
        this.unhatchedEggs = myUnhatchedEggs
        this.unfertilizedOocytes = myUnfertilizedOocytes
    }
}