package com.example.swiperawesome

class Chamber(){

    var id:Int? = null
    var status:Byte? = null
    var auxiliaryStatus:Byte? = null
    var chamberColorString:String? = null
    var chamberShape:Int? = null
    var progenyCount:Int? = null
    var type:String? = null

    constructor(myID:Int, myStatus:Byte, myAuxiliaryStatus:Byte, myChamberColorString: String, myChamberShape: Int, myProgenyCount:Int, mType:String):this(){
        this.id = myID
        this.status = myStatus
        this.chamberColorString = myChamberColorString
        this.chamberShape = myChamberShape
        this.progenyCount = myProgenyCount
        this.auxiliaryStatus = myAuxiliaryStatus
        this.type = mType
    }
}