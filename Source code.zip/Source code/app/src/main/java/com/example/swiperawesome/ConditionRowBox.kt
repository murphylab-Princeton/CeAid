package com.example.swiperawesome

import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

class ConditionRowBox() {
    var parent:LinearLayout? = null
    var name:EditText? = null
    var num:EditText? = null
    var start:TextView? = null
    var end:TextView? = null

    constructor(myParent:LinearLayout, myName:EditText, myNum:EditText, myStart:TextView, myEnd:TextView): this() {
        this.parent = myParent
        this.name = myName
        this.num = myNum
        this.start = myStart
        this.end = myEnd
    }
}