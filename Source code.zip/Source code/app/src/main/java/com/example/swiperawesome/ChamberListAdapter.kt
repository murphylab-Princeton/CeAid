package com.example.swiperawesome

import android.content.Context
import android.content.Intent
import android.content.res.Resources
import android.graphics.Paint
import android.os.Build
import android.view.*
import android.widget.*
import androidx.annotation.RequiresApi
import androidx.recyclerview.widget.RecyclerView

class ChamberListAdapter (val thisExpID:Int, private val chamberList: ArrayList<Chamber>,
                          val galleryContext: Context): RecyclerView.Adapter<ChamberListAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChamberListAdapter.ViewHolder {
        // create our view from our .xlm file
        val galleryView = LayoutInflater.from(galleryContext).inflate(R.layout.gallery_item_recycler,parent, false)
        return ViewHolder(galleryView)
    }
    //----------------------------------------------------------------------------------------------
    override fun getItemCount(): Int {return chamberList.size}
    //----------------------------------------------------------------------------------------------
    override fun onBindViewHolder(holder: ChamberListAdapter.ViewHolder, myPosition: Int) {
        holder.bindMyViews(chamberList[myPosition])
    }
    //----------------------------------------------------------------------------------------------
    inner class ViewHolder(myItemView: View): RecyclerView.ViewHolder(myItemView), View.OnClickListener {
        private var myChamberClicker = myItemView.findViewById(R.id.chamberIDgallery) as TextView
        //------------------------------------------------------------------------------------------
        @RequiresApi(Build.VERSION_CODES.M)
        fun bindMyViews(myChamber:Chamber){

            val myChamberID = MyUtility.findProperNumberUsingProperNumberingStyle(galleryContext, thisExpID,myChamber.id!!)

            when (myChamber.type) {
                galleryContext.getString(R.string.RS_assay) -> {
                    myChamberClicker.text = myChamberID.toString();myChamberClicker.textSize = 17f
                    myChamber.status = MyUtility.modifyStatusChamberReproductiveAssay(myChamber.status!!)
                }
                galleryContext.getString(R.string.ChoiceAssay) -> {
                    if (myChamber.status!!.toInt()<MaxOfAvailableIntInByteArray.toInt() && myChamber.auxiliaryStatus!!.toInt()<MaxOfAvailableIntInByteArray.toInt()) {
                        myChamberClicker.text = "#${myChamberID}\n${MyUtility.byte2Int(myChamber.status!!)}|${MyUtility.byte2Int(myChamber.auxiliaryStatus!!)}"
                        myChamberClicker.textSize = 15f
                    } else {
                        myChamberClicker.text = "#${myChamberID}"
                        myChamberClicker.textSize = 17f
                    }
                }
                galleryContext.getString(R.string.ProgenyAssay) -> {
                    if (myChamber.status!!.toInt()<MaxOfAvailableIntInByteArray.toInt()) {
                            myChamberClicker.text = "#${myChamberID}\n${MyUtility.byte2Int(myChamber.status!!)}"
                            myChamberClicker.textSize = 15f
                    } else {
                        myChamberClicker.text = "#${myChamberID}"
                        myChamberClicker.textSize = 17f
                    }
                }
                galleryContext.getString(R.string.LS_assayXX) -> {myChamberClicker.text = myChamberID.toString();myChamberClicker.textSize = 17f}
                galleryContext.getString(R.string.LS_assay) -> {
                    if (myChamber.status!!.toInt()<MaxOfAvailableIntInByteArray.toInt()) {
                        myChamberClicker.text = "#${myChamberID}\n${MyUtility.byte2Int(myChamber.status!!)}"
                        myChamberClicker.textSize = 15f
                    } else {
                        myChamberClicker.text = "#${myChamberID}"
                        myChamberClicker.textSize = 17f
                    }
                }
            }
            myChamberClicker.paintFlags = myChamberClicker.paintFlags or Paint.UNDERLINE_TEXT_FLAG
            //val conditionNum = MyUtility.findConditionNumberForConditionColor(galleryContext, thisExpID, myChamber.id!!)
            //myChamberClicker.setTextColor(galleryContext.getColor(COLORS_FOR_TEXT[conditionNum-1]))
            myChamberClicker.setTextColor(galleryContext.getColor(R.color.Black))


            myChamberClicker.setOnClickListener(this)
            when (myChamber.status) {
                CensorBagged, CensorDried, CensorExploded, CensorLost, CensorUnidentified, CensorRed, CensorDeadReproductive -> {MyUtility.makeShapeRed(myChamberClicker, galleryContext)}
                ProgenyGreen -> {MyUtility.makeShapeGreen(myChamberClicker, galleryContext)}
                NoProgenyBlue -> {MyUtility.makeShapeBlue(myChamberClicker, galleryContext)}
                NoInputGray -> {MyUtility.makeShapeGray(myChamberClicker, galleryContext)}
                AliveGreen -> {MyUtility.makeShapeGreen(myChamberClicker, galleryContext)}
                DeadBlue -> {MyUtility.makeShapeBlue(myChamberClicker, galleryContext)}
                else -> {MyUtility.makeShapeBlue(myChamberClicker, galleryContext)}
            }
            MyUtility.backGroundIconFinder(myChamberClicker, myChamber.chamberShape!!)
        }
        //------------------------------------------------------------------------------------------
        override fun onClick(v_row: View?) {

            val myTestDataHandler = ExpDatabaseHandler(galleryContext)
            val myExpClass = myTestDataHandler.readOneExpInfo(thisExpID)
            var myIntent:Intent?=null
            when (myExpClass.type) {
                galleryContext.getString(R.string.LS_assay) -> {myIntent = Intent(galleryContext, ActivityLifeSpanFeeder::class.java)}
                galleryContext.getString(R.string.LS_assayXX) -> {myIntent = Intent(galleryContext, ActivityLifeSpanFeederXX::class.java)}
                galleryContext.getString(R.string.RS_assay) -> {myIntent = Intent(galleryContext, ActivityDataFeeder::class.java)}
                galleryContext.getString(R.string.ProgenyAssay) -> {myIntent = Intent(galleryContext, ActivityProgenyCountFeeder::class.java)}
                galleryContext.getString(R.string.ChoiceAssay) -> {myIntent = Intent(galleryContext, ActivityChoiceAssay::class.java)}
            }
            myIntent!!.putExtra("KeyForExpID", thisExpID)
            myIntent.putExtra("KeyForChamberID", adapterPosition + 1)
            galleryContext.startActivity(myIntent)
        }
        //------------------------------------------------------------------------------------------
    }
}