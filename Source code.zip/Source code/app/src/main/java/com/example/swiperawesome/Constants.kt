package com.example.swiperawesome
//--------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------
const val DATABASE_VERSION :Int = 1
const val DATABASE_NAME:String = "expINFO.db"
const val TABLE_NAME:String = "expTable"
const val KEY_ID:String="id"
const val KEY_EXP_NAME:String ="name"
const val KEY_EXP_TYPE:String ="AssayType"
const val KEY_EXP_DATE:String="startDate"
const val KEY_EXP_Column_POINTER:String = "dayPointer"
const val KEY_EXP_NUMBERING_STYLE_POINTER:String = "numberingStyle"
const val LS_DAY_X:String = "LSXX_alive_day"
const val LS1_DAY_X:String = "LS_alive_day"
const val LS2_DAY_X:String = "LS_dead_day"
const val LS3_DAY_X:String = "LS_censor_day"
const val RS_DAY_X:String = "RS_day"
const val RS_COUNT_DAY_X:String = "RS_count_day"
const val RS_UNHATCHED_DAY_X:String = "RS_unhatched_day"
const val RS_UNFERTILIZED_DAY_X:String = "RS_unfertilized_day"
const val CHOICE_ASSAY_PREFERENCE_X:String = "ChoiceAssay_preference"
const val CONDITION_NAME_X:String = "conditionName"
const val CONDITION_RANGE_X:String = "conditionRange"
//--------------------------------------------------------------------------------------------------
const val TOTAL_NUM_CONDITIONS:Int = 30
const val NUMBER_OF_DAYS_LS:Int = 70
const val NUMBER_OF_DAYS_RS:Int = 15
const val NUMBER_OF_DAYS_RS_COUNT:Int = 15
const val NUMBER_OF_Column_CHOICE_ASSAY:Int = 2
const val MY_DATA_CHECK_CODE:Int = 1234
const val NUM_WORMS_PER_LS_PLATE = 30
const val NUM_UNHATCHED_UNFERTILIZED_PER_PROGENY_PLATE = 25
//--------------------------------------------------------------------------------------------------
const val TextToSpeechSpeedValue = 1.5f
var myBooleanMute = false
//--------------------------------------------------------------------------------------------------
// max should be 127
const val NoInputGray:Byte = 127.toByte()
const val ProgenyGreen:Byte = 126.toByte()
const val NoProgenyBlue:Byte = 125.toByte()
const val AliveGreen:Byte = 124.toByte()
const val DeadBlue:Byte = 123.toByte()
const val CensorRed:Byte = 122.toByte()
const val CensorBagged:Byte = 121.toByte()
const val CensorDried:Byte = 120.toByte()
const val CensorExploded:Byte = 119.toByte()
const val CensorLost:Byte = 118.toByte()
const val CensorUnidentified:Byte = 117.toByte()
const val CensorDeadReproductive:Byte = 116.toByte()
const val MaxOfAvailableIntInByteArray = 114.toByte()
const val HintNoMaleReproductive:Byte = 50.toByte()
const val HintFewMaleReproductive:Byte = 100.toByte()
const val MyByteTransferValue = 128
//--------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------
val MY_DRAWABLE_LIST = arrayOf(
    R.drawable.ic_backgr1,  R.drawable.ic_backgr2,  R.drawable.ic_backgr3,  R.drawable.ic_backgr4,
    R.drawable.ic_backgr5,  R.drawable.ic_backgr6,  R.drawable.ic_backgr7,  R.drawable.ic_backgr8,

    R.drawable.ic_backgr1,  R.drawable.ic_backgr2,  R.drawable.ic_backgr3,  R.drawable.ic_backgr4,
    R.drawable.ic_backgr5,  R.drawable.ic_backgr6,  R.drawable.ic_backgr7,  R.drawable.ic_backgr8,

    R.drawable.ic_backgr1,  R.drawable.ic_backgr2,  R.drawable.ic_backgr3,  R.drawable.ic_backgr4,
    R.drawable.ic_backgr5,  R.drawable.ic_backgr6,  R.drawable.ic_backgr7,  R.drawable.ic_backgr8
)
//--------------------------------------------------------------------------------------------------
val COLORS_FOR_TEXT= arrayOf(
    R.color.Black,      R.color.Blue,        R.color.Red,      R.color.LimeGreen,   R.color.LawnGreen,

    R.color.Black,          R.color.DarkViolet,    R.color.DarkBlue,        R.color.DarkRed,
    R.color.DarkGreen,      R.color.DarkOrange,    R.color.DarkSlateGray,   R.color.DarkCyan,

    R.color.Black,          R.color.DarkViolet,    R.color.DarkBlue,        R.color.DarkRed,
    R.color.DarkGreen,      R.color.DarkOrange,    R.color.DarkSlateGray,   R.color.DarkCyan
    )
//--------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------
val COLORS_FOR_PLOT = arrayOf(R.color.Gray, R.color.Red, R.color.Blue, R.color.Green, R.color.Magenta,
    R.color.Brown, R.color.Orange, R.color.Yellow, R.color.Chocolate, R.color.Black)
//--------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------


