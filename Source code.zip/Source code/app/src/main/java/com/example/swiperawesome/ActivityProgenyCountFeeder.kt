package com.example.swiperawesome

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Paint
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.text.Editable
import android.text.TextWatcher
import android.view.Menu
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Switch
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.android.synthetic.main.activity_progeny_count_feeder.*
import kotlinx.android.synthetic.main.keyboard.*
import kotlinx.android.synthetic.main.switch_item.view.*
import java.util.*

class ActivityProgenyCountFeeder : AppCompatActivity() {
    //----------------------------------------------------------------------------------------------
    private var mTts: TextToSpeech? = null
    var sr: SpeechRecognizer? = null
    var myExpClass:Experiment? = null
    var thisExpID:Int? = null
    var columnID:Int? = null
    var chamberID:Int? = null
    var idArrayList:Int? = null
    var myTestDataHandler:ExpDatabaseHandler? = null
    private var totNumChambers:Int? = null
    private var foundExperimentDayNum:Int? = null
    var myToasterObject: Toast? = null
    private var myShapeOfChambersArray:Array<Int?>? = null
    private var textArrayOfConditionName:Array<String?>? = null
    //----------------------------------------------------------------------------------------------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_progeny_count_feeder)
        //----------------------------------------
        val checkIntent = Intent()
        checkIntent.action = TextToSpeech.Engine.ACTION_CHECK_TTS_DATA
        startActivityForResult(checkIntent, MY_DATA_CHECK_CODE)
        //-----------------------------------------
        this.thisExpID = intent.extras?.get("KeyForExpID") as Int
        this.chamberID = intent.extras?.get("KeyForChamberID") as Int
        myTestDataHandler = ExpDatabaseHandler(this)
        myExpClass = myTestDataHandler!!.readOneExpInfo(thisExpID!!)
        this.columnID = myExpClass!!.dayPointer
        this.totNumChambers = myExpClass!!.testConditionRange.last().toInt()
        this.foundExperimentDayNum = MyUtility.findNumberOfColumns(this, myExpClass!!.type!!)
        myShapeOfChambersArray = MyUtility.shapeOfChamberIdentifier(myExpClass!!)
        textArrayOfConditionName = MyUtility.textOfConditionIdentifier(myExpClass!!)
        listenerInitialization()
        initialStatusDetermination()
        disappearUnhatchedUnfertilized()
        //----------------------------------------
        val ic = hiddenEditText.onCreateInputConnection(EditorInfo())
        appKeyboard.setInputConnection(ic)
        button_enter.setOnClickListener {if (hiddenEditText.text.toString()!="") { val myValue = hiddenEditText.text.toString(); saveInfoGoToNextChamber(myValue.toInt()) }}
        hiddenEditText.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                if (s.length<4) {
                    if(s.toString()!="") reportNumProgenyTextView(s.toString().toInt())
                    else reportEmptyTextView()
                } else { button_delete.performClick()}
            }
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}
            override fun afterTextChanged(s: Editable) {if (hiddenEditText.text.toString()!="") {MyUtility.makeShapeOrange(button_enter, applicationContext)}}
        })
        //------------------------------------------------------------------------------------------
        seekBarLeftProgenyCount.setOnProgressChangeListener { progressValue -> updateUnhatchedInfoBox(progressValue)}
        seekBarLeftProgenyCount.setOnReleaseListener { progressValue ->  saveUnhatchedForProgenyAssay(progressValue)}
        seekBarRightProgenyCount.setOnProgressChangeListener { progressValue -> updateUnfertilizedInfoBox(progressValue) }
        seekBarRightProgenyCount.setOnReleaseListener { progressValue ->  saveUnfertilizedForProgenyAssay(progressValue) }
        //------------------------------------------------------------------------------------------
        viewForProgenyCount.setOnTouchListener(object : OnSwipeTouchListener(this@ActivityProgenyCountFeeder) {
            //---------------------------------------------
            override fun onSwipeDown() {gotoPreviousChamber()}
            override fun onSwipeUp() {gotoNextChamber()}
            override fun onSwipeLeft() {goToNextColumn()}
            override fun onSwipeRight() {goToPreviousColumn()}
            override fun onDoubleTouch() {sr!!.startListening(intent)}
            override fun onLongTouch() {userInputCensored()}
            override fun onSingleTouch() {
                if (button_enter.text== "Tap on Screen" ) {
                    saveInfoGoToNextChamber(textViewForProgenyAssay.text.toString().toInt())
                    MyUtility.makeShapeGray(button_enter, applicationContext)
                    button_enter.text = "ENTER"
                }
            }
            //---------------------------------------------
        })
    }
    //----------------------------------------------------------------------------------------------
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_progeny_count_feeder, menu)
        val myAccessibleSwitch = menu!!.findItem(R.id.myAppSwitchProgeny).actionView.sallySwitchBox as Switch
        myAccessibleSwitch.setOnCheckedChangeListener { _, _ ->
            if (myAccessibleSwitch.isChecked) { showManualUnhatchedUnfertilized()}
            else { disappearUnhatchedUnfertilized()}
        }
        return true
    }
    //----------------------------------------------------------------------------------------------
    private fun initialStatusDetermination() {
        val myTestDataHandler = ExpDatabaseHandler(this@ActivityProgenyCountFeeder)
        val arrayListData = myTestDataHandler.readByteArrayAtColumns(thisExpID!!,columnID!!)
        val progenyNumAtDayX = MyUtility.byte2Int(arrayListData!![0][chamberID!!-1])
        val unhatchedNumAtDayX = MyUtility.byte2Int(arrayListData[1][chamberID!!-1])
        val unFertilizedNumAtDayX = MyUtility.byte2Int(arrayListData[2][chamberID!!-1])
        getSeekBarsProgressMaxValues()
        ShowDayAtProgenyAssay.text = "Day $columnID"
        ShowDayAtProgenyAssay.paintFlags =ShowDayAtProgenyAssay.paintFlags or Paint.UNDERLINE_TEXT_FLAG
        ShowConditionAtProgenyCount.text = textArrayOfConditionName?.get(chamberID!!-1)!!
        MyUtility.backGroundIconFinder(textViewForProgenyAssay, myShapeOfChambersArray?.get(chamberID!!-1)!!)
        hiddenEditText.setText("")
        when(progenyNumAtDayX) {
            MyUtility.byte2Int(CensorRed) -> {MyUtility.makeBoxRed(textViewForProgenyAssay,applicationContext);
                val updatedChamberID = MyUtility.findProperNumberUsingProperNumberingStyle(this, thisExpID!!, chamberID!!)
                ShowNumberChamberAtProgenyAssay.text = "#$updatedChamberID"; textViewForProgenyAssay.text = "Censored"}
            MyUtility.byte2Int(NoInputGray) -> {MyUtility.makeBoxGray(textViewForProgenyAssay,applicationContext); reportEmptyTextView()}
            else -> {MyUtility.makeBoxBlue(textViewForProgenyAssay,applicationContext); reportNumProgenyTextView(progenyNumAtDayX)}
        }
        when(unhatchedNumAtDayX) {
            MyUtility.byte2Int(CensorRed) -> {MyUtility.makeBoxRed(myLeftProgenyAssayInfoBox,applicationContext); myLeftProgenyAssayInfoBox.text = "Censored"; seekBarLeftProgenyCount.progress=0}
            MyUtility.byte2Int(NoInputGray) -> {MyUtility.makeBoxGray(myLeftProgenyAssayInfoBox,applicationContext); myLeftProgenyAssayInfoBox.text = "-?- Unhatched eggs"; seekBarLeftProgenyCount.progress=0}
            else -> {MyUtility.makeBoxYellow(myLeftProgenyAssayInfoBox,applicationContext); updateUnhatchedInfoBox(unhatchedNumAtDayX); seekBarLeftProgenyCount.progress=unhatchedNumAtDayX}
        }
        when(unFertilizedNumAtDayX) {
            MyUtility.byte2Int(CensorRed) -> {MyUtility.makeBoxRed(myRightProgenyAssayInfoBox,applicationContext); myRightProgenyAssayInfoBox.text = "Censored"; seekBarRightProgenyCount.progress=0}
            MyUtility.byte2Int(NoInputGray) -> {MyUtility.makeBoxGray(myRightProgenyAssayInfoBox,applicationContext); myRightProgenyAssayInfoBox.text = "-?- Unfertilized oocytes"; seekBarRightProgenyCount.progress=0}
            else -> {MyUtility.makeBoxGreen(myRightProgenyAssayInfoBox,applicationContext); updateUnfertilizedInfoBox(unFertilizedNumAtDayX); seekBarRightProgenyCount.progress=unFertilizedNumAtDayX}
        }
    }
    //----------------------------------------------------------------------------------------------
    inner class TextListener: RecognitionListener {
        override fun onReadyForSpeech(params: Bundle) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray) {}
        override fun onEndOfSpeech() {}
        override fun onError(error: Int) { textViewForProgenyAssay.text = "Err" }
        override fun onPartialResults(partialResults: Bundle) {}
        override fun onEvent(eventType: Int, params: Bundle) {}
        //--------------------------------------------
        override fun onResults(results: Bundle) {
            val data: ArrayList<String>? = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)

            var foundNum:String? = null
            outer@ for (myString in data!!.iterator()) {
                if (myString.length<4) {
                    for (i in myString.indices) {
                        if (!myString[i].isDigit()) break
                        if (i==myString.length-1){
                            foundNum = myString
                            break@outer
                        }
                    }
                }
            }
            if (foundNum!=null) {afterVoiceInputForProgenyAssay(foundNum.toInt()) }
            else {textViewForProgenyAssay.text = "Err"; speakUp("Try again or use Numpad");toastMe("Try again or use Numpad")}
        }
        //--------------------------------------------
    }
    //----------------------------------------------------------------------------------------------
    private fun updateStatus (dataByte:Byte) {myTestDataHandler!!.updateOneCellAtColumns(thisExpID!!, columnID!!, chamberID!!, dataByte, idArrayList!!)}
    private fun speakUp (sayThis:String) {
        if (!myBooleanMute) {mTts!!.speak(sayThis, TextToSpeech.QUEUE_FLUSH, null, null)}
    }
    private fun toastMe(useThis:String) {myToasterObject?.cancel()
        myToasterObject = Toast.makeText(this@ActivityProgenyCountFeeder, useThis, Toast.LENGTH_SHORT)
        myToasterObject?.show()}
    private fun afterVoiceInputForProgenyAssay(voiceNum:Int) {
        idArrayList = 1
        reportNumProgenyTextView(voiceNum)
        val updatedChamberID = MyUtility.findProperNumberUsingProperNumberingStyle(this, thisExpID!!, chamberID!!)
        speakUp("$voiceNum progeny in $updatedChamberID")
        MyUtility.makeBoxBlue(textViewForProgenyAssay,applicationContext)
        MyUtility.makeShapeOrange(button_enter, applicationContext)
        button_enter.text = "Tap on Screen"
    }
    private fun saveInfoGoToNextChamber(voiceNum:Int) {
        idArrayList = 1
        if(voiceNum<MyUtility.byte2Int(MaxOfAvailableIntInByteArray)) {
            updateStatus(MyUtility.int2Byte(voiceNum))
            gotoNextChamber()
            MyUtility.makeBoxGray(button_enter, applicationContext)
            button_enter.text = "ENTER"
        }
        else {
            speakUp("max is " + MyUtility.byte2Int(MaxOfAvailableIntInByteArray))
            toastMe("Data not stored!")
            gotoNextChamber()
            gotoPreviousChamber()
            hiddenEditText.setText("")
            MyUtility.makeBoxGray(button_enter, applicationContext)
            button_enter.text = "ENTER"
            MyUtility.makeBoxGray(textViewForProgenyAssay, applicationContext)
        }
    }

    private fun saveUnhatchedForProgenyAssay(voiceNum:Int) {
        idArrayList = 2
        if(voiceNum<MyUtility.byte2Int(MaxOfAvailableIntInByteArray)) {
            updateUnhatchedInfoBox(voiceNum)
            val updatedChamberID = MyUtility.findProperNumberUsingProperNumberingStyle(this, thisExpID!!, chamberID!!)
            speakUp("$voiceNum unhatched in $updatedChamberID")
            updateStatus(MyUtility.int2Byte(voiceNum))
            MyUtility.makeBoxYellow(myLeftProgenyAssayInfoBox,applicationContext)
        }
        else {speakUp("max is " + MyUtility.byte2Int(MaxOfAvailableIntInByteArray)); toastMe("Data not stored")}
    }
    private fun saveUnfertilizedForProgenyAssay(voiceNum:Int) {
        idArrayList = 3
        if(voiceNum<MyUtility.byte2Int(MaxOfAvailableIntInByteArray)) {
            updateUnfertilizedInfoBox(voiceNum)
            val updatedChamberID = MyUtility.findProperNumberUsingProperNumberingStyle(this, thisExpID!!, chamberID!!)
            speakUp("$voiceNum unfertilized in $updatedChamberID")
            updateStatus(MyUtility.int2Byte(voiceNum))
            MyUtility.makeBoxGreen(myRightProgenyAssayInfoBox,applicationContext)
        }
        else {speakUp("max is " + MyUtility.byte2Int(MaxOfAvailableIntInByteArray)); toastMe("Data not stored")}
    }
    fun userInputCensored(){
        idArrayList=1; updateStatus(CensorRed)
        idArrayList=2; updateStatus(CensorRed)
        idArrayList=3; updateStatus(CensorRed)
        MyUtility.makeBoxRed(textViewForProgenyAssay,applicationContext)
        MyUtility.makeBoxRed(myLeftProgenyAssayInfoBox,applicationContext)
        MyUtility.makeBoxRed(myRightProgenyAssayInfoBox,applicationContext)
        val updatedChamberID = MyUtility.findProperNumberUsingProperNumberingStyle(this, thisExpID!!, chamberID!!)
        speakUp("$updatedChamberID censored")
    }
    fun gotoNextChamber() {
        if (chamberID!!<totNumChambers!!) {
            chamberID = chamberID!!.plus(1)
            initialStatusDetermination()
            val updatedChamberID = MyUtility.findProperNumberUsingProperNumberingStyle(this, thisExpID!!, chamberID!!)
            speakUp("$updatedChamberID ready")
        } else {
            toastMe("Next worm Not available!")
        }
    }
    fun gotoPreviousChamber() {
        if (chamberID!!>1) {
            chamberID = chamberID!!.minus(1)
            initialStatusDetermination()
            val updatedChamberID = MyUtility.findProperNumberUsingProperNumberingStyle(this, thisExpID!!, chamberID!!)
            speakUp("$updatedChamberID ready")
        } else {
            toastMe("Previous worm Not available!")
        }
    }
    fun goToPreviousColumn() {
        if (columnID!!>1){
            columnID = columnID!!.minus(1)
            initialStatusDetermination()
            val updatedChamberID = MyUtility.findProperNumberUsingProperNumberingStyle(this, thisExpID!!, chamberID!!)
            mTts!!.speak("$updatedChamberID at day $columnID ready", TextToSpeech.QUEUE_FLUSH, null, null)
        } else {
            toastMe("Previous day not available!")
        }
    }
    fun goToNextColumn() {
        if (columnID!!<foundExperimentDayNum!!){
            columnID = columnID!!.plus(1)
            initialStatusDetermination()
            val updatedChamberID = MyUtility.findProperNumberUsingProperNumberingStyle(this, thisExpID!!, chamberID!!)
            speakUp("$updatedChamberID at day $columnID ready")
        } else {
            toastMe("Next day not available!")
        }
    }
    private fun reportNumProgenyTextView(value:Int) {
        val updatedChamberID = MyUtility.findProperNumberUsingProperNumberingStyle(this, thisExpID!!, chamberID!!)
        ShowNumberChamberAtProgenyAssay.text = "#$updatedChamberID";
        textViewForProgenyAssay.text = "$value"
    }
    private fun reportEmptyTextView(){
        val updatedChamberID = MyUtility.findProperNumberUsingProperNumberingStyle(this, thisExpID!!, chamberID!!)
        ShowNumberChamberAtProgenyAssay.text = "#$updatedChamberID";
        textViewForProgenyAssay.text = "-?-"
    }
    private fun updateUnhatchedInfoBox(value:Int) {
        myLeftProgenyAssayInfoBox.text = "$value Unhatched eggs"
    }
    private fun updateUnfertilizedInfoBox(value:Int) {
        myRightProgenyAssayInfoBox.text = "$value Unfertilized oocytes"
    }
    //---------------------------------------------
    private fun listenerInitialization() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)!= PackageManager.PERMISSION_GRANTED) {
            if (!ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.RECORD_AUDIO)) {
                ActivityCompat.requestPermissions(this, arrayOf<String>(Manifest.permission.RECORD_AUDIO),527)
            }
        }
        sr = SpeechRecognizer.createSpeechRecognizer(this)
        sr?.setRecognitionListener(TextListener())
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        intent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, "voice.recognition.test")
        intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 50)
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
    }
    //----------------------------------------------------------------------------------------------
    override fun onDestroy() {
        mTts!!.stop()
        mTts!!.shutdown()
        if (sr!=null) sr!!.destroy()
        super.onDestroy()
    }
    //----------------------------------------------------------------------------------------------
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == MY_DATA_CHECK_CODE) {
            if (resultCode == TextToSpeech.Engine.CHECK_VOICE_DATA_PASS) {

                mTts = TextToSpeech(this@ActivityProgenyCountFeeder, TextToSpeech.OnInitListener { })
                mTts!!.language = Locale.US
                mTts!!.setSpeechRate(TextToSpeechSpeedValue)
            } else {
                toastMe("Missing Text to Speech Package")
                val installIntent = Intent()
                installIntent.action = TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA
                startActivity(installIntent)
            }
        }
    }
    //----------------------------------------------------------------------------------------------
    private fun showManualUnhatchedUnfertilized() {
        initialStatusDetermination()
        myLeftProgenyAssayInfoBox.visibility = View.VISIBLE
        myRightProgenyAssayInfoBox.visibility = View.VISIBLE
        seekBarLeftProgenyCount.visibility = View.VISIBLE
        seekBarRightProgenyCount.visibility = View.VISIBLE
    }
    //----------------------------------------------------------------------------------------------
    private fun disappearUnhatchedUnfertilized() {
        initialStatusDetermination()
        myLeftProgenyAssayInfoBox.visibility = View.GONE
        myRightProgenyAssayInfoBox.visibility = View.GONE
        seekBarLeftProgenyCount.visibility = View.GONE
        seekBarRightProgenyCount.visibility = View.GONE
    }
    //----------------------------------------------------------------------------------------------
    private fun getSeekBarsProgressMaxValues() {
        val myNameStringArray = myExpClass!!.name!!.split(",", ignoreCase = true, limit = 0)
        val maxValueOfSeekBars = if (myNameStringArray.size>1) { myNameStringArray.last().toInt() }
        else {NUM_UNHATCHED_UNFERTILIZED_PER_PROGENY_PLATE}
        seekBarLeftProgenyCount.maxValue = maxValueOfSeekBars
        seekBarRightProgenyCount.maxValue = maxValueOfSeekBars
    }
    //----------------------------------------------------------------------------------------------
}
