package com.example.swiperawesome

class LifeSpanData() {
    var alive:ByteArray? = null
    var dead:ByteArray? = null
    var censored:ByteArray? = null

    constructor(myAlive:ByteArray, myDead:ByteArray, myCensored:ByteArray):this() {

        this.alive = myAlive
        this.dead = myDead
        this.censored = myCensored

    }
}