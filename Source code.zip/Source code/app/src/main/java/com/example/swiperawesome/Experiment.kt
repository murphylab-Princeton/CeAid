package com.example.swiperawesome

class Experiment() {
    var id:Int? = null
    var name:String? = null
    var startDate:String? = null
    var dayPointer:Int? = null
    var numberingStyle:Int? = null
    var type:String? = null
    var testConditionName:MutableList<String> = ArrayList()
    var testConditionRange:MutableList<Int> = ArrayList()

    constructor(myAssayName: String, myAssayStartDate:String, myAssayID:Int, myDayPointer :Int,
                myNumberingStyle:Int ,myType: String, myTestConditionName:MutableList<String>,
                myTestConditionRange:MutableList<Int>):this(){
        this.id = myAssayID
        this.name = myAssayName
        this.startDate = myAssayStartDate
        this.dayPointer = myDayPointer
        this.numberingStyle = myNumberingStyle
        this.type = myType
        this.testConditionName = myTestConditionName
        this.testConditionRange = myTestConditionRange
    }
}