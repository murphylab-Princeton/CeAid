package com.example.swiperawesome

import android.content.Intent
import android.graphics.Paint
import android.os.Build
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.TextToSpeech.OnInitListener
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_data_feeder.*
import java.util.*

class ActivityDataFeeder : AppCompatActivity() {

    //----------------------------------------------------------------------------------------------
    private var mTts: TextToSpeech? = null
    var myExpClass:Experiment? = null
    var thisExpID:Int? = null
    var columnID:Int? = null
    var chamberID:Int? = null
    var dayToCheck:Int? = null
    var myTestDataHandler:ExpDatabaseHandler? = null
    private var totNumChambers:Int? = null
    private var foundExperimentDayNum:Int? = null
    var myToasterObject:Toast? = null
    private var myShapeOfChambersArray:Array<Int?>? = null
    private var textArrayOfConditionName:Array<String?>? = null
    var hintFewMales = false
    var hintNoMales = false
    //----------------------------------------------------------------------------------------------
    @RequiresApi(Build.VERSION_CODES.M)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_data_feeder)
        //-----------------------------------------
        val checkIntent = Intent()
        checkIntent.action = TextToSpeech.Engine.ACTION_CHECK_TTS_DATA
        startActivityForResult(checkIntent, MY_DATA_CHECK_CODE)
        //---------------------------------------
        this.thisExpID = intent.extras?.get("KeyForExpID") as Int
        this.chamberID = intent.extras?.get("KeyForChamberID") as Int
        myTestDataHandler = ExpDatabaseHandler(this)
        myExpClass = myTestDataHandler!!.readOneExpInfo(thisExpID!!)
        this.columnID = myExpClass!!.dayPointer
        this.totNumChambers = myExpClass!!.testConditionRange.last().toInt()
        this.foundExperimentDayNum = MyUtility.findNumberOfColumns(this, myExpClass!!.type!!)
        myShapeOfChambersArray = MyUtility.shapeOfChamberIdentifier(myExpClass!!)
        textArrayOfConditionName = MyUtility.textOfConditionIdentifier(myExpClass!!)
        initialStatusDetermination()
        makePreWormNoInput()
        //---------------------------------------
        viewForDataFeeder.setOnTouchListener(object :
            OnSwipeTouchListener(this@ActivityDataFeeder) {
            //---------------------------------------------
            override fun onSwipeDown() {userInputNoProgeny()}
            override fun onSwipeUp() {userInputReproductive()}
            override fun onSwipeLeft() {goToNextColumn()}
            override fun onSwipeRight() {goToPreviousColumn()}
            override fun onDoubleTouch() {gotoNextChamber()}
            override fun onLongTouch() {gotoPreviousChamber()}
            override fun onSingleTouch() {userInputCensored("Censored", CensorRed)}
            //---------------------------------------------
        })
        //-------------------------------------------------------------------
        censoredBaggedButton.setOnClickListener { userInputCensored("Bagged", CensorBagged) }
        censorDeadButton.setOnClickListener { userInputCensored("Dead", CensorDeadReproductive) }
        censorExplodedButton.setOnClickListener { userInputCensored("Exploded", CensorExploded) }
        censorLostButton.setOnClickListener { userInputCensored("Lost", CensorLost) }
        hintFewMaleReproductive.setOnClickListener { userInputFewMalePresence() }
        hintNoMaleReproductive.setOnClickListener { userInputNoMalePresence() }
        //-------------------------------------------------------------------
    }
    //----------------------------------------------------------------------------------------------
    @RequiresApi(Build.VERSION_CODES.M)
    private fun initialStatusDetermination() {
        val myTestDataHandler = ExpDatabaseHandler(this@ActivityDataFeeder)
        val statusOfChamberAtDayX = myTestDataHandler.readByteArrayAtOneColumn(thisExpID!!,columnID!!)?.get(chamberID!! - 1)

        ShowDayAtFeeder.text = "Day $columnID"
        MyUtility.backGroundIconFinder(textViewForChamberID,myShapeOfChambersArray?.get(chamberID!! - 1)!!)
        ShowConditionAtFeeder.text = textArrayOfConditionName?.get(chamberID!! - 1)!!
        ShowConditionAtFeeder.paintFlags = ShowConditionAtFeeder.paintFlags or Paint.UNDERLINE_TEXT_FLAG

        hintNoMales = false
        hintFewMales = false
        MyUtility.makeBoxGray(hintNoMaleReproductive, applicationContext)
        MyUtility.makeBoxGray(hintFewMaleReproductive, applicationContext)
        val modifiedStaysOfChamberAtDayX = MyUtility.modifyStatusChamberReproductiveAssay(statusOfChamberAtDayX!!)
        if (MyUtility.byte2Int(statusOfChamberAtDayX)<MyUtility.byte2Int(MaxOfAvailableIntInByteArray)) {
            if (MyUtility.byte2Int(statusOfChamberAtDayX)>(MyUtility.byte2Int(MaxOfAvailableIntInByteArray)-MyUtility.byte2Int(HintNoMaleReproductive))) {
                hintNoMales = true
                MyUtility.makeBoxYellow(hintNoMaleReproductive, applicationContext)
            } else if (MyUtility.byte2Int(statusOfChamberAtDayX)>(MyUtility.byte2Int(MaxOfAvailableIntInByteArray)-MyUtility.byte2Int(HintFewMaleReproductive))) {
                hintFewMales = true
                MyUtility.makeBoxYellow(hintFewMaleReproductive, applicationContext)
            }
        }
        val updatedChamberID = MyUtility.findProperNumberUsingProperNumberingStyle(this, thisExpID!!,chamberID!!)
        when (modifiedStaysOfChamberAtDayX) {
            ProgenyGreen -> {MyUtility.makeBoxGreen(textViewForChamberID,applicationContext); textViewForChamberID.text = "#$updatedChamberID";
                ReportReproductiveStatusTextView.text="Reproductive"; RS_PreviousDataBox4.text="RP"; RS_PreviousDataBox4.setTextColor(getColor(R.color.Green))}
            NoProgenyBlue -> {MyUtility.makeBoxBlue(textViewForChamberID,applicationContext); textViewForChamberID.text = "#$updatedChamberID"
                ReportReproductiveStatusTextView.text="No progeny"; RS_PreviousDataBox4.text="NP"; RS_PreviousDataBox4.setTextColor(getColor(R.color.Blue))}
            NoInputGray -> {MyUtility.makeBoxGray(textViewForChamberID,applicationContext); textViewForChamberID.text = "#$updatedChamberID"
                ReportReproductiveStatusTextView.text="Ready"; RS_PreviousDataBox4.text="NA"; RS_PreviousDataBox4.setTextColor(getColor(R.color.DarkGray))}
            CensorRed -> {initCensored("Censored"); RS_PreviousDataBox4.text="C"}
            CensorBagged -> {initCensored("Bagged"); RS_PreviousDataBox4.text="CB"}
            CensorDeadReproductive -> {initCensored("Dead"); RS_PreviousDataBox4.text="CB"}
            CensorExploded -> {initCensored("Exploded"); RS_PreviousDataBox4.text="CE"}
            CensorLost -> {initCensored("Lost"); RS_PreviousDataBox4.text="CL"}
        }
        fillPreviousAndNextDayData()
    }
    //----------------------------------------------------------------------------------------------
    private fun updateStatus(dataByte: Byte) {
        val mFinalDataByte = if (hintNoMales) {MyUtility.byte2Int(dataByte)-MyUtility.byte2Int(
            HintNoMaleReproductive
        )}
                             else if (hintFewMales) {MyUtility.byte2Int(dataByte)- MyUtility.byte2Int(
            HintFewMaleReproductive
        )}
                             else {MyUtility.byte2Int(dataByte)}
        myTestDataHandler!!.updateOneCellAtOneColumn(
            thisExpID!!, columnID!!, chamberID!!, MyUtility.int2Byte(
                mFinalDataByte
            )
        )
    }
    private fun speakUp(sayThis: String) {if (!myBooleanMute) {
            mTts!!.speak(sayThis, TextToSpeech.QUEUE_FLUSH, null, null)} }
    private fun speakUpAfterPreviousDone(sayThis: String) {
        if (!myBooleanMute) {mTts!!.speak(sayThis, TextToSpeech.QUEUE_ADD, null, null)}
    }
    private fun toastMe(useThis: String) {
        myToasterObject?.cancel()
        myToasterObject = Toast.makeText(this@ActivityDataFeeder,useThis, Toast.LENGTH_SHORT)
        myToasterObject?.show()
    }
    fun userInputNoProgeny() {
        MyUtility.makeBoxBlue(PreWormDisplayID, applicationContext)
        val updatedChamberID = MyUtility.findProperNumberUsingProperNumberingStyle(this, thisExpID!!,chamberID!!)
        PreWormDisplayID.text = "#$updatedChamberID -> No Progeny"
        updateStatus(NoProgenyBlue)
        makeWormFollowingDaysNoInput()
        speakUp("$updatedChamberID no progeny")
        gotoNextChamber()
    }
    private fun userInputCensored(textMassage: String, byteValue: Byte){
        MyUtility.makeBoxRed(PreWormDisplayID, applicationContext)
        val updatedChamberID = MyUtility.findProperNumberUsingProperNumberingStyle(this,thisExpID!!,chamberID!!)
        PreWormDisplayID.text = "#$updatedChamberID -> $textMassage"
        updateStatus(byteValue)
        makeWormFollowingDaysCensored(byteValue)
        speakUp("$updatedChamberID $textMassage")
        gotoNextChamber()
    }
    private fun userInputFewMalePresence(){
        when (hintFewMales) {
            false -> {
                hintFewMales = true
                hintNoMales = false
                MyUtility.makeBoxYellow(hintFewMaleReproductive, applicationContext)
                MyUtility.makeBoxGray(hintNoMaleReproductive, applicationContext)
                speakUp("Few Males")
            }
            true -> {
                hintNoMales = false
                MyUtility.makeBoxGray(hintFewMaleReproductive, applicationContext)
            }
        }
    }
    private fun userInputNoMalePresence(){
        when (hintNoMales) {
            false -> {
                hintNoMales = true
                hintFewMales = false
                MyUtility.makeBoxYellow(hintNoMaleReproductive, applicationContext)
                MyUtility.makeBoxGray(hintFewMaleReproductive, applicationContext)
                speakUp("No Males")
            }
            true -> {
                hintNoMales = false
                MyUtility.makeBoxGray(hintNoMaleReproductive, applicationContext)
            }
        }
    }
    @RequiresApi(Build.VERSION_CODES.M)
    private fun initCensored(textMassage: String){
        MyUtility.makeBoxRed(textViewForChamberID, applicationContext)
        val updatedChamberID = MyUtility.findProperNumberUsingProperNumberingStyle(this,thisExpID!!,chamberID!!)
        textViewForChamberID.text = "#$updatedChamberID"
        ReportReproductiveStatusTextView.text=textMassage
        RS_PreviousDataBox4.setTextColor(getColor(R.color.Red))
    }
    private fun makePreWormNoInput(){
        PreWormDisplayID.text = "Last Input NA"
        MyUtility.makeBoxGray(PreWormDisplayID, applicationContext)
    }
    fun userInputReproductive() {
        MyUtility.makeBoxGreen(PreWormDisplayID, applicationContext)
        val updatedChamberID = MyUtility.findProperNumberUsingProperNumberingStyle(this, thisExpID!!, chamberID!!)
        PreWormDisplayID.text = "#$updatedChamberID -> Reproductive"
        updateStatus(ProgenyGreen)
        makeWormFollowingDaysNoInput()
        speakUp("$updatedChamberID reproductive")
        gotoNextChamber()
    }
    //----------------------------------------------------------------------------------------------
    private fun makeWormFollowingDaysCensored(dataByte: Byte) {
        var daysFollowing = columnID
        while (daysFollowing!!<foundExperimentDayNum!!) {
            daysFollowing = daysFollowing.plus(1)
            myTestDataHandler!!.updateOneCellAtOneColumn( thisExpID!!, daysFollowing, chamberID!!, dataByte)
        }
    }
    private fun makeWormFollowingDaysNoInput() {
        var daysFollowing = columnID
        while (daysFollowing!!<foundExperimentDayNum!!) {
            daysFollowing = daysFollowing.plus(1)
            myTestDataHandler!!.updateOneCellAtOneColumn(
                thisExpID!!,
                daysFollowing,
                chamberID!!,
                NoInputGray
            )
        }
    }
    //----------------------------------------------------------------------------------------------
    private fun nextWormIsCensoredOrNot ():Boolean {
        val myTestDataHandler = ExpDatabaseHandler(this@ActivityDataFeeder)
        val statusOfChamberAtDayX = myTestDataHandler.readByteArrayAtOneColumn(thisExpID!!, columnID!!)?.get(chamberID!! - 1)
        var mDecision = false
        when (statusOfChamberAtDayX) {
            CensorBagged, CensorDeadReproductive, CensorExploded, CensorLost, CensorRed -> {mDecision = true}}
        return mDecision
    }
    //----------------------------------------------------------------------------------------------
    @RequiresApi(Build.VERSION_CODES.M)
    fun gotoNextChamber() {
        if (chamberID!!<totNumChambers!!) {
            chamberID = chamberID!!.plus(1)
            //===========================
            //if (columnID!!>1) {dayToCheck = columnID!!-1; while (!makeDecisionAboutChamberToShow()){chamberID = chamberID!!.plus(1)} }
            if (nextWormIsCensoredOrNot()){gotoNextChamber()}
            else {
                initialStatusDetermination()
                val updatedChamberID = MyUtility.findProperNumberUsingProperNumberingStyle(this, thisExpID!!, chamberID!!)
                speakUpAfterPreviousDone("$updatedChamberID ready")
            }
        } else {
            toastMe("Next Chamber Not available!")
            speakUpAfterPreviousDone("last worm")
        }
    }
    @RequiresApi(Build.VERSION_CODES.M)
    fun gotoPreviousChamber() {
        if (chamberID!!>1) {
            chamberID = chamberID!!.minus(1)
            initialStatusDetermination()
            val updatedChamberID = MyUtility.findProperNumberUsingProperNumberingStyle(this, thisExpID!!, chamberID!!)
            speakUpAfterPreviousDone("$updatedChamberID ready")
        } else {
            toastMe("Previous Worm Not available!")
            speakUpAfterPreviousDone("first worm")
        }
        makePreWormNoInput()
    }
    @RequiresApi(Build.VERSION_CODES.M)
    fun goToPreviousColumn() {
        if (columnID!!>1){
            columnID = columnID!!.minus(1)
            initialStatusDetermination()
            val updatedChamberID = MyUtility.findProperNumberUsingProperNumberingStyle(this, thisExpID!!, chamberID!!)
            speakUp("$updatedChamberID at day $columnID")
        } else {
            toastMe("Previous Day Not available!")
            speakUpAfterPreviousDone("Previous day is not available")
        }
        makePreWormNoInput()
    }
    @RequiresApi(Build.VERSION_CODES.M)
    fun goToNextColumn() {
        if (columnID!!<foundExperimentDayNum!!){
            columnID = columnID!!.plus(1)
            initialStatusDetermination()
            val updatedChamberID = MyUtility.findProperNumberUsingProperNumberingStyle(this,thisExpID!!,chamberID!!)
            speakUp("$updatedChamberID at day $columnID")
        } else {
            toastMe("Next Day Not available!")
            speakUpAfterPreviousDone("Next day is not available")
        }
        makePreWormNoInput()
    }
    //----------------------------------------------------------------------------------------------
    private fun readPreviousDayInfo():Byte? {
        val myTestDataHandler = ExpDatabaseHandler(this@ActivityDataFeeder)
        return myTestDataHandler.readByteArrayAtOneColumn(thisExpID!!, dayToCheck!!)?.get(chamberID!! - 1)
    }
    private fun makeDecisionAboutChamberToShowOldProblematic ():Boolean {
        var mDecision = false
        when (readPreviousDayInfo()) {
            ProgenyGreen -> {
                mDecision = true
            }
            NoProgenyBlue -> {
                if (dayToCheck == (columnID!! - 2)) {
                    mDecision = false
                } else {
                    dayToCheck = dayToCheck?.minus(1)
                    mDecision = makeDecisionAboutChamberToShowOldProblematic()
                }
            }
            NoInputGray -> {
                dayToCheck = dayToCheck?.minus(1)
                mDecision = makeDecisionAboutChamberToShowOldProblematic()
            }
            CensorBagged -> {
                mDecision = false
            }
            CensorDeadReproductive -> {
                mDecision = false
            }
            CensorExploded -> {
                mDecision = false
            }
            CensorLost -> {
                mDecision = false
            }
        }
        return mDecision
    }
    //----------------------------------------------------------------------------------------------
    //----------------------------------------------------------------------------------------------
    @RequiresApi(Build.VERSION_CODES.M)
    private fun fillPreviousAndNextDayData() {
        val myTestDataHandler = ExpDatabaseHandler(this@ActivityDataFeeder)
        var statusOfChamberAtDayX:Byte? = null
        var dayNumValue:Int? = null

        dayNumValue =columnID!!-1
        if (dayNumValue>0 && dayNumValue<=foundExperimentDayNum!!) {
            statusOfChamberAtDayX = myTestDataHandler.readByteArrayAtOneColumn(thisExpID!!,dayNumValue )?.get(chamberID!!-1)
            fillPreNextAccordingly(statusOfChamberAtDayX!!, RS_PreviousDataBox3)
        }else {fillPreNextAccordingly(NoInputGray, RS_PreviousDataBox3)}

        dayNumValue =columnID!!-2
        if (dayNumValue>0 && dayNumValue<=foundExperimentDayNum!!) {
            statusOfChamberAtDayX = myTestDataHandler.readByteArrayAtOneColumn(thisExpID!!,dayNumValue )?.get(chamberID!!-1)
            fillPreNextAccordingly(statusOfChamberAtDayX!!, RS_PreviousDataBox2)}
        else {fillPreNextAccordingly(NoInputGray, RS_PreviousDataBox2)}

        dayNumValue =columnID!!-3
        if (dayNumValue>0 && dayNumValue<=foundExperimentDayNum!!) {
            statusOfChamberAtDayX = myTestDataHandler.readByteArrayAtOneColumn(thisExpID!!,dayNumValue)?.get(chamberID!!-1)
            fillPreNextAccordingly(statusOfChamberAtDayX!!, RS_PreviousDataBox1)}
        else {fillPreNextAccordingly(NoInputGray, RS_PreviousDataBox1)}

        dayNumValue =columnID!!+1
        if (dayNumValue>0 && dayNumValue<=foundExperimentDayNum!!) {
            statusOfChamberAtDayX = myTestDataHandler.readByteArrayAtOneColumn(thisExpID!!,dayNumValue)?.get(chamberID!!-1)
            fillPreNextAccordingly(statusOfChamberAtDayX!!, RS_PreviousDataBox5)}
        else {fillPreNextAccordingly(NoInputGray, RS_PreviousDataBox5)}
    }
    @RequiresApi(Build.VERSION_CODES.M)
    private fun fillPreNextAccordingly(statusOfChamber:Byte, myTextView:TextView){
        when (statusOfChamber) {
            ProgenyGreen -> {myTextView.text="RP"; myTextView.backgroundTintList = getColorStateList(R.color.SeaGreen)}
            NoProgenyBlue -> {myTextView.text="NP"; myTextView.backgroundTintList = getColorStateList(R.color.DeepSkyBlue)}
            NoInputGray -> {myTextView.text="NA"; myTextView.backgroundTintList = getColorStateList(R.color.DarkGray)}
            CensorRed -> {myTextView.text="C"; myTextView.backgroundTintList = getColorStateList(R.color.IndianRed)}
            CensorBagged -> {myTextView.text="CB"; myTextView.backgroundTintList = getColorStateList(R.color.IndianRed)}
            CensorDeadReproductive -> {myTextView.text="CD"; myTextView.backgroundTintList = getColorStateList(R.color.IndianRed)}
            CensorExploded -> {myTextView.text="CE"; myTextView.backgroundTintList = getColorStateList(R.color.IndianRed)}
            CensorLost -> {myTextView.text="CL"; myTextView.backgroundTintList = getColorStateList(R.color.IndianRed)}
        }
    }
    //----------------------------------------------------------------------------------------------
    //----------------------------------------------------------------------------------------------
    override fun onDestroy() {
        mTts!!.stop()
        mTts!!.shutdown()
        super.onDestroy()
    }
    //----------------------------------------------------------------------------------------------
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == MY_DATA_CHECK_CODE) {
            if (resultCode == TextToSpeech.Engine.CHECK_VOICE_DATA_PASS) {

                mTts = TextToSpeech(this@ActivityDataFeeder, OnInitListener { })
                mTts!!.language = Locale.US
                mTts!!.setSpeechRate(TextToSpeechSpeedValue)
            } else {
                toastMe("Missing Text to Speech Package")
                val installIntent = Intent()
                installIntent.action = TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA
                startActivity(installIntent)
            }
        }
    }
    //----------------------------------------------------------------------------------------------
}
