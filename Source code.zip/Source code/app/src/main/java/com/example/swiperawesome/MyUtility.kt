package com.example.swiperawesome

import android.content.ContentValues
import android.content.Context
import android.util.DisplayMetrics
import android.widget.Button
import android.widget.TextView
import androidx.core.content.ContextCompat
import kotlin.math.round

object MyUtility {
    //----------------------------------------------------------------------------------------------
    fun findProperNumberUsingProperNumberingStyle(mContext: Context, thisExpID: Int, myChamberID: Int):Int {
        val myChamberDatabaseHandler = ExpDatabaseHandler(mContext)
        val myExpInfo = myChamberDatabaseHandler.readOneExpInfo(thisExpID)
        var pNumber = 0
        if (myExpInfo.numberingStyle==0 && myChamberID>myExpInfo.testConditionRange[0]) {
            for (ii in 2..myExpInfo.testConditionRange.size) {
                if (myChamberID>myExpInfo.testConditionRange[ii-2] && myChamberID<=myExpInfo.testConditionRange[ii-1]) {
                    pNumber = myChamberID-myExpInfo.testConditionRange[ii-2]
                }
            }
        } else {pNumber= myChamberID}
        return pNumber
    }
    //----------------------------------------------------------------------------------------------
    fun findConditionNumberForConditionColor(mContext: Context, thisExpID: Int, myChamberID: Int):Int {
        val myChamberDatabaseHandler = ExpDatabaseHandler(mContext)
        val myExpInfo = myChamberDatabaseHandler.readOneExpInfo(thisExpID)
        var pValue = 1
        for (ii in 2..myExpInfo.testConditionRange.size) {
             if (myChamberID>myExpInfo.testConditionRange[ii - 2] && myChamberID<myExpInfo.testConditionRange[ii - 1]) {pValue = ii}
        }
        return pValue
    }
    //----------------------------------------------------------------------------------------------
    fun findNumberOfColumns(mContext: Context, expType: String): Int? {
        var numColumn:Int? = null

        when(expType) {
            mContext.getString(R.string.LS_assay) -> {
                numColumn = NUMBER_OF_DAYS_LS
            }
            mContext.getString(R.string.LS_assayXX) -> {
                numColumn = NUMBER_OF_DAYS_LS
            }
            mContext.getString(R.string.RS_assay) -> {
                numColumn = NUMBER_OF_DAYS_RS
            }
            mContext.getString(R.string.ProgenyAssay) -> {
                numColumn = NUMBER_OF_DAYS_RS_COUNT
            }
            mContext.getString(R.string.ChoiceAssay) -> {
                numColumn = NUMBER_OF_Column_CHOICE_ASSAY
            }
        }
        return numColumn
    }
    //----------------------------------------------------------------------------------------------
    fun calculateNoOfColumnsInGallery(context: Context, columnWidthDp: Float): Int {
        val displayMetrics: DisplayMetrics = context.resources.displayMetrics
        val screenWidthDp = displayMetrics.widthPixels
        val resultRoundDown = roundDown(screenWidthDp/ columnWidthDp)
        return resultRoundDown.toInt()
    }
    fun roundDown(f: Float): Int {
        val c = (f + 0.5f).toInt()
        val n = f + 0.5f
        return if ((n - c) % 2 == 0f) f.toInt() else c
    }
    //----------------------------------------------------------------------------------------------
    fun backGroundIconFinder(myShape: TextView, shapeIdentifier: Int) {
        myShape.setBackgroundResource(MY_DRAWABLE_LIST[shapeIdentifier - 1])
    }
    //----------------------------------------------------------------------------------------------
    fun makeBoxRed(mBox: TextView, mContext: Context) {mBox.backgroundTintList = ContextCompat.getColorStateList(mContext, R.color.Red)}
    fun makeBoxBlue(mBox: TextView, mContext: Context) {mBox.backgroundTintList = ContextCompat.getColorStateList(mContext, R.color.DeepSkyBlue)}
    fun makeBoxGray(mBox: TextView, mContext: Context) {mBox.backgroundTintList = ContextCompat.getColorStateList(mContext, R.color.DarkGray)}
    fun makeBoxGreen(mBox: TextView, mContext: Context) {mBox.backgroundTintList = ContextCompat.getColorStateList(mContext, R.color.SpringGreen)}
    fun makeBoxYellow(mBox: TextView, mContext: Context) {mBox.backgroundTintList = ContextCompat.getColorStateList(mContext, R.color.Yellow)}
    //----------------------------------------------------------------------------------------------
    fun makeShapeRed(mBox: TextView, mContext: Context) {mBox.backgroundTintList = ContextCompat.getColorStateList(mContext, R.color.Red)}
    fun makeShapeBlue(mBox: TextView, mContext: Context) {mBox.backgroundTintList = ContextCompat.getColorStateList(mContext, R.color.DeepSkyBlue)}
    fun makeShapeGray(mBox: TextView, mContext: Context) {mBox.backgroundTintList = ContextCompat.getColorStateList(mContext, R.color.DarkGray)}
    fun makeShapeGreen(mBox: TextView, mContext: Context) {mBox.backgroundTintList = ContextCompat.getColorStateList(mContext, R.color.SpringGreen)}
    fun makeShapeYellow(mBox: TextView, mContext: Context) {mBox.backgroundTintList = ContextCompat.getColorStateList(mContext, R.color.Yellow)}
    fun makeShapeOrange(mBox: TextView, mContext: Context) {mBox.backgroundTintList = ContextCompat.getColorStateList(mContext, R.color.OrangeRed)}
    //----------------------------------------------------------------------------------------------
    fun makeButtonRed(mBox: Button, mContext: Context) {mBox.backgroundTintList = ContextCompat.getColorStateList(mContext, R.color.Red)}
    fun makeButtonBlue(mBox: Button, mContext: Context) {mBox.backgroundTintList = ContextCompat.getColorStateList(mContext, R.color.Blue)}
    fun makeButtonGreen(mBox: Button, mContext: Context) {mBox.backgroundTintList = ContextCompat.getColorStateList(mContext, R.color.Green)}
    //----------------------------------------------------------------------------------------------
    //----------------------------------------------------------------------------------------------

    fun shapeOfChamberIdentifier(thisExpInfo: Experiment) : Array<Int?> {
        val shapeStatusOfChambersArray = arrayOfNulls<Int>(thisExpInfo.testConditionRange.last().toInt())
        for (chamberCounter in 1..thisExpInfo.testConditionRange.last().toInt()) {
            for (conditionCounter in 1..thisExpInfo.testConditionName.size){

                if (chamberCounter <= thisExpInfo.testConditionRange[conditionCounter - 1] &&
                    shapeStatusOfChambersArray[chamberCounter - 1]==null) {
                    shapeStatusOfChambersArray[chamberCounter - 1] = conditionCounter
                }
            }
        }
        return shapeStatusOfChambersArray
    }
    //----------------------------------------------------------------------------------------------
    fun textOfConditionIdentifier(thisExpInfo: Experiment) : Array<String?> {
        val conditionNameTextArray = arrayOfNulls<String>(thisExpInfo.testConditionRange.last().toInt())
        for (chamberCounter in 1..thisExpInfo.testConditionRange.last().toInt()) {
            for (conditionCounter in 1..thisExpInfo.testConditionName.size){

                if (chamberCounter <= thisExpInfo.testConditionRange[conditionCounter - 1] &&
                    conditionNameTextArray[chamberCounter - 1]==null) {
                    conditionNameTextArray[chamberCounter - 1] = thisExpInfo.testConditionName[conditionCounter - 1]
                }
            }
        }
        return conditionNameTextArray
    }

    //----------------------------------------------------------------------------------------------
    fun isEmptyMyArrayString(array: MutableList<String>): Boolean {
        for (i in array.indices) {
            if (array[i].isEmpty()) {
                return true
            }
        }
        return false
    }
    //----------------------------------------------------------------------------------------------
    fun addTextToDatabaseHeader(numberOfColumns: Int, ColumnTitle: String): String? {
        var addedText:String = ""
        for (xColumn in 1..numberOfColumns) {
            addedText += "$ColumnTitle$xColumn TEXT,"
        }
        return addedText
    }
    //----------------------------------------------------------------------------------------------
    fun puttingNoInputValueInByteArray(myValues: ContentValues, myExp: Experiment, numberOfColumns: Int, ColumnTitle: String): ContentValues {
        val dayFillerInput = ByteArray(myExp.testConditionRange.last().toInt()) {NoInputGray}
        for (xColumn in 1..numberOfColumns){
            myValues.put("$ColumnTitle$xColumn", dayFillerInput)
        }
        return myValues
    }
    //----------------------------------------------------------------------------------------------
    fun intArray2ByteArrayConverter(mInts: IntArray): ByteArray {
        val mByteArray= ByteArray(mInts.size)
        for (mm in 1..mInts.size){mByteArray[mm - 1] = (mInts[mm - 1]-MyByteTransferValue).toByte()}
        return  mByteArray
    }
    //----------------------------------------------------------------------------------------------
    fun int2Byte(mInts: Int): Byte {
        return  (mInts-MyByteTransferValue).toByte()
    }
    //----------------------------------------------------------------------------------------------
    fun byteArray2IntArrayConverter(mBytes: ByteArray): IntArray {
        val mIntArray= IntArray(mBytes.size)
        for (mm in 1..mBytes.size){mIntArray[mm - 1] = (mBytes[mm - 1].toInt())+MyByteTransferValue}
        return  mIntArray
    }
    //----------------------------------------------------------------------------------------------
    fun byte2Int(mBytes: Byte):Int {
        return  (mBytes.toInt())+MyByteTransferValue
    }
    //----------------------------------------------------------------------------------------------
    fun updateStartEndRange(myConditionBoxArray: ArrayList<ConditionRowBox>) {
        var sumEnd:Int=0
        for (XX in 1..myConditionBoxArray.size) {
            val myTmp = myConditionBoxArray[XX - 1].num!!.text.toString()
            if (myTmp!="") {
                myConditionBoxArray[XX - 1].end!!.text = (myTmp.toInt()+sumEnd).toString()
                sumEnd = myConditionBoxArray[XX - 1].end!!.text.toString().toInt()
                if ((XX)<myConditionBoxArray.size) myConditionBoxArray[XX].start!!.text = "${myConditionBoxArray[XX - 1].end!!.text.toString().toInt()+1}-"
            }
        }
    }
    //----------------------------------------------------------------------------------------------
    fun modifyStatusChamberReproductiveAssay(statusOfChamberAtDayX: Byte):Byte {
        val bbNoMale = byte2Int(MaxOfAvailableIntInByteArray)-byte2Int(HintNoMaleReproductive)
        val bbFewMale = byte2Int(MaxOfAvailableIntInByteArray)-byte2Int(HintFewMaleReproductive)
        var modifiedStaysOfChamberAtDayX:Byte = 0
        if (byte2Int(statusOfChamberAtDayX)<byte2Int(MaxOfAvailableIntInByteArray)) {
            if (byte2Int(statusOfChamberAtDayX)>bbNoMale) {
                modifiedStaysOfChamberAtDayX = int2Byte(byte2Int(statusOfChamberAtDayX) + byte2Int(HintNoMaleReproductive))
            } else if (byte2Int(statusOfChamberAtDayX)>bbFewMale) {
                modifiedStaysOfChamberAtDayX = int2Byte(byte2Int(statusOfChamberAtDayX) + byte2Int(HintFewMaleReproductive))
            }
        } else { modifiedStaysOfChamberAtDayX = statusOfChamberAtDayX}
        return modifiedStaysOfChamberAtDayX
    }
    //----------------------------------------------------------------------------------------------
}
