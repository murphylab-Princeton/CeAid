package com.example.swiperawesome

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.android.synthetic.main.activity_choice_assay.*
import kotlinx.android.synthetic.main.keyboard.*
import java.util.*


class ActivityChoiceAssay : AppCompatActivity() {

    //----------------------------------------------------------------------------------------------
    private var mTts: TextToSpeech? = null
    var sr: SpeechRecognizer? = null
    private var myExpClass:Experiment? = null
    private var thisExpID:Int? = null
    var columnID:Int? = null
    var chamberID:Int? = null
    var myTestDataHandler:ExpDatabaseHandler? = null
    private var totNumChambers:Int? = null
    private var foundExperimentDayNum:Int? = null
    var myToasterObject: Toast? = null
    var leftyChoiceFlag:Boolean? = null
    private var myShapeOfChambersArray:Array<Int?>? = null
    private var textArrayOfConditionName:Array<String?>? = null
    //----------------------------------------------------------------------------------------------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_choice_assay)
        //---------------------------------------------
        val checkIntent = Intent()
        checkIntent.action = TextToSpeech.Engine.ACTION_CHECK_TTS_DATA
        startActivityForResult(checkIntent, MY_DATA_CHECK_CODE)
        //--------------------------------------------
        this.thisExpID = intent.extras?.get("KeyForExpID") as Int
        this.chamberID = intent.extras?.get("KeyForChamberID") as Int
        myTestDataHandler = ExpDatabaseHandler(this)
        myExpClass = myTestDataHandler!!.readOneExpInfo(thisExpID!!)
        this.columnID = myExpClass!!.dayPointer
        this.totNumChambers = myExpClass!!.testConditionRange.last().toInt()
        this.foundExperimentDayNum = MyUtility.findNumberOfColumns(this, myExpClass!!.type!!)
        myShapeOfChambersArray = MyUtility.shapeOfChamberIdentifier(myExpClass!!)
        textArrayOfConditionName = MyUtility.textOfConditionIdentifier(myExpClass!!)
        //--------------------------------------------
        leftConditionNameID.text = "Choice at Left"
        rightConditionNameID.text = "Choice at Right"
        listenerInitialization()
        leftyChoiceFlag=true; initialStatusDetermination(rightChoiceAssayID)
        leftyChoiceFlag=false; initialStatusDetermination(leftChoiceAssayID)
        columnID=1; leftyChoiceFlag = false
        leftChoiceArrow.visibility = View.VISIBLE
        rightChoiceArrow.visibility = View.GONE
        //--------------------------------------------
        val ic = hiddenTextChoiceAssay.onCreateInputConnection(EditorInfo())
        choiceAssayKeyboard.setInputConnection(ic)
        button_enter.setOnClickListener {
            if(hiddenTextChoiceAssay.text.toString()!="") {
                saveInfoAfterEnterCommand(hiddenTextChoiceAssay.text.toString().toInt())
                hiddenTextChoiceAssay.setText("")
                MyUtility.makeShapeGray(button_enter, applicationContext)
            }
        }
        hiddenTextChoiceAssay.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                columnID = if(leftyChoiceFlag!!) 2; else 1
                if (s.length<4) {
                    if(s.toString()!=""){ reportNumWormsTextView(s.toString().toInt()) }
                } else { button_delete.performClick()}
            }
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}
            override fun afterTextChanged(s: Editable) {

                if (hiddenTextChoiceAssay.text.toString()!="") {
                        MyUtility.makeShapeBlue(button_enter, applicationContext)
                        if (leftyChoiceFlag == true) {MyUtility.makeShapeGray(rightChoiceAssayID, applicationContext)}
                        else if (leftyChoiceFlag == false) {MyUtility.makeShapeGray(leftChoiceAssayID, applicationContext)}
                }
            }
        })
        //------------------------------------------------------------------------------------------
        viewForChoiceAssay.setOnTouchListener(object : OnSwipeTouchListener(this@ActivityChoiceAssay) {
            //---------------------------------------------
            override fun onSwipeDown() {}
            override fun onSwipeUp() {}
            override fun onSwipeLeft() {goToNextChamberForChoice()}
            override fun onSwipeRight() {goToPreviousChamberForChoice()}
            override fun onDoubleTouch() {
                columnID = if(leftyChoiceFlag!!) 2; else 1
                sr!!.startListening(intent)
            }
            override fun onLongTouch() {censorChoiceAssayChamber()}
            override fun onSingleTouch() {
                if (hiddenTextChoiceAssay.text.toString()=="") {
                    if (leftyChoiceFlag == true) {saveInfoAfterEnterCommand(rightChoiceAssayID.text.toString().toInt())}
                    else if (leftyChoiceFlag == false) {saveInfoAfterEnterCommand(leftChoiceAssayID.text.toString().toInt())}
                    MyUtility.makeShapeGray(button_enter, applicationContext)
                    button_enter.text = "ENTER"
                }
            }
            //---------------------------------------------
        })
    }
    //----------------------------------------------------------------------------------------------
    private fun initialStatusDetermination(ChoiceAssayID:TextView) {
        val myTestDataHandler = ExpDatabaseHandler(this@ActivityChoiceAssay)
        var sally=1; if(leftyChoiceFlag!!) {sally=2}
        val statusOfChamberAtDayX = myTestDataHandler.readByteArrayAtOneColumn(thisExpID!!,sally)?.get(chamberID!!-1)
        MyUtility.backGroundIconFinder(ChoiceAssayID, myShapeOfChambersArray?.get(chamberID!!-1)!!)

        val splitStringArray = textArrayOfConditionName!![chamberID!!-1]!!.split(",", ignoreCase = true, limit = 0)
        if (textArrayOfConditionName!!.size==3) {
            leftConditionNameID.text = splitStringArray[1]
            rightConditionNameID.text = splitStringArray[2]
        }
        hiddenTextChoiceAssay.setText("")
        val updatedChamberID = MyUtility.findProperNumberUsingProperNumberingStyle(this, thisExpID!!, chamberID!!)
        when(statusOfChamberAtDayX) {
            CensorRed -> {
                leftChamberNumberID.text = "#$updatedChamberID"
                rightChamberNumberID.text = "#$updatedChamberID"
                MyUtility.makeBoxRed(ChoiceAssayID,applicationContext); ChoiceAssayID.text = "Censored"}
                NoInputGray -> {MyUtility.makeBoxGray(ChoiceAssayID,applicationContext); reportEmptyTextView()}
            else -> {MyUtility.makeBoxGreen(ChoiceAssayID,applicationContext); reportNumWormsTextView(MyUtility.byte2Int(statusOfChamberAtDayX!!))}
        }
    }
    //----------------------------------------------------------------------------------------------
    inner class TextListener: RecognitionListener {

        override fun onReadyForSpeech(params: Bundle) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray) {}
        override fun onEndOfSpeech() {}
        override fun onError(error: Int) { warningTheTextBox("error $error")}
        override fun onPartialResults(partialResults: Bundle) {}
        override fun onEvent(eventType: Int, params: Bundle) {}
        //--------------------------------------------
        override fun onResults(results: Bundle) {
            val data: ArrayList<String>? = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)

            var foundNum:String? = null
            outer@ for (myString in data!!.iterator()) {
                if (myString.length<4) {
                    for (i in myString.indices) {
                        if (!myString[i].isDigit()) break
                        if (i==myString.length-1){
                            foundNum = myString
                            break@outer
                        }
                    }
                }
            }
            if (foundNum!=null) { afterVoiceInputForChoiceAssay(foundNum.toInt())}
            else {warningTheTextBox("Try again or Long Touch")}
        }
        //--------------------------------------------
    }
    //----------------------------------------------------------------------------------------------
    private fun updateStatus (dataByte:Byte) {myTestDataHandler!!.updateOneCellAtOneColumn(thisExpID!!, columnID!!, chamberID!!, dataByte)}
    private fun speakUp (sayThis:String) {if (!myBooleanMute) {mTts!!.speak(sayThis, TextToSpeech.QUEUE_FLUSH, null, null)} }
    private fun speakUpAfterPreviousDone (sayThis:String) { if (!myBooleanMute) { mTts!!.speak(sayThis, TextToSpeech.QUEUE_ADD, null, null)} }

    private fun toastMe(useThis:String) {   myToasterObject?.cancel()
                                            myToasterObject = Toast.makeText(this@ActivityChoiceAssay, useThis, Toast.LENGTH_SHORT)
                                            myToasterObject?.show()}

    fun afterVoiceInputForChoiceAssay(voiceNum:Int) {
        updateStatus(MyUtility.int2Byte(voiceNum))
        MyUtility.makeBoxBlue(button_enter, applicationContext)
        button_enter.text = "Tap on screen"
        val updatedChamberID = MyUtility.findProperNumberUsingProperNumberingStyle(this, thisExpID!!, chamberID!!)
        when(columnID) {
            1 -> {MyUtility.makeBoxGreen(leftChoiceAssayID,applicationContext)
                leftChamberNumberID.text = "#$updatedChamberID"
                leftChoiceAssayID.text = "$voiceNum"
            }
            2 -> {MyUtility.makeBoxGreen(rightChoiceAssayID,applicationContext)
                rightChamberNumberID.text = "#$updatedChamberID"
                rightChoiceAssayID.text = "$voiceNum"
            }
        }
    }

    fun saveInfoAfterEnterCommand(voiceNum:Int) {
        if(voiceNum<MyUtility.byte2Int(MaxOfAvailableIntInByteArray)) {

            updateStatus(MyUtility.int2Byte(voiceNum))
            val updatedChamberID = MyUtility.findProperNumberUsingProperNumberingStyle(this, thisExpID!!, chamberID!!)
            when(columnID) {
                1 -> {speakUp("$voiceNum Worms on left")
                    MyUtility.makeBoxGreen(leftChoiceAssayID,applicationContext)
                    leftChoiceArrow.visibility = View.GONE
                    rightChoiceArrow.visibility = View.VISIBLE
                    leftyChoiceFlag = true
                    speakUpAfterPreviousDone("ready at right")
                }
                2 -> {speakUp("$voiceNum Worms on right")
                    MyUtility.makeBoxGreen(rightChoiceAssayID,applicationContext)
                    leftChoiceArrow.visibility = View.VISIBLE
                    rightChoiceArrow.visibility = View.GONE
                    leftyChoiceFlag = false
                    goToNextChamberForChoice()
                }
            }
        }
        else {
            speakUpAfterPreviousDone("max is 240")
            toastMe("Data not stored")
            hiddenTextChoiceAssay.setText("")
            if (leftyChoiceFlag==true) {goToNextChamberForChoice(); goToPreviousChamberForChoice(); leftyChoiceFlag=true;
                val updatedChamberID = MyUtility.findProperNumberUsingProperNumberingStyle(this, thisExpID!!, chamberID!!)
                speakUp("$updatedChamberID is ready at right")
                leftChoiceArrow.visibility = View.GONE
                rightChoiceArrow.visibility = View.VISIBLE
            }
            else if (leftyChoiceFlag==false) {goToNextChamberForChoice();goToPreviousChamberForChoice(); leftyChoiceFlag=false
                val updatedChamberID = MyUtility.findProperNumberUsingProperNumberingStyle(this, thisExpID!!, chamberID!!)
                speakUp("$updatedChamberID is ready at left")
            }
            MyUtility.makeBoxGray(button_enter, applicationContext)
            button_enter.text = "ENTER"
        }
    }

    fun censorChoiceAssayChamber() {
        columnID=2; updateStatus(CensorRed)
        columnID=1; updateStatus(CensorRed)
        leftyChoiceFlag = false
        val updatedChamberID = MyUtility.findProperNumberUsingProperNumberingStyle(this, thisExpID!!, chamberID!!)

        leftChamberNumberID.text = "#$updatedChamberID"
        rightChamberNumberID.text = "#$updatedChamberID"
        leftChoiceAssayID.text = "Censored"
        rightChoiceAssayID.text = "Censored"
        MyUtility.makeBoxRed(leftChoiceAssayID,applicationContext)
        MyUtility.makeBoxRed(rightChoiceAssayID,applicationContext)
        speakUp("$chamberID is censored")
    }
    fun goToNextChamberForChoice() {
        if (chamberID!!<totNumChambers!!) {
            chamberID = chamberID!!.plus(1)
            leftyChoiceFlag=true; initialStatusDetermination(rightChoiceAssayID)
            leftyChoiceFlag=false; initialStatusDetermination(leftChoiceAssayID)
            columnID=1; leftyChoiceFlag = false
            leftChoiceArrow.visibility = View.VISIBLE
            rightChoiceArrow.visibility = View.GONE
            val updatedChamberID = MyUtility.findProperNumberUsingProperNumberingStyle(this, thisExpID!!, chamberID!!)
            speakUpAfterPreviousDone("$updatedChamberID is ready at left")
        } else {
            toastMe("Next Chamber Not available!")
            speakUpAfterPreviousDone("last worm")
        }
    }
    fun goToPreviousChamberForChoice() {
        if (chamberID!!>1){
            chamberID = chamberID!!.minus(1)
            leftyChoiceFlag=true; initialStatusDetermination(rightChoiceAssayID)
            leftyChoiceFlag=false; initialStatusDetermination(leftChoiceAssayID)
            leftyChoiceFlag = false
            leftChoiceArrow.visibility = View.VISIBLE
            rightChoiceArrow.visibility = View.GONE
            val updatedChamberID = MyUtility.findProperNumberUsingProperNumberingStyle(this, thisExpID!!, chamberID!!)
            speakUpAfterPreviousDone("$updatedChamberID is ready at left")
        } else {
            toastMe("Previous chamber Not available!")
            speakUpAfterPreviousDone("Previous chamber is not available")
        }
    }
    private fun reportNumWormsTextView(value:Int) {
        val updatedChamberID = MyUtility.findProperNumberUsingProperNumberingStyle(this, thisExpID!!, chamberID!!)
        leftChamberNumberID.text = "#$updatedChamberID"
        rightChamberNumberID.text = "#$updatedChamberID"
        when(leftyChoiceFlag) {
            false -> leftChoiceAssayID.text = "$value"
            true -> rightChoiceAssayID.text = "$value"
        }
    }
    private fun reportEmptyTextView(){
        val updatedChamberID = MyUtility.findProperNumberUsingProperNumberingStyle(this, thisExpID!!, chamberID!!)
        leftChamberNumberID.text = "#$updatedChamberID"
        rightChamberNumberID.text = "#$updatedChamberID"
        when(leftyChoiceFlag) {
            false -> leftChoiceAssayID.text = "-?-"
            true -> rightChoiceAssayID.text = "-?-"
        }
    }
    //---------------------------------------------
    fun warningTheTextBox (myWarning:String) {
        when(columnID) {
            2 -> {rightChoiceAssayID.text = myWarning}
            1 -> {leftChoiceAssayID.text = myWarning}
        }
    }
    //---------------------------------------------
    private fun listenerInitialization() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)!= PackageManager.PERMISSION_GRANTED) {
            if (!ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.RECORD_AUDIO)) {
                ActivityCompat.requestPermissions(this, arrayOf<String>(Manifest.permission.RECORD_AUDIO),527)
            }
        }
        sr = SpeechRecognizer.createSpeechRecognizer(this)
        sr?.setRecognitionListener(TextListener())
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        intent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, "voice.recognition.test")
        intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 50)
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
    }
    //----------------------------------------------------------------------------------------------
    override fun onDestroy() {
        mTts!!.stop()
        mTts!!.shutdown()
        if (sr!=null) sr!!.destroy()
        super.onDestroy()
    }
    //----------------------------------------------------------------------------------------------
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == MY_DATA_CHECK_CODE) {
            if (resultCode == TextToSpeech.Engine.CHECK_VOICE_DATA_PASS) {

                mTts = TextToSpeech(this@ActivityChoiceAssay, TextToSpeech.OnInitListener { })
                mTts!!.language = Locale.US
                mTts!!.setSpeechRate(1.2f)
            } else {
                toastMe("Missing Text to Speech Package")
                val installIntent = Intent()
                installIntent.action = TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA
                startActivity(installIntent)
            }
        }
    }
    //----------------------------------------------------------------------------------------------
}