package com.example.swiperawesome

import android.content.Context
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Build
import android.widget.TextView
import androidx.annotation.RequiresApi
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.charts.CandleStickChart
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.components.AxisBase
import com.github.mikephil.charting.components.Legend
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import java.util.*
import kotlin.collections.ArrayList
import kotlin.math.absoluteValue
import kotlin.random.Random


object PlotSpecs {

    @RequiresApi(Build.VERSION_CODES.M)
    fun specsForSurvivalPlot(mConditionArray:ArrayList<Condition>, myLines:ArrayList<LineDataSet>,
                             lineChart:LineChart, mContext:Context, XaxisLabel:TextView, YaxisLabel:VerticalTextView, maxAxisX:Float) {

        for (jj in 1..myLines.size) {
            myLines[jj-1].lineWidth = 6f
            myLines[jj-1].color = mContext.getColor(COLORS_FOR_PLOT[jj-1])
            myLines[jj-1].setDrawValues(false)
            myLines[jj-1].setDrawCircleHole(false)
            myLines[jj-1].setDrawCircles(true)
            myLines[jj-1].circleRadius = 4f
            myLines[jj-1].setCircleColor(mContext.getColor(COLORS_FOR_PLOT[jj-1]))
            myLines[jj-1].isHighlightEnabled = false
        }
        lineChart.axisLeft.axisMinimum = 0f
        lineChart.axisLeft.axisMaximum = 100f
        lineChart.xAxis.axisMinimum = 0f
        lineChart.xAxis.axisMaximum = maxAxisX
        XaxisLabel.text = "Time(Days)"
        //----------------------------------------------
        when (mConditionArray[0].type) {
            mContext.getString(R.string.LS_assay), mContext.getString(R.string.LS_assayXX) -> {YaxisLabel.text = "% worms alive"}
            mContext.getString(R.string.RS_assay) -> {YaxisLabel.text = "% worms reproductive"}
        }
        //----------------------------------------------
        lineChart.description.isEnabled = false
        lineChart.setDrawGridBackground(false)
        lineChart.axisRight.setDrawLabels(false)
        lineChart.axisRight.setDrawGridLines(false)
        lineChart.setTouchEnabled(false)
        lineChart.setPinchZoom(false)
        lineChart.setExtraOffsets(0f,0f, 0f,5f)
        //----------------------------------------------
        lineChart.xAxis.setDrawLabels(true)
        lineChart.xAxis.position = XAxis.XAxisPosition.BOTTOM
        lineChart.xAxis.textSize = 20f
        lineChart.xAxis.textColor = Color.BLACK
        lineChart.xAxis.axisLineColor = Color.BLACK
        lineChart.xAxis.setDrawAxisLine(true)
        lineChart.xAxis.setDrawGridLines(true)
        //----------------------------------------------
        lineChart.axisLeft.setDrawLabels(true)
        lineChart.axisLeft.textSize = 20f
        lineChart.axisLeft.textColor = Color.BLACK
        lineChart.axisLeft.axisLineColor = Color.BLACK
        //----------------------------------------------
        lineChart.legend.textSize = 20f
        lineChart.legend.textColor = Color.BLACK
        lineChart.legend.isEnabled= true
        lineChart.legend.verticalAlignment = Legend.LegendVerticalAlignment.BOTTOM
        lineChart.legend.horizontalAlignment = Legend.LegendHorizontalAlignment.LEFT
        lineChart.legend.orientation = Legend.LegendOrientation.VERTICAL
        lineChart.legend.setDrawInside(true)
        lineChart.legend.xOffset = 60f
        lineChart.legend.yOffset = 40f
        //----------------------------------------------
        lineChart.setDrawBorders(true)
        lineChart.setBorderWidth(3f)
        lineChart.setBorderColor(Color.BLACK)
        //----------------------------------------------
    }
    //----------------------------------------------------------------------------------------------
    //----------------------------------------------------------------------------------------------
    @RequiresApi(Build.VERSION_CODES.M)
    fun specsForChoiceAssay(mContext: Context, set1:CandleDataSet, data:CandleData, myCandleStickChart:CandleStickChart, YaxisLabel:VerticalTextView, whichDataSetToShow:Int, mNumGroupToCandleStick:Int) {

        YaxisLabel.text = "Choice Index"
        myCandleStickChart.setTouchEnabled(false)
        myCandleStickChart.setPinchZoom(false)
        myCandleStickChart.setDrawBorders(true)
        myCandleStickChart.setBorderWidth(3f)
        myCandleStickChart.setBorderColor(mContext.getColor(R.color.Black))
        myCandleStickChart.description.isEnabled = false
        myCandleStickChart.setDrawGridBackground(false)
        myCandleStickChart.axisRight.setDrawLabels(false)
        myCandleStickChart.axisRight.setDrawGridLines(false)
        myCandleStickChart.setExtraOffsets(5f,0f, 0f,30f)
        myCandleStickChart.legend.isEnabled = false
        //----------------------------------------------
        set1.shadowColor = mContext.getColor(R.color.Black)
        set1.shadowWidth = 5f
        set1.barSpace = 0.3f
        set1.decreasingColor = mContext.getColor(R.color.Blue)
        set1.decreasingPaintStyle = Paint.Style.FILL_AND_STROKE
        set1.increasingColor = mContext.getColor(R.color.Red)
        set1.increasingPaintStyle = Paint.Style.STROKE
        set1.neutralColor = mContext.getColor(R.color.Green)
        set1.setDrawValues(false)
        //----------------------------------------------
        val myXAxis = myCandleStickChart.xAxis
        myXAxis.setDrawGridLines(false)
        myXAxis.textSize = 15f
        myXAxis.typeface = Typeface.DEFAULT_BOLD
        myXAxis.textColor = Color.BLACK
        myXAxis.setDrawAxisLine(true)
        myXAxis.setDrawLabels(true)
        myXAxis.axisLineColor = Color.BLACK
        myXAxis.position = XAxis.XAxisPosition.BOTTOM
        val myStringArray = set1.label.split(",", ignoreCase = true, limit = 0)
        myXAxis.valueFormatter = IndexAxisValueFormatter(myStringArray)
        myXAxis.labelCount = mNumGroupToCandleStick
        myXAxis.labelRotationAngle =-90f
        myXAxis.axisMinimum = -0.5f+(whichDataSetToShow.toFloat()-1)*mNumGroupToCandleStick.toFloat()
        myXAxis.axisMaximum = -0.5f+(whichDataSetToShow.toFloat())*mNumGroupToCandleStick.toFloat()
        //----------------------------------------------
        val yAxis = myCandleStickChart.axisLeft
        yAxis.setDrawGridLines(true)
        yAxis.setDrawLabels(true)
        yAxis.textSize = 20f
        yAxis.textColor = Color.BLACK
        yAxis.axisLineColor = Color.BLACK
        //yAxis.axisMaximum = 1f
        //yAxis.axisMinimum = -1f
        //----------------------------------------------
        myCandleStickChart.invalidate()
        //----------------------------------------------
    }
    //----------------------------------------------------------------------------------------------
    //----------------------------------------------------------------------------------------------
    fun specsForProgenyAssay(mContext: Context, myGroupedBarChart: BarChart, myXAxisString:ArrayList<String>, maxYAxisValue:Float, groupCount:Int) {
        //----------------------------------------------
        myGroupedBarChart.setDrawBarShadow(false)
        myGroupedBarChart.setDrawValueAboveBar(true)
        myGroupedBarChart.description.isEnabled = false
        myGroupedBarChart.setPinchZoom(false)
        myGroupedBarChart.setTouchEnabled(false)
        myGroupedBarChart.setDrawGridBackground(false)
        myGroupedBarChart.setDrawBorders(true)
        myGroupedBarChart.setBorderWidth(2f)
        myGroupedBarChart.setBorderColor(Color.BLACK)
        //----------------------------------------------
        val myXAxis = myGroupedBarChart.xAxis
        //myXAxis.isGranularityEnabled = true
        //myXAxis.granularity = 1f
        myXAxis.setCenterAxisLabels(true)
        myXAxis.setAvoidFirstLastClipping(true)
        myXAxis.setDrawLabels(true)
        myXAxis.position = XAxis.XAxisPosition.BOTTOM
        myXAxis.textSize = 20f
        //myXAxis.labelRotationAngle = 90f
        myXAxis.textColor = Color.BLACK
        myXAxis.axisLineColor = Color.BLACK
        myXAxis.setDrawGridLines(false)
        //----------------------------------------------
        val myLeftAxis = myGroupedBarChart.axisLeft
        myGroupedBarChart.axisRight.isEnabled = false
        myLeftAxis.setDrawGridLines(false)
        myLeftAxis.spaceTop = 30f
        myLeftAxis.axisMinimum = 0f
        myLeftAxis.textSize = 15f
        myLeftAxis.textColor = Color.BLACK
        myLeftAxis.axisLineColor = Color.BLACK
        myLeftAxis.axisMaximum = maxYAxisValue*1.1f
        //----------------------------------------------
        val myLegend = myGroupedBarChart.legend
        myLegend.textSize = 15f
        myLegend.textColor = Color.BLACK
        myLegend.isEnabled= true
        myLegend.verticalAlignment = Legend.LegendVerticalAlignment.TOP
        myLegend.horizontalAlignment = Legend.LegendHorizontalAlignment.RIGHT
        myLegend.orientation = Legend.LegendOrientation.VERTICAL
        myLegend.setDrawInside(true)
        myLegend.xOffset = 10f
        //----------------------------------------------
        val groupSpace = 0.2f
        val barSpace = 0f
        val mBarWidth = (1-groupSpace)/groupCount
        myGroupedBarChart.barData.barWidth = mBarWidth
        myGroupedBarChart.groupBars(0f, groupSpace, barSpace)
        myXAxis.axisMinimum = 0f
        myXAxis.axisMaximum = myXAxisString.size.toFloat()
        myXAxis.valueFormatter = IndexAxisValueFormatter(myXAxisString)
        myXAxis.labelCount = myXAxisString.size
        myGroupedBarChart.barData.setValueTextSize(15f)
        myGroupedBarChart.barData.setValueTypeface(Typeface.DEFAULT_BOLD)
        myGroupedBarChart.invalidate()
        myGroupedBarChart.data.notifyDataChanged()
        myGroupedBarChart.notifyDataSetChanged()
        //----------------------------------------------
    }
    //----------------------------------------------------------------------------------------------
    //----------------------------------------------------------------------------------------------
}