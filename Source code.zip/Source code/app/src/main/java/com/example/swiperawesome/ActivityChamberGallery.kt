package com.example.swiperawesome

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Switch
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.activity_chamber_gallery.*
import kotlinx.android.synthetic.main.switch_item.view.*
import java.text.SimpleDateFormat
import java.time.format.DateTimeFormatter
import java.util.*
import kotlin.collections.ArrayList


class ActivityChamberGallery : AppCompatActivity() {

    var myChamberDatabaseHandler:ExpDatabaseHandler? = null
    var myDataAdapter:ChamberListAdapter? = null
    var myDataLayoutManager: RecyclerView.LayoutManager? = null
    var thisExpID: Int? = null
    var totNumChambers :Int? = null
    var myCleverMenu: Menu? = null

    //----------------------------------------------------------------------------------------------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chamber_gallery)

        goToThisDayID.visibility = View.GONE
        approveInsertedDayID.visibility = View.GONE

        val tmpItem1 = intent.extras?.get("KeyForExpID") as Int?
        val tmpItem2 = intent.extras?.get("KeyForNumChambers") as Int?
        this.thisExpID = tmpItem1
        this.totNumChambers = tmpItem2
        //-----------------------------------------------------
        if (thisExpID!=null && totNumChambers!=null) {
            this.myChamberDatabaseHandler = ExpDatabaseHandler(this)
            val expClass = myChamberDatabaseHandler!!.readOneExpInfo(thisExpID!!)
            expClass.dayPointer?.let { activityStarter(thisExpID!!, it) }
            //-----------------------------------------------------
            val mFoundExperimentDayNum = MyUtility.findNumberOfColumns(this, expClass.type!!)
            approveInsertedDayID.setOnClickListener {
                val newDayInserted = goToThisDayID.text.toString().toInt()
                if (newDayInserted >= 1 && newDayInserted <= mFoundExperimentDayNum!!) {

                    goToThisDayID.visibility = View.GONE
                    approveInsertedDayID.visibility = View.GONE
                    myChamberDatabaseHandler!!.updateDayPointerForEachExperiment(
                        thisExpID!!,
                        newDayInserted
                    )
                    activityStarter(thisExpID!!, newDayInserted)
                    myCleverMenu?.findItem(R.id.myMenuDays)!!.title = "Day$newDayInserted"

                } else {
                    Toast.makeText(
                        applicationContext,
                        "Day$newDayInserted Out of range",
                        Toast.LENGTH_SHORT
                    ).show()
                    goToThisDayID.setText("")
                }
            }
            //-----------------------------------------------------
        }
    }
    //----------------------------------------------------------------------------------------------
    override fun onResume() {
        super.onResume()
        if (thisExpID!=null && totNumChambers!=null) {
            val myDayID = myChamberDatabaseHandler!!.readColumnPointerForEachExperiment(thisExpID!!)
            activityStarter(thisExpID!!, myDayID)
        }
    }
    //----------------------------------------------------------------------------------------------
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_chamber_gallery, menu)
        this.myCleverMenu = menu

        val myExp = myChamberDatabaseHandler!!.readOneExpInfo(thisExpID!!)
        val mStringMonthDay = findDayMonthOfTheMenu(myExp, myExp.dayPointer!!)
        menu!!.findItem(R.id.myMenuDays).title = "D${myExp.dayPointer} - $mStringMonthDay"

        val switchNumberingChambers = menu.findItem(R.id.switchItemNumberingChambers).actionView.sallySwitchBox as Switch

        myChamberDatabaseHandler = ExpDatabaseHandler(this)
        val numberingStyle = myChamberDatabaseHandler!!.readNumberingStylePointerForEachExperiment(
            thisExpID!!
        )
        if (numberingStyle==0){switchNumberingChambers.isChecked=false} else if (numberingStyle==1) {switchNumberingChambers.isChecked=true}
        switchNumberingChambers.setOnCheckedChangeListener { _, _ ->
            if (switchNumberingChambers.isChecked)
                 {myChamberDatabaseHandler!!.updateNumberingStylePointerForEachExperiment(thisExpID!!, 1)}
            else {myChamberDatabaseHandler!!.updateNumberingStylePointerForEachExperiment(thisExpID!!, 0)}
            val myExperiment = myChamberDatabaseHandler!!.readOneExpInfo(thisExpID!!)
            activityStarter(thisExpID!!, myExperiment.dayPointer!!)
        }
        return true
    }
    //----------------------------------------------------------------------------------------------
    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        var flagPass = false
        val myExpInformation = myChamberDatabaseHandler!!.readOneExpInfo(thisExpID!!)

        if (thisExpID!=null && totNumChambers!=null && myExpInformation.type!=getString(R.string.ChoiceAssay)) {
            var myDayID = myExpInformation.dayPointer
            val foundExperimentDayNum = MyUtility.findNumberOfColumns(this, myExpInformation.type!!)
            when (item.itemId) {
                R.id.previousDayButton -> {
                    if (myDayID != 1) {
                        if (myDayID != null) {
                            myDayID -= 1
                            flagPass = true
                        }
                    } else {
                        Toast.makeText(
                            applicationContext,
                            "There is no Previous day",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
                //--------------------------------------------------------
                R.id.myMenuDays -> {
                    goToThisDayID.visibility = View.VISIBLE
                    approveInsertedDayID.visibility = View.VISIBLE
                    goToThisDayID.hint = myDayID.toString()
                }
                //--------------------------------------------------------
                R.id.nextDayButton -> {
                    if (myDayID != foundExperimentDayNum) {
                        if (myDayID != null) {
                            myDayID += 1
                            flagPass = true
                        }
                    } else {
                        Toast.makeText(
                            applicationContext,
                            "There is no Next Day",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }
            if (flagPass) {
                myChamberDatabaseHandler!!.updateDayPointerForEachExperiment(thisExpID!!, myDayID!!)
                activityStarter(thisExpID!!, myDayID)
                val mStringMonthDay = findDayMonthOfTheMenu(myExpInformation,myDayID)
                myCleverMenu?.findItem(R.id.myMenuDays)!!.title = "D$myDayID - $mStringMonthDay"
            }
        }
        return super.onOptionsItemSelected(item)
    }
    //----------------------------------------------------------------------------------------------
    private fun activityStarter(thisExpID: Int, myDayID: Int) {

        val listOfChamberItems = ArrayList<Chamber>()
        val chamberShapeWidthDP:Float = (resources.getDimension(R.dimen.widthOfchamberShape)/1).toFloat()
        val mNoOfColumns: Int = MyUtility.calculateNoOfColumnsInGallery(applicationContext, chamberShapeWidthDP)
        this.myDataLayoutManager = GridLayoutManager(this, mNoOfColumns)
        this.myDataAdapter = ChamberListAdapter(thisExpID, listOfChamberItems, this)
        recyclerChamberGalleryID.layoutManager = myDataLayoutManager
        recyclerChamberGalleryID.adapter = myDataAdapter

        // load our experiments
        val statusChamberByteArray = myChamberDatabaseHandler!!.readByteArrayAtOneColumn(
            thisExpID,
            myDayID
        )
        val thisExpInfo = myChamberDatabaseHandler!!.readOneExpInfo(thisExpID)
        val myShapeOfChambersArray = MyUtility.shapeOfChamberIdentifier(thisExpInfo)
        var statusExtraChoiceAssay:ByteArray? = null
        if (thisExpInfo.type==getString(R.string.ChoiceAssay)) statusExtraChoiceAssay=myChamberDatabaseHandler!!.readByteArrayAtOneColumn(
            thisExpID,
            myDayID + 1
        )
        //--------------------------------------------
        for (XX in 1..statusChamberByteArray!!.size) {
            val chamberInfo = Chamber()
            chamberInfo.id = XX
            chamberInfo.chamberShape = myShapeOfChambersArray[XX - 1]
            chamberInfo.status = statusChamberByteArray[XX - 1]
            chamberInfo.type = thisExpInfo.type
            if(statusExtraChoiceAssay!=null) chamberInfo.auxiliaryStatus = statusExtraChoiceAssay[XX - 1]
            listOfChamberItems.add(chamberInfo)
        }
        myDataAdapter!!.notifyDataSetChanged()
    }
    //----------------------------------------------------------------------------------------------

    private fun findDayMonthOfTheMenu(myExperiment:Experiment, dDayIntended:Int):String {
        val dayOneOfExp = myExperiment.startDate
        val mDateParts = dayOneOfExp!!.split("-")

        val mCalendar = Calendar.getInstance()
        mCalendar[Calendar.YEAR] = mDateParts[0].toInt()
        mCalendar[Calendar.MONTH] = mDateParts[1].toInt()-1
        mCalendar[Calendar.DAY_OF_MONTH] = mDateParts[2].toInt()

        mCalendar.add(Calendar.DATE, dDayIntended-1)
        val mDay = mCalendar[Calendar.DATE]
        val monthDateFormat = SimpleDateFormat("MMM")
        val monthName: String = monthDateFormat.format(mCalendar.time)
        return "$monthName $mDay"
    }
}


