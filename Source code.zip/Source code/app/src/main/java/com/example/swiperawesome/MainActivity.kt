package com.example.swiperawesome

import android.graphics.drawable.Icon
import android.os.Build
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.list_rows_recycler.*


class MainActivity : AppCompatActivity() {
    var myDatabaseHandler:ExpDatabaseHandler? = null
    var myAdapter:ExpListAdapter? = null
    var listOfExp:ArrayList<Experiment>? = null
    var listOfExpItems:ArrayList<Experiment>? = null
    var myLayoutManager:RecyclerView.LayoutManager? = null
    var myMenu:Menu? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //-------------------------------------------------------
        myDatabaseHandler = ExpDatabaseHandler(this)
        listOfExp = ArrayList()
        listOfExpItems = ArrayList()
        myLayoutManager = LinearLayoutManager(this).apply { reverseLayout=true }.apply { stackFromEnd=true }
        myAdapter = ExpListAdapter(listOfExpItems!!,this)
        myRecyclerView.layoutManager = myLayoutManager
        myRecyclerView.adapter = myAdapter
        //-------------------------------------------------------
        if (!checkDB()) {
            createPopupDialog()
        } else {
            listOfExp = myDatabaseHandler!!.readAllExpInfo()
            for (cc in listOfExp!!.iterator()) {
                val expLoop = Experiment()
                expLoop.id = cc.id
                expLoop.name = cc.name
                expLoop.startDate = cc.startDate
                expLoop.type = cc.type
                expLoop.dayPointer = cc.dayPointer
                expLoop.testConditionName = cc.testConditionName
                expLoop.testConditionRange = cc.testConditionRange
                listOfExpItems!!.add(expLoop)
            }
            myAdapter!!.notifyDataSetChanged()
        }
    }
    //----------------------------------------------------------------------------------------------
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.top_menu, menu)
        this.myMenu = menu
        return true
    }
    //----------------------------------------------------------------------------------------------
    @RequiresApi(Build.VERSION_CODES.N)
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.add_menu_button){
            createPopupDialog()
        } else if (item.itemId==R.id.templateOpenerID) {
            listOfExpItems = SampleExperiments.templateExpForReproductiveSpanAssay2 (listOfExpItems!!, applicationContext, myDatabaseHandler!!, myAdapter!!)
            listOfExpItems = SampleExperiments.templateExpForReproductiveSpanAssay (listOfExpItems!!, applicationContext, myDatabaseHandler!!, myAdapter!!)
            listOfExpItems = SampleExperiments.templateExpForChoiceAssay (listOfExpItems!!, applicationContext, myDatabaseHandler!!, myAdapter!!)
            listOfExpItems = SampleExperiments.templateExpForProgenyCountAssay(listOfExpItems!!, applicationContext, myDatabaseHandler!!, myAdapter!!)
            listOfExpItems = SampleExperiments.templateExpForLifeSpanAssay(listOfExpItems!!, applicationContext, myDatabaseHandler!!, myAdapter!!)
            listOfExpItems = SampleExperiments.templateExpForLifeSpanAssay2(listOfExpItems!!, applicationContext, myDatabaseHandler!!, myAdapter!!)
            listOfExpItems = SampleExperiments.templateExpForLifeSpanAssayXX(listOfExpItems!!, applicationContext, myDatabaseHandler!!, myAdapter!!)
            myMenu!!.findItem(R.id.templateOpenerID).isVisible = false
        } else if (item.itemId==R.id.myMuteMode) {
            if (myBooleanMute) {
                item.iconTintList = getColorStateList(R.color.Black)
                myBooleanMute = false
            } else {
                item.iconTintList = getColorStateList(R.color.Red)
                myBooleanMute = true
            }
        }

        return super.onOptionsItemSelected(item)
    }
    //----------------------------------------------------------------------------------------------
    private fun checkDB(): Boolean {
        return myDatabaseHandler!!.getExpCount()>0
    }
    //----------------------------------------------------------------------------------------------
    private fun createPopupDialog() {
        val myView = layoutInflater.inflate(R.layout.popup_add_exp,null)
        listOfExpItems = NewExpPopup.runningPopup(false, 0 , myView, listOfExpItems, this, myAdapter!!)
    }
}