package com.example.swiperawesome

fun reproductiveSpanCalculator (mCondtn:Condition): Condition {

    val rSpanIndicatorDay = arrayOfNulls<Int>(mCondtn.totalC!!)
    val rSpanBooleanValue = arrayOfNulls<Boolean>(mCondtn.totalC!!)
    val maxCreator = 10

    for (cID in 1..mCondtn.totalC!!) {

        val ifCensored = IntArray(mCondtn.numColumnTotal!!) {mCondtn.numColumnTotal!!+maxCreator}
        val ifProgeny = IntArray(mCondtn.numColumnTotal!!) {0}
        val ifNoProgeny = IntArray(mCondtn.numColumnTotal!!) {0}
        val ifNoInput = IntArray(mCondtn.numColumnTotal!!) {mCondtn.numColumnTotal!!+maxCreator}
        //------------------------
        for (dayID in 1..mCondtn.numColumnTotal!!) {

            if (mCondtn.dataMatrix!! [cID-1] [dayID-1] == MyUtility.byte2Int(CensorRed)) {
                ifCensored[dayID-1]=dayID
            } else if (mCondtn.dataMatrix!! [cID-1] [dayID-1] == MyUtility.byte2Int(ProgenyGreen)) {
                ifProgeny[dayID-1]=dayID
            } else if (mCondtn.dataMatrix!! [cID-1] [dayID-1] ==MyUtility.byte2Int(NoProgenyBlue)) {
                ifNoProgeny[dayID-1]=dayID
            } else if (mCondtn.dataMatrix!! [cID-1] [dayID-1] == MyUtility.byte2Int(NoInputGray)) {
                ifNoInput[dayID-1]=dayID
            }
        }
        //----------------------- The whole logic for analyzing data
        if (ifCensored.sum()!=((mCondtn.numColumnTotal!!+maxCreator)*mCondtn.numColumnTotal!!)) {
            rSpanIndicatorDay [cID-1] = ifCensored.min()!!
            rSpanBooleanValue [cID-1] = false
        } else if (ifNoInput.sum()!=((mCondtn.numColumnTotal!!+maxCreator)*mCondtn.numColumnTotal!!)) {
            if (ifProgeny.max()!!+1== ifNoInput.min()) {
                rSpanIndicatorDay [cID-1] = NUMBER_OF_DAYS_RS
                rSpanBooleanValue [cID-1] = true
            } else if (ifNoProgeny.max()!!+1 == ifNoInput.min()) {
                rSpanIndicatorDay [cID-1] = ifProgeny.max()!!
                rSpanBooleanValue [cID-1] = true
            } else {
                rSpanIndicatorDay [cID-1] = NUMBER_OF_DAYS_RS
                rSpanBooleanValue [cID-1] = true
            }
        } else {
            rSpanIndicatorDay [cID-1] = ifProgeny.max()!!
            rSpanBooleanValue [cID-1] = true
        }
        //----------------------------------------------------------
    }
    mCondtn.dayStop = rSpanIndicatorDay
    mCondtn.censorB = rSpanBooleanValue
    return mCondtn
}
fun survivalAxisCalculator (mCondtn:Condition): Condition {



    var tmpXaxis = arrayOfNulls<Float>(mCondtn.numColumnTotal!!)
    var tmpTotalDaily = arrayOfNulls<Int>(mCondtn.numColumnTotal!!)
    var tmpPassDaily = arrayOfNulls<Int>(mCondtn.numColumnTotal!!)
    var tmpYaxis = arrayOfNulls<Float>(mCondtn.numColumnTotal!!)

    for (sDay in 1..mCondtn.numColumnTotal!!) {

        var tmpDailyLost:Int= 0
        var tmpTrueCounter:Int = 0
        var tmpFalseCounter:Int = 0

        for (ii in 1..mCondtn.totalC!!) {
            if(mCondtn.dayStop!![ii-1] == sDay) {
                tmpDailyLost += 1
                if (mCondtn.censorB!![ii-1]!!) {
                    tmpTrueCounter += 1
                } else if (!mCondtn.censorB!![ii-1]!!) {
                    tmpFalseCounter += 1
                }
            }
        }
        //---------------------------------
        tmpXaxis[sDay-1] = sDay.toFloat()
        if (sDay==1) {
            tmpPassDaily[sDay-1] = mCondtn.totalC!! - tmpDailyLost
            tmpTotalDaily[sDay-1] = mCondtn.totalC!! - tmpFalseCounter
        } else {
            tmpPassDaily[sDay-1] = tmpPassDaily[sDay-2]!! - tmpDailyLost
            tmpTotalDaily[sDay-1] = tmpTotalDaily[sDay-2]!! - tmpFalseCounter
        }
        tmpYaxis[sDay-1] = 100* (tmpPassDaily[sDay-1]!!.toFloat() / tmpTotalDaily[sDay-1]!!)
    }
    return mCondtn
}