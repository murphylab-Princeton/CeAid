package com.example.swiperawesome

import android.content.Context
import android.os.Build
import androidx.annotation.RequiresApi
import kotlin.collections.ArrayList
import kotlin.math.exp

object SampleExperiments {
    //----------------------------------------------------------------------------------------------
    fun templateExpForLifeSpanAssayXX (listOfExpItems:ArrayList<Experiment>, mContext: Context, myDatabaseHandler:ExpDatabaseHandler, myAdapter:ExpListAdapter):ArrayList<Experiment> {
        val a:Byte = AliveGreen
        val d:Byte = DeadBlue
        val c:Byte = CensorRed
        val i:Byte = NoInputGray
        val b:Byte = CensorBagged
        val l:Byte = CensorLost
        val e:Byte = CensorExploded
        //----------------------------------------------------
        val expInformation = Experiment()
        if (listOfExpItems.isNotEmpty()) {
            val previousExp = listOfExpItems.last()
            expInformation.id = previousExp.id?.plus(1)
        } else {expInformation.id = 1}
        expInformation.name = "Mated-Unmated LS"
        expInformation.startDate ="2021-03-10"
        expInformation.dayPointer = 1
        expInformation.numberingStyle = 0
        expInformation.testConditionName.add("N2-unmated")
        expInformation.testConditionName.add("eat2-unmated")
        expInformation.testConditionName.add("eat2-mated")
        expInformation.testConditionRange.add(66)
        expInformation.testConditionRange.add(132)
        expInformation.testConditionRange.add(200)
        expInformation.type = mContext.getString(R.string.LS_assayXX)
        myDatabaseHandler.createExpInfo(expInformation)
        listOfExpItems.add(expInformation)
        myAdapter.notifyItemInserted(listOfExpItems.size-1)
        val dayInfo = Array(MyUtility.findNumberOfColumns(mContext, expInformation.type!!)!!) { ByteArray(200) }
        //-----------------------------------------------
        dayInfo[0]   = byteArrayOf(i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,   i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,   i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i)
        dayInfo[1]   = byteArrayOf(i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,   i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,   i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i)
        dayInfo[2]   = byteArrayOf(a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,   a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,b,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,   a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i)
        dayInfo[3]   = byteArrayOf(a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,   a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,b,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,   a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,c,a,a,a,a,a,a,a,a,a,a,a,a,a,a,b,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,c,a,a)
        dayInfo[4]   = byteArrayOf(a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,b,a,a,a,b,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,b,a,a,a,a,b,a,a,a,a,c,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,   a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,b,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,   a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,c,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,c,a,a)
        dayInfo[5]   = byteArrayOf(a,c,a,a,a,a,a,a,a,a,a,a,a,a,a,b,a,b,a,a,a,b,a,a,a,a,a,a,a,a,a,a,b,e,b,a,a,a,a,a,b,a,a,a,a,b,a,a,b,a,c,a,a,e,a,a,a,a,a,a,a,a,a,a,a,c,   a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,b,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,b,a,a,a,   a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,c,a,a,c,a,a,a,b,a,c,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,c,a,a,a,a,a,c,a,a)
        dayInfo[6]   = byteArrayOf(a,c,a,a,a,a,a,a,a,a,a,a,a,a,a,b,a,b,a,a,c,b,a,a,a,a,a,a,a,a,a,a,b,e,b,a,b,a,a,a,b,a,a,a,a,b,a,a,b,a,c,c,a,e,a,a,a,a,a,a,a,a,a,a,a,c,   b,b,a,a,a,a,a,a,a,a,a,a,a,a,a,b,a,a,a,a,a,a,a,a,b,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,d,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,d,a,a,a,   a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,b,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,c,a,a,c,a,a,a,b,a,c,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,c,a,a,a,a,a,c,a,b)
        dayInfo[7]   = byteArrayOf(a,c,a,e,a,a,a,a,a,a,a,a,a,a,a,b,a,b,a,a,c,b,a,a,a,c,a,a,a,a,a,a,b,e,b,a,b,a,a,a,b,a,a,a,a,b,a,a,b,c,c,c,a,e,a,a,a,a,a,a,a,a,a,c,a,c,   b,b,a,a,a,a,a,b,a,a,a,a,a,a,a,b,a,a,a,a,a,a,a,a,b,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,d,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,d,a,b,a,   a,a,a,a,a,a,a,a,a,a,a,c,a,a,a,b,a,a,a,a,a,a,a,a,a,a,a,a,c,a,a,c,e,a,c,a,a,a,b,a,c,a,a,a,a,a,a,a,a,a,a,a,a,a,a,c,a,a,a,c,a,a,a,c,a,c,a,b)
        dayInfo[8]   = byteArrayOf(d,c,a,e,a,d,a,a,a,a,d,a,a,a,a,b,a,b,a,a,a,b,a,a,a,c,a,a,a,a,a,a,b,e,b,a,b,a,a,a,b,b,a,a,a,b,a,a,b,c,c,c,a,e,a,a,a,a,a,a,b,a,a,c,a,c,   b,b,a,a,a,a,a,b,a,a,a,a,a,a,a,b,a,a,a,a,a,a,a,a,b,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,d,a,a,a,a,a,a,a,a,a,a,a,b,a,a,a,a,a,a,a,a,d,a,b,a,   a,a,a,a,a,a,a,a,a,a,d,c,a,a,a,b,a,a,a,a,c,a,a,a,a,a,a,a,c,a,a,c,e,a,c,a,a,a,b,a,c,a,a,a,a,a,a,a,a,a,a,a,a,a,a,c,a,a,c,c,a,a,a,c,a,c,a,b)
        dayInfo[9]   = byteArrayOf(d,c,a,e,a,d,a,a,a,a,d,a,a,a,a,b,a,b,a,a,a,b,a,a,a,c,a,a,a,a,a,a,b,e,b,a,b,a,a,c,b,b,a,a,a,b,a,a,b,a,c,c,a,e,a,a,a,a,a,a,b,a,e,c,a,c,   b,b,a,a,a,a,a,b,a,a,a,a,a,a,a,b,a,a,a,a,a,a,a,a,b,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,d,a,a,a,a,a,a,a,a,a,a,a,b,a,a,a,a,a,a,d,a,d,a,b,a,   a,a,a,a,a,a,a,a,a,a,d,c,a,a,a,b,a,a,e,a,c,a,a,a,a,a,a,a,c,a,a,c,c,a,c,a,a,a,b,a,c,a,a,a,a,a,a,d,a,a,a,c,a,a,a,c,a,a,c,c,a,a,a,c,a,c,a,b)
        dayInfo[10]  = byteArrayOf(d,c,a,e,a,d,a,a,a,a,d,a,a,a,a,b,a,b,a,a,a,b,a,a,d,c,a,a,a,a,a,a,b,e,b,a,b,a,a,c,b,b,a,a,a,b,a,a,b,a,c,c,a,e,a,a,a,a,a,a,b,a,e,c,a,c,   b,b,a,a,a,a,a,b,a,d,a,a,e,a,a,b,a,a,a,a,a,a,a,a,b,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,d,e,a,a,a,a,a,a,a,a,a,a,b,a,a,a,a,d,a,d,a,d,a,b,a,   a,a,a,a,d,a,e,a,a,a,d,c,a,a,a,b,a,a,e,d,c,a,a,a,a,a,a,a,c,a,a,c,c,a,c,a,d,a,b,a,c,a,a,a,a,a,a,d,a,a,a,c,a,a,a,c,a,a,c,c,a,a,a,c,d,c,a,b)
        dayInfo[11]  = byteArrayOf(d,c,a,e,a,d,a,a,a,a,d,e,a,a,c,b,a,b,a,a,a,b,a,a,d,c,a,a,a,a,a,a,b,e,b,a,b,a,a,c,b,b,a,a,a,b,d,a,b,a,c,c,a,e,a,a,a,a,a,a,b,e,e,c,a,c,   b,b,a,a,a,a,a,b,a,d,a,a,e,a,a,b,a,a,a,a,a,a,a,a,b,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,d,e,a,a,a,a,e,a,a,a,a,a,b,a,a,a,a,a,a,d,a,d,a,b,a,   a,a,e,a,d,a,e,a,a,a,d,c,a,a,a,b,d,d,e,d,c,a,a,a,d,a,a,a,c,a,a,c,c,a,c,d,d,a,b,a,c,a,a,a,a,a,a,d,a,c,a,c,a,a,a,c,a,a,c,c,a,a,a,c,d,c,a,b)
        dayInfo[12]  = byteArrayOf(d,c,a,e,a,d,a,a,a,a,d,e,a,a,a,b,a,b,a,a,a,b,d,a,d,c,a,a,a,a,a,a,b,e,b,a,b,a,a,c,b,b,a,a,a,b,d,a,b,a,c,c,a,e,d,a,a,a,a,a,b,e,e,c,a,c,   b,b,d,a,a,a,a,b,a,d,a,a,e,a,a,b,a,a,a,a,a,a,a,a,b,a,a,a,a,a,a,a,a,a,a,a,e,a,a,a,a,d,e,c,a,a,a,e,a,a,a,a,a,b,a,a,a,a,a,a,d,a,d,a,b,a,   a,d,e,e,d,d,e,a,a,a,d,c,a,a,a,b,d,d,e,d,c,d,a,a,d,a,a,a,c,a,a,c,c,a,c,d,d,a,b,a,c,a,a,a,a,a,a,d,a,c,d,c,a,a,a,c,a,a,c,c,a,a,a,c,d,c,a,b)
        dayInfo[13]  = byteArrayOf(d,c,i,e,i,d,i,i,i,i,d,e,i,i,i,b,i,b,i,i,i,b,d,i,d,c,i,i,i,i,i,i,b,e,b,i,b,i,i,c,b,b,i,i,i,b,d,i,b,i,c,c,i,e,d,i,i,i,i,i,b,e,e,c,i,c,   b,b,d,i,i,i,i,b,i,d,i,i,e,i,i,b,i,i,i,i,i,i,i,i,b,i,i,i,i,i,i,i,i,i,i,i,e,i,i,i,i,d,e,c,i,i,i,e,i,i,i,i,i,b,i,i,i,i,i,i,d,i,d,i,b,i,   i,d,e,e,d,d,e,i,i,i,d,c,i,i,i,b,d,d,e,d,c,d,i,i,d,i,i,i,c,i,i,c,c,i,c,d,d,i,b,i,c,i,i,i,i,i,i,d,i,c,d,c,i,i,i,c,i,i,c,c,i,i,i,c,d,c,i,b)
        dayInfo[14]  = byteArrayOf(d,c,a,e,a,d,a,d,a,a,d,e,a,a,a,b,a,b,d,a,a,b,d,a,d,c,a,a,a,a,a,e,b,e,b,a,b,a,d,c,b,b,a,a,a,b,d,a,b,a,c,c,a,e,d,a,e,d,e,a,b,e,e,c,a,c,   b,b,d,d,a,a,a,b,d,d,a,a,e,a,a,b,a,a,a,a,a,a,a,a,b,a,a,a,e,e,a,d,a,a,a,a,e,a,a,a,a,d,e,c,a,a,a,e,a,a,a,a,a,b,a,a,a,a,a,a,d,a,d,a,b,a,   a,d,e,e,d,d,e,a,a,a,d,c,a,a,a,b,d,d,e,d,c,d,a,a,d,a,a,a,c,a,a,c,c,a,c,d,d,a,b,a,c,a,a,a,a,a,a,d,a,c,d,c,a,a,d,c,a,d,c,c,a,a,a,c,d,c,a,b)
        dayInfo[15]  = byteArrayOf(d,c,i,e,i,d,i,d,i,i,d,e,i,i,i,b,i,b,d,i,i,b,d,i,d,c,i,i,i,i,i,e,b,e,b,i,b,i,d,c,b,b,i,i,i,b,d,i,b,i,c,c,i,e,d,i,e,d,e,i,b,e,e,c,i,c,   b,b,d,d,i,i,i,b,d,d,i,i,e,i,i,b,i,i,i,i,i,i,i,i,b,i,i,i,e,e,i,d,i,i,i,i,e,i,i,i,i,d,e,c,i,i,i,e,i,i,i,i,i,b,i,i,i,i,i,i,d,i,d,i,b,i,   i,d,e,e,d,d,e,i,i,i,d,c,i,i,i,b,d,d,e,d,c,d,i,i,d,i,i,i,c,i,i,c,c,i,c,d,d,i,b,i,c,i,i,i,i,i,i,d,i,c,d,i,i,i,d,c,i,d,c,c,i,i,i,c,d,c,i,b)
        dayInfo[16]  = byteArrayOf(d,c,a,e,d,d,d,d,d,d,d,e,d,d,a,b,a,b,d,a,d,b,d,a,d,c,d,a,a,a,d,e,b,e,b,a,b,d,a,c,b,b,a,a,a,b,d,a,b,a,c,c,d,e,d,a,e,d,e,a,b,e,e,c,a,c,   b,b,d,a,a,a,a,b,a,d,a,a,e,d,a,b,d,a,a,a,a,a,a,a,b,a,d,a,e,e,a,d,a,a,a,a,e,a,a,a,a,d,e,c,a,a,d,e,a,a,a,a,a,b,a,a,a,a,a,a,d,a,d,a,b,a,   d,d,e,e,d,d,e,a,a,a,d,c,a,a,a,b,d,d,e,d,c,d,a,a,d,a,a,d,c,d,a,c,c,d,c,d,d,a,b,a,c,a,d,a,a,d,d,d,d,c,d,c,a,a,d,c,a,d,c,c,a,d,a,c,d,c,a,b)
        dayInfo[17]  = byteArrayOf(d,c,i,e,d,d,d,d,d,d,d,e,d,d,i,b,i,b,d,i,d,b,d,i,d,c,d,i,i,i,d,e,b,e,b,i,b,d,i,c,b,b,i,i,i,b,d,i,b,i,c,c,d,e,d,i,e,d,e,i,b,e,e,c,i,c,   b,b,d,i,i,i,i,b,i,d,i,i,e,d,i,b,d,i,i,i,i,i,i,i,b,i,d,i,e,e,i,d,i,i,i,i,e,i,i,i,i,d,e,c,i,i,d,e,i,i,i,i,i,b,i,i,i,i,i,i,d,i,d,i,b,i,   d,d,e,e,d,d,e,i,i,i,d,c,i,i,i,b,d,d,e,d,c,d,i,i,d,i,i,d,c,d,i,c,c,d,c,d,d,i,b,i,c,i,d,i,i,d,d,d,d,c,d,c,i,i,d,c,i,d,c,c,i,d,i,c,d,c,i,b)
        dayInfo[18]  = byteArrayOf(d,c,d,e,d,d,d,d,d,d,d,e,d,d,a,b,a,b,d,a,d,b,d,a,d,c,d,a,a,a,d,e,b,e,b,a,b,d,d,c,b,b,d,a,d,b,d,a,b,d,c,c,d,e,d,a,e,d,e,a,b,e,e,c,d,c,   b,b,d,a,a,a,a,b,a,d,a,a,e,d,e,b,d,a,a,a,a,d,d,a,b,a,d,a,e,e,a,d,a,a,a,a,e,a,a,a,a,d,e,c,d,d,d,e,a,a,a,a,a,b,a,d,a,a,a,d,d,d,d,a,b,d,   d,d,e,e,d,d,e,a,a,d,d,c,a,a,d,b,d,d,e,d,c,d,a,d,d,a,a,d,c,d,d,c,c,d,c,d,d,a,b,a,c,a,d,d,a,d,d,d,d,c,d,c,a,a,d,c,d,d,c,c,a,d,a,c,d,c,d,b)
        dayInfo[19]  = byteArrayOf(d,c,d,e,d,d,d,d,d,d,d,e,d,d,i,b,i,b,d,i,d,b,d,i,d,c,d,i,i,i,d,e,b,e,b,i,b,d,d,c,b,b,d,i,d,b,d,i,b,d,c,c,d,e,d,i,e,d,e,i,b,e,e,c,d,c,   b,b,d,i,i,i,i,b,i,d,i,i,e,d,e,b,d,i,i,i,i,d,d,i,b,i,d,i,e,e,i,d,i,i,i,i,e,i,i,i,i,d,e,c,d,d,d,e,i,i,i,i,i,b,i,d,i,i,i,d,d,d,d,i,b,d,   d,d,e,e,d,d,e,i,i,d,d,c,i,i,d,b,d,d,e,d,c,d,i,d,d,i,i,d,c,d,d,c,c,d,c,d,d,i,b,i,c,i,d,d,i,d,d,d,d,c,d,c,i,i,d,c,d,d,c,c,i,d,i,c,d,c,d,b)
        dayInfo[20]  = byteArrayOf(d,c,d,e,d,d,d,d,d,d,d,e,d,d,a,b,d,b,d,d,d,b,d,a,d,c,d,d,a,d,d,e,b,e,b,a,b,d,d,c,b,b,d,d,d,b,d,a,b,d,c,c,d,e,d,a,e,d,e,d,b,e,e,c,d,c,   b,b,d,a,a,a,a,b,d,d,a,a,e,d,e,b,d,a,a,a,d,d,d,a,b,a,d,a,e,e,a,d,a,d,a,a,e,a,a,a,a,d,e,c,d,d,d,e,a,a,a,a,a,b,a,d,a,a,a,d,d,d,d,a,b,d,   d,d,e,e,d,d,e,a,a,d,d,c,d,a,d,b,d,d,e,d,c,d,a,d,d,d,a,d,c,d,d,c,c,d,c,d,d,a,b,a,c,d,d,d,a,d,d,d,d,c,d,c,a,a,d,c,d,d,c,c,a,d,a,c,d,c,d,b)
        dayInfo[21]  = byteArrayOf(d,c,d,e,d,d,d,d,d,d,d,e,d,d,i,b,d,b,d,d,d,b,d,i,d,c,d,d,i,d,d,e,b,e,b,i,b,d,d,c,b,b,d,d,d,b,d,i,b,d,c,c,d,e,d,i,e,d,e,d,b,e,e,c,d,c,   b,b,d,i,i,i,i,b,d,d,i,i,e,d,e,b,d,i,i,i,d,d,d,i,b,i,d,i,e,e,i,d,i,d,i,i,e,i,i,i,i,d,e,c,d,d,d,e,i,i,i,i,i,b,i,d,i,i,i,d,d,d,d,i,b,d,   d,d,e,e,d,d,e,i,i,d,d,c,d,i,d,b,d,d,e,d,c,d,i,d,d,d,i,d,c,d,d,c,c,d,c,d,d,i,b,i,c,d,d,d,i,d,d,d,d,c,d,c,i,i,d,c,d,d,c,c,i,d,i,c,d,c,d,b)
        dayInfo[22]  = byteArrayOf(d,c,d,e,d,d,d,d,d,d,d,e,d,d,i,b,d,b,d,d,d,b,d,i,d,c,d,d,i,d,d,e,b,e,b,i,b,d,d,c,b,b,d,d,d,b,d,i,b,d,c,c,d,e,d,i,e,d,e,d,b,e,e,c,d,c,   b,b,d,i,i,i,i,b,d,d,i,i,e,d,e,b,d,i,i,i,d,d,d,i,b,i,d,i,e,e,i,d,i,d,i,i,e,i,i,i,i,d,e,c,d,d,d,e,i,i,i,i,i,b,i,d,i,i,i,d,d,d,d,i,b,d,   d,d,e,e,d,d,e,i,i,d,d,c,d,i,d,b,d,d,e,d,c,d,i,d,d,d,i,d,c,d,d,c,c,d,c,d,d,i,b,i,c,d,d,d,i,d,d,d,d,c,d,c,i,i,d,c,d,d,c,c,i,d,i,c,d,c,d,b)
        dayInfo[23]  = byteArrayOf(d,c,d,e,d,d,d,d,d,d,d,e,d,d,i,b,d,b,d,d,d,b,d,i,d,c,d,d,i,d,d,e,b,e,b,i,b,d,d,c,b,b,d,d,d,b,d,i,b,d,c,c,d,e,d,i,e,d,e,d,b,e,e,c,d,c,   b,b,d,i,i,i,i,b,d,d,i,i,e,d,e,b,d,i,i,i,d,d,d,i,b,i,d,i,e,e,i,d,i,d,i,i,e,i,i,i,i,d,e,c,d,d,d,e,i,i,i,i,i,b,i,d,i,i,i,d,d,d,d,i,b,d,   d,d,e,e,d,d,e,i,i,d,d,c,d,i,d,b,d,d,e,d,c,d,i,d,d,d,i,d,c,d,d,c,c,d,c,d,d,i,b,i,c,d,d,d,i,d,d,d,d,c,d,c,i,i,d,c,d,d,c,c,i,d,i,c,d,c,d,b)
        dayInfo[24]  = byteArrayOf(d,c,d,e,d,d,d,d,d,d,d,e,d,d,i,b,d,b,d,d,d,b,d,i,d,c,d,d,i,d,d,e,b,e,b,i,b,d,d,c,b,b,d,d,d,b,d,i,b,d,c,c,d,e,d,i,e,d,e,d,b,e,e,c,d,c,   b,b,d,i,i,i,i,b,d,d,i,i,e,d,e,b,d,i,i,i,d,d,d,i,b,i,d,i,e,e,i,d,i,d,i,i,e,i,i,i,i,d,e,c,d,d,d,e,i,i,i,i,i,b,i,d,i,i,i,d,d,d,d,i,b,d,   d,d,e,e,d,d,e,i,i,d,d,c,d,i,d,b,d,d,e,d,c,d,i,d,d,d,i,d,c,d,d,c,c,d,c,d,d,i,b,i,c,d,d,d,i,d,d,d,d,c,d,c,i,i,d,c,d,d,c,c,i,d,i,c,d,c,d,b)
        dayInfo[25]  = byteArrayOf(d,c,d,e,d,d,d,d,d,d,d,e,d,d,i,b,d,b,d,d,d,b,d,i,d,c,d,d,i,d,d,e,b,e,b,i,b,d,d,c,b,b,d,d,d,b,d,i,b,d,c,c,d,e,d,i,e,d,e,d,b,e,e,c,d,c,   b,b,d,i,i,i,i,b,d,d,i,i,e,d,e,b,d,i,i,i,d,d,d,i,b,i,d,i,e,e,i,d,i,d,i,i,e,i,i,i,i,d,e,c,d,d,d,e,i,i,i,i,i,b,i,d,i,i,i,d,d,d,d,i,b,d,   d,d,e,e,d,d,e,i,i,d,d,c,d,i,d,b,d,d,e,d,c,d,i,d,d,d,i,d,c,d,d,c,c,d,c,d,d,i,b,i,c,d,d,d,i,d,d,d,d,c,d,c,i,i,d,c,d,d,c,c,i,d,i,c,d,c,d,b)
        dayInfo[26]  = byteArrayOf(d,c,d,e,d,d,d,d,d,d,d,e,d,d,i,b,d,b,d,d,d,b,d,i,d,c,d,d,i,d,d,e,b,e,b,i,b,d,d,c,b,b,d,d,d,b,d,i,b,d,c,c,d,e,d,i,e,d,e,d,b,e,e,c,d,c,   b,b,d,i,i,i,i,b,d,d,i,i,e,d,e,b,d,i,i,i,d,d,d,i,b,i,d,i,e,e,i,d,i,d,i,i,e,i,i,i,i,d,e,c,d,d,d,e,i,i,i,i,i,b,i,d,i,i,i,d,d,d,d,i,b,d,   d,d,e,e,d,d,e,i,i,d,d,c,d,i,d,b,d,d,e,d,c,d,i,d,d,d,i,d,c,d,d,c,c,d,c,d,d,i,b,i,c,d,d,d,i,d,d,d,d,c,d,c,i,i,d,c,d,d,c,c,i,d,i,c,d,c,d,b)
        dayInfo[27]  = byteArrayOf(d,c,d,e,d,d,d,d,d,d,d,e,d,d,i,b,d,b,d,d,d,b,d,i,d,c,d,d,i,d,d,e,b,e,b,i,b,d,d,c,b,b,d,d,d,b,d,i,b,d,c,c,d,e,d,i,e,d,e,d,b,e,e,c,d,c,   b,b,d,i,i,i,i,b,d,d,i,i,e,d,e,b,d,i,i,i,d,d,d,i,b,i,d,i,e,e,i,d,i,d,i,i,e,i,i,i,i,d,e,c,d,d,d,e,i,i,i,i,i,b,i,d,i,i,i,d,d,d,d,i,b,d,   d,d,e,e,d,d,e,i,i,d,d,c,d,i,d,b,d,d,e,d,c,d,i,d,d,d,i,d,c,d,d,c,c,d,c,d,d,i,b,i,c,d,d,d,i,d,d,d,d,c,d,c,i,i,d,c,d,d,c,c,i,d,i,c,d,c,d,b)
        dayInfo[28]  = byteArrayOf(d,c,d,e,d,d,d,d,d,d,d,e,d,d,i,b,d,b,d,d,d,b,d,i,d,c,d,d,i,d,d,e,b,e,b,i,b,d,d,c,b,b,d,d,d,b,d,i,b,d,c,c,d,e,d,i,e,d,e,d,b,e,e,c,d,c,   b,b,d,i,i,i,i,b,d,d,i,i,e,d,e,b,d,i,i,i,d,d,d,i,b,i,d,i,e,e,i,d,i,d,i,i,e,i,i,i,i,d,e,c,d,d,d,e,i,i,i,i,i,b,i,d,i,i,i,d,d,d,d,i,b,d,   d,d,e,e,d,d,e,i,i,d,d,c,d,i,d,b,d,d,e,d,c,d,i,d,d,d,i,d,c,d,d,c,c,d,c,d,d,i,b,i,c,d,d,d,i,d,d,d,d,c,d,c,i,i,d,c,d,d,c,c,i,d,i,c,d,c,d,b)
        dayInfo[29]  = byteArrayOf(d,c,d,e,d,d,d,d,d,d,d,e,d,d,i,b,d,b,d,d,d,b,d,i,d,c,d,d,i,d,d,e,b,e,b,i,b,d,d,c,b,b,d,d,d,b,d,i,b,d,c,c,d,e,d,i,e,d,e,d,b,e,e,c,d,c,   b,b,d,i,i,i,i,b,d,d,i,i,e,d,e,b,d,i,i,i,d,d,d,i,b,i,d,i,e,e,i,d,i,d,i,i,e,i,i,i,i,d,e,c,d,d,d,e,i,i,i,i,i,b,i,d,i,i,i,d,d,d,d,i,b,d,   d,d,e,e,d,d,e,i,i,d,d,c,d,i,d,b,d,d,e,d,c,d,i,d,d,d,i,d,c,d,d,c,c,d,c,d,d,i,b,i,c,d,d,d,i,d,d,d,d,c,d,c,i,i,d,c,d,d,c,c,i,d,i,c,d,c,d,b)

        for (ii in 1..30) {
            myDatabaseHandler.updateByteArrayAtOneColumn(expInformation.id!!, ii, dayInfo[ii-1] )
        }
        //------------------------------------------------
        return listOfExpItems
    }
    //----------------------------------------------------------------------------------------------
    @RequiresApi(Build.VERSION_CODES.N)
    fun templateExpForChoiceAssay(listOfExpItems:ArrayList<Experiment>, mContext: Context, myDatabaseHandler:ExpDatabaseHandler, myAdapter:ExpListAdapter):ArrayList<Experiment>  {

        val expInformation = Experiment()
        val i = MyUtility.byte2Int(NoInputGray)
        if (listOfExpItems.isNotEmpty()) {
            val previousExp = listOfExpItems.last()
            expInformation.id = previousExp.id?.plus(1)
        } else {expInformation.id = 1}
        expInformation.name = "Sample choice assay,6"
        expInformation.startDate ="2020-06-26"
        expInformation.dayPointer = 1
        expInformation.numberingStyle = 0
        expInformation.testConditionName.add("M.luteus,OP50,M.l.")
        expInformation.testConditionName.add("OP50,OP50,M.I.")
        expInformation.testConditionName.add("S.enterica,OP50,S.e.")
        expInformation.testConditionName.add("OP50,OP50,S.e.")
        expInformation.testConditionName.add("P.fluorescens15,OP50,Pf15")
        expInformation.testConditionName.add("OP50,OP50,Pf15")
        expInformation.testConditionName.add("Jub19,OP50,Jub19")
        expInformation.testConditionName.add("OP50,OP50,Jub19")
        expInformation.testConditionName.add("F.johnsoniae,OP50,F.j.")
        expInformation.testConditionName.add("OP50,OP50,F.j.")
        expInformation.testConditionName.add("Jub5,OP50,Jub56")
        expInformation.testConditionName.add("OP50,OP50,Jub56")
        expInformation.testConditionName.add("GRb0427,OP50,GRb0427")
        expInformation.testConditionName.add("OP50,OP50,GRb0427")
        expInformation.testConditionName.add("S.marcescans,OP50,Sm")
        expInformation.testConditionName.add("OP50,OP50,Sm")
        expInformation.testConditionName.add("PA14,OP50,PA14")
        expInformation.testConditionName.add("OP50,OP50,PA14")
        //------------------------------------------------------------
        expInformation.testConditionRange.add(10)
        expInformation.testConditionRange.add(16)
        expInformation.testConditionRange.add(25)
        expInformation.testConditionRange.add(31)
        expInformation.testConditionRange.add(40)
        expInformation.testConditionRange.add(46)
        expInformation.testConditionRange.add(56)
        expInformation.testConditionRange.add(62)
        expInformation.testConditionRange.add(72)
        expInformation.testConditionRange.add(78)
        expInformation.testConditionRange.add(88)
        expInformation.testConditionRange.add(94)
        expInformation.testConditionRange.add(104)
        expInformation.testConditionRange.add(110)
        expInformation.testConditionRange.add(121)
        expInformation.testConditionRange.add(127)
        expInformation.testConditionRange.add(137)
        expInformation.testConditionRange.add(143)
        //------------------------------------------------------------
        expInformation.type = mContext.getString(R.string.ChoiceAssay)
        myDatabaseHandler.createExpInfo(expInformation)
        listOfExpItems.add(expInformation)
        myAdapter.notifyItemInserted(listOfExpItems.size-1)

        val leftChoiceIntegers = intArrayOf(37,35,53,64,14,i,18,34,37,16,25,18,9,2,12,20,5,35,18,38,31,42,i,18,53,15,8,8,2,12,3,33,39,34,12,13,39,31,37,23,24,22,14,36,14,29,54,58,63,19,72,42,68,51,31,44,34,42,20,30,20,24,36,50,55,30,34,29,18,44,33,76,1,13,15,38,5,17,16,31,30,45,40,28,26,13,16,21,30,26,8,11,17,7,28,21,27,55,21,37,32,25,24,26,12,4,6,4,3,26,43,26,42,32,38,72,38,20,35,33,26,7,7,12,3,2,10,55,30,59,67,100,103,66,92,50,98,25,24,23,27,20,62)
        val rightChoiceIntegers = intArrayOf(i,73,133,107,84,86,69,57,52,42,24,41,31,12,49,56,12,83,77,68,137,82,37,48,74,67,49,19,11,54,11,49,67,49,55,45,95,33,72,33,54,43,26,71,28,41,28,37,45,31,83,57,50,57,51,62,17,36,23,38,22,36,37,57,113,49,50,51,41,96,53,85,25,69,56,69,21,59,67,41,72,35,38,59,60,37,55,75,29,26,19,14,72,21,53,25,42,68,48,37,38,61,34,65,64,20,28,47,17,33,89,56,101,72,62,71,62,66,82,49,86,73,48,18,27,37,25,70,42,87,48,110,90,98,27,68,147,58,23,29,24,25,35)

        myDatabaseHandler.updateByteArrayAtOneColumn(expInformation.id!!, 1, MyUtility.intArray2ByteArrayConverter(leftChoiceIntegers) )
        myDatabaseHandler.updateByteArrayAtOneColumn(expInformation.id!!, 2, MyUtility.intArray2ByteArrayConverter(rightChoiceIntegers) )
        return listOfExpItems
    }
    //----------------------------------------------------------------------------------------------
    fun templateExpForProgenyCountAssay (listOfExpItems:ArrayList<Experiment>, mContext: Context, myDatabaseHandler:ExpDatabaseHandler, myAdapter:ExpListAdapter):ArrayList<Experiment> {

        val expInformation = Experiment()
        if (listOfExpItems.isNotEmpty()) {
            val previousExp = listOfExpItems.last()
            expInformation.id = previousExp.id?.plus(1)
        } else {expInformation.id = 1}
        expInformation.name = "OP50-PA14-nhr49,60"
        expInformation.startDate ="2020-05-07"
        expInformation.dayPointer = 1
        expInformation.numberingStyle = 0
        expInformation.testConditionName.add("N2 Fed OP50")
        expInformation.testConditionName.add("F1 PA14 Mixed")
        expInformation.testConditionName.add("nhr-49 Fed")
        expInformation.testConditionRange.add(50)
        expInformation.testConditionRange.add(100)
        expInformation.testConditionRange.add(150)
        expInformation.type = mContext.getString(R.string.ProgenyAssay)
        myDatabaseHandler.createExpInfo(expInformation)
        listOfExpItems.add(expInformation)
        myAdapter.notifyItemInserted(listOfExpItems.size-1)
        //-----------------------------------------------
        val i:Int = MyUtility.byte2Int(NoInputGray)
        val day0ProgenyAssay00 = intArrayOf(172,147,183,212,219,224,171,82,81,163,238,154,176,144,161,181,231,188,157,174,211,158,206,201,155,176,166,176,196,148,171,168,191,134,132,171,213,200,156,189,197,145,120,197,163,173,123,198,190,159,i,9,28,22,7,9,i,15,8,29,18,22,i,17,28,15,3,i,i,3,13,18,10,1,6,14,32,26,28,11,13,41,12,i,8,3,i,i,27,i,11,7,i,i,22,5,11,3,1,17,124,i,i,134,140,114,i,105,116,113,143,i,126,125,139,75,126,109,124,144,107,115,126,128,118,91,131,113,147,i,113,121,117,112,104,77,78,66,104,109,5,124,127,123,121,79,132,i,111,89)
        val day1ProgenyAssay00 = intArrayOf(34,65,10,88,55,25,13,i,10,64,62,4,130,8,49,57,10,14,62,8,43,9,42,8,14,74,21,6,56,25,7,30,12,57,12,52,48,11,23,42,4,76,18,8,42,46,2,6,34,62,i,28,40,25,29,35,i,23,16,44,43,44,i,46,62,76,11,i,i,1,43,43,24,i,46,34,57,76,79,52,34,81,52,i,46,71,i,i,37,i,20,36,i,i,13,29,29,i,15,30,71,i,i,33,83,14,i,75,32,92,42,i,40,i,63,38,50,87,41,78,65,83,86,59,66,69,56,52,20,i,62,56,112,31,57,21,93,39,77,7,49,54,21,53,12,78,29,38,66,46)
        val day2ProgenyAssay00 = intArrayOf(2,1,1,9,3,i,i,i,1,2,3,i,14,2,i,13,10,4,7,i,i,1,5,3,1,i,i,4,6,2,21,5,1,31,7,i,1,2,3,i,i,9,1,1,i,i,i,i,i,10,i,23,31,1,45,31,i,14,21,10,14,20,i,26,1,138,12,i,59,i,59,3,3,i,4,1,6,71,22,42,25,41,50,i,37,93,i,i,26,i,35,32,i,i,18,46,9,i,1,35,21,i,i,1,1,8,i,i,6,17,28,i,2,i,6,14,1,7,2,1,14,10,2,4,1,7,3,14,2,i,1,5,24,1,i,3,25,i,4,1,i,2,24,i,4,49,i,5,i,6)
        val day3ProgenyAssay00 = intArrayOf(i,6,i,i,2,i,i,i,i,i,i,i,i,i,i,5,5,i,4,i,i,i,i,i,i,4,i,3,1,1,3,i,i,i,1,3,i,i,i,i,i,i,i,1,1,i,i,i,i,1,i,1,2,i,2,7,i,i,3,6,i,i,i,i,i,37,2,i,i,i,1,1,1,i,1,i,i,3,12,18,i,6,23,i,8,32,i,i,3,i,5,7,i,i,12,6,3,i,i,6,4,i,i,i,i,4,i,i,i,i,i,i,i,i,6,i,i,i,i,i,i,i,i,i,i,i,3,2,i,i,i,i,12,i,11,64,i,1,i,i,7,i,i,i,1,1,i,i,i,1)
        val day4ProgenyAssay00 = intArrayOf(3,i,i,i,i,i,i,i,i,i,i,i,i,i,i,1,i,i,i,1,i,i,i,i,i,i,i,10,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,1,i,i,2,i,i,i,2,i,i,i,i,i,8,i,i,i,i,1,i,1,i,i,1,i,i,i,i,i,i,i,i,3,3,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,1,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i)
        val day5ProgenyAssay00 = intArrayOf(i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,14,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,3,3,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i)
        val day6ProgenyAssay00 = intArrayOf(i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,1,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,2,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i)

        val day0ProgenyAssay11 = intArrayOf(34,29,36,42,43,44,34,16,16,32,47,30,35,28,32,36,46,37,31,34,42,31,41,40,31,35,33,35,39,29,34,33,38,26,26,34,42,40,31,37,39,29,24,39,32,34,24,39,38,31,i,1,5,4,1,1,i,3,1,5,3,4,i,3,5,3,0,i,i,0,2,3,2,0,1,2,6,5,5,2,2,8,2,i,1,0,i,i,5,i,2,1,i,i,4,1,2,0,0,3,24,i,i,26,28,22,i,21,23,22,28,i,25,25,27,15,25,21,24,28,21,23,25,25,23,18,26,22,29,i,22,24,23,22,20,15,15,13,20,21,1,24,25,24,24,15,26,i,22,17)
        val day1ProgenyAssay11 = intArrayOf(6,13,2,17,11,5,2,i,2,12,12,0,26,1,9,11,2,2,12,1,8,1,8,1,2,14,4,1,11,5,1,6,2,11,2,10,9,2,4,8,0,15,3,1,8,9,0,1,6,12,i,5,8,5,5,7,i,4,3,8,8,8,i,9,12,15,2,i,i,0,8,8,4,i,9,6,11,15,15,10,6,16,10,i,9,14,i,i,7,i,4,7,i,i,2,5,5,i,3,6,14,i,i,6,16,2,i,15,6,18,8,i,8,i,12,7,10,17,8,15,13,16,17,11,13,13,11,10,4,i,12,11,22,6,11,4,18,7,15,1,9,10,4,10,2,15,5,7,13,9)
        val day2ProgenyAssay11 = intArrayOf(0,0,0,1,0,i,i,i,0,0,0,i,2,0,i,2,2,0,1,i,i,0,1,0,0,i,i,0,1,0,4,1,0,6,1,i,0,0,0,i,i,1,0,0,i,i,i,i,i,2,i,4,6,0,9,6,i,2,4,2,2,4,i,5,0,27,2,i,11,i,11,0,0,i,0,0,1,14,4,8,5,8,10,i,7,18,i,i,5,i,7,6,i,i,3,9,1,i,0,7,4,i,i,0,0,1,i,i,1,3,5,i,0,i,1,2,0,1,0,0,2,2,0,0,0,1,0,2,0,i,0,1,4,0,i,0,5,i,0,0,i,0,4,i,0,9,i,1,i,1)
        val day3ProgenyAssay11 = intArrayOf(i,1,i,i,0,i,i,i,i,i,i,i,i,i,i,1,1,i,0,i,i,i,i,i,i,0,i,0,0,0,0,i,i,i,0,0,i,i,i,i,i,i,i,0,0,i,i,i,i,0,i,0,0,i,0,1,i,i,0,1,i,i,i,i,i,7,0,i,i,i,0,0,0,i,0,i,i,0,2,3,i,1,4,i,1,6,i,i,0,i,1,1,i,i,2,1,0,i,i,1,0,i,i,i,i,0,i,i,i,i,i,i,i,i,1,i,i,i,i,i,i,i,i,i,i,i,0,0,i,i,i,i,2,i,2,12,i,0,i,i,1,i,i,i,0,0,i,i,i,0)
        val day4ProgenyAssay11 = intArrayOf( 0,i,i,i,i,i,i,i,i,i,i,i,i,i,i,0,i,i,i,0,i,i,i,i,i,i,i,2,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,0,i,i,0,i,i,i,0,i,i,i,i,i,1,i,i,i,i,0,i,0,i,i,0,i,i,i,i,i,i,i,i,0,0,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,0,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i)
        val day5ProgenyAssay11 = intArrayOf(i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,2,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,0,0,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i)
        val day6ProgenyAssay11 = intArrayOf(i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,0,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,0,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i)

        val day0ProgenyAssay22 = intArrayOf(34,29,36,42,43,44,34,16,16,32,47,30,35,28,32,36,46,37,31,34,42,31,41,40,31,35,33,35,39,29,34,33,38,26,26,34,42,40,31,37,39,29,24,39,32,34,24,39,38,31,i,1,5,4,1,1,i,3,1,5,3,4,i,3,5,3,0,i,i,0,2,3,2,0,1,2,6,5,5,2,2,8,2,i,1,0,i,i,5,i,2,1,i,i,4,1,2,0,0,3,24,i,i,26,28,22,i,21,23,22,28,i,25,25,27,15,25,21,24,28,21,23,25,25,23,18,26,22,29,i,22,24,23,22,20,15,15,13,20,21,1,24,25,24,24,15,26,i,22,17)
        val day1ProgenyAssay22 = intArrayOf(6,13,2,17,11,5,2,i,2,12,12,0,26,1,9,11,2,2,12,1,8,1,8,1,2,14,4,1,11,5,1,6,2,11,2,10,9,2,4,8,0,15,3,1,8,9,0,1,6,12,i,5,8,5,5,7,i,4,3,8,8,8,i,9,12,15,2,i,i,0,8,8,4,i,9,6,11,15,15,10,6,16,10,i,9,14,i,i,7,i,4,7,i,i,2,5,5,i,3,6,14,i,i,6,16,2,i,15,6,18,8,i,8,i,12,7,10,17,8,15,13,16,17,11,13,13,11,10,4,i,12,11,22,6,11,4,18,7,15,1,9,10,4,10,2,15,5,7,13,9)
        val day2ProgenyAssay22 = intArrayOf(0,0,0,1,0,i,i,i,0,0,0,i,2,0,i,2,2,0,1,i,i,0,1,0,0,i,i,0,1,0,4,1,0,6,1,i,0,0,0,i,i,1,0,0,i,i,i,i,i,2,i,4,6,0,9,6,i,2,4,2,2,4,i,5,0,27,2,i,11,i,11,0,0,i,0,0,1,14,4,8,5,8,10,i,7,18,i,i,5,i,7,6,i,i,3,9,1,i,0,7,4,i,i,0,0,1,i,i,1,3,5,i,0,i,1,2,0,1,0,0,2,2,0,0,0,1,0,2,0,i,0,1,4,0,i,0,5,i,0,0,i,0,4,i,0,9,i,1,i,1)
        val day3ProgenyAssay22 = intArrayOf(i,1,i,i,0,i,i,i,i,i,i,i,i,i,i,1,1,i,0,i,i,i,i,i,i,0,i,0,0,0,0,i,i,i,0,0,i,i,i,i,i,i,i,0,0,i,i,i,i,0,i,0,0,i,0,1,i,i,0,1,i,i,i,i,i,7,0,i,i,i,0,0,0,i,0,i,i,0,2,3,i,1,4,i,1,6,i,i,0,i,1,1,i,i,2,1,0,i,i,1,0,i,i,i,i,0,i,i,i,i,i,i,i,i,1,i,i,i,i,i,i,i,i,i,i,i,0,0,i,i,i,i,2,i,2,12,i,0,i,i,1,i,i,i,0,0,i,i,i,0)
        val day4ProgenyAssay22 = intArrayOf( 0,i,i,i,i,i,i,i,i,i,i,i,i,i,i,0,i,i,i,0,i,i,i,i,i,i,i,2,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,0,i,i,0,i,i,i,0,i,i,i,i,i,1,i,i,i,i,0,i,0,i,i,0,i,i,i,i,i,i,i,i,0,0,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,0,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i)
        val day5ProgenyAssay22 = intArrayOf(i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,2,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,0,0,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i)
        val day6ProgenyAssay22 = intArrayOf(i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,0,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,0,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i)

        val day0ProgenyAssay = ArrayList<ByteArray>()
        val day1ProgenyAssay = ArrayList<ByteArray>()
        val day2ProgenyAssay = ArrayList<ByteArray>()
        val day3ProgenyAssay = ArrayList<ByteArray>()
        val day4ProgenyAssay = ArrayList<ByteArray>()
        val day5ProgenyAssay = ArrayList<ByteArray>()
        val day6ProgenyAssay = ArrayList<ByteArray>()

        //val day6ProgenyAssay = ArrayList(3) { ByteArray(150) }
        day0ProgenyAssay.add(MyUtility.intArray2ByteArrayConverter(day0ProgenyAssay00))
        day1ProgenyAssay.add(MyUtility.intArray2ByteArrayConverter(day1ProgenyAssay00))
        day2ProgenyAssay.add(MyUtility.intArray2ByteArrayConverter(day2ProgenyAssay00))
        day3ProgenyAssay.add(MyUtility.intArray2ByteArrayConverter(day3ProgenyAssay00))
        day4ProgenyAssay.add(MyUtility.intArray2ByteArrayConverter(day4ProgenyAssay00))
        day5ProgenyAssay.add(MyUtility.intArray2ByteArrayConverter(day5ProgenyAssay00))
        day6ProgenyAssay.add(MyUtility.intArray2ByteArrayConverter(day6ProgenyAssay00))

        day0ProgenyAssay.add(MyUtility.intArray2ByteArrayConverter(day0ProgenyAssay11))
        day1ProgenyAssay.add(MyUtility.intArray2ByteArrayConverter(day1ProgenyAssay11))
        day2ProgenyAssay.add(MyUtility.intArray2ByteArrayConverter(day2ProgenyAssay11))
        day3ProgenyAssay.add(MyUtility.intArray2ByteArrayConverter(day3ProgenyAssay11))
        day4ProgenyAssay.add(MyUtility.intArray2ByteArrayConverter(day4ProgenyAssay11))
        day5ProgenyAssay.add(MyUtility.intArray2ByteArrayConverter(day5ProgenyAssay11))
        day6ProgenyAssay.add(MyUtility.intArray2ByteArrayConverter(day6ProgenyAssay11))

        day0ProgenyAssay.add(MyUtility.intArray2ByteArrayConverter(day0ProgenyAssay22))
        day1ProgenyAssay.add(MyUtility.intArray2ByteArrayConverter(day1ProgenyAssay22))
        day2ProgenyAssay.add(MyUtility.intArray2ByteArrayConverter(day2ProgenyAssay22))
        day3ProgenyAssay.add(MyUtility.intArray2ByteArrayConverter(day3ProgenyAssay22))
        day4ProgenyAssay.add(MyUtility.intArray2ByteArrayConverter(day4ProgenyAssay22))
        day5ProgenyAssay.add(MyUtility.intArray2ByteArrayConverter(day5ProgenyAssay22))
        day6ProgenyAssay.add(MyUtility.intArray2ByteArrayConverter(day6ProgenyAssay22))
        //----------------------------------------------------
        myDatabaseHandler.updateByteArrayAtColumns (expInformation.id!!, 1, day0ProgenyAssay)
        myDatabaseHandler.updateByteArrayAtColumns (expInformation.id!!, 2, day1ProgenyAssay)
        myDatabaseHandler.updateByteArrayAtColumns (expInformation.id!!, 3, day2ProgenyAssay)
        myDatabaseHandler.updateByteArrayAtColumns (expInformation.id!!, 4, day3ProgenyAssay)
        myDatabaseHandler.updateByteArrayAtColumns (expInformation.id!!, 5, day4ProgenyAssay)
        myDatabaseHandler.updateByteArrayAtColumns (expInformation.id!!, 6, day5ProgenyAssay)
        myDatabaseHandler.updateByteArrayAtColumns (expInformation.id!!, 7, day6ProgenyAssay)
        //------------------------------------------------
        return listOfExpItems
    }
    //----------------------------------------------------------------------------------------------
    fun templateExpForLifeSpanAssay (listOfExpItems:ArrayList<Experiment>, mContext: Context, myDatabaseHandler:ExpDatabaseHandler, myAdapter:ExpListAdapter):ArrayList<Experiment> {

        val expInformation = Experiment()
        if (listOfExpItems.isNotEmpty()) {
            val previousExp = listOfExpItems.last()
            expInformation.id = previousExp.id?.plus(1)
        } else {expInformation.id = 1}
        expInformation.name = "LS cer1,50"
        expInformation.startDate ="2020-08-30"
        expInformation.dayPointer = 1
        expInformation.numberingStyle = 0
        expInformation.testConditionName.add("Control(RNAi)")
        expInformation.testConditionName.add("cer1(RNAi)")
        expInformation.testConditionRange.add(4)
        expInformation.testConditionRange.add(8)
        expInformation.type = mContext.getString(R.string.LS_assay)
        myDatabaseHandler.createExpInfo(expInformation)
        listOfExpItems.add(expInformation)
        myAdapter.notifyItemInserted(listOfExpItems.size-1)
        //-----------------------------------------------
        val i:Int = MyUtility.byte2Int(NoInputGray)

        val day1LSpanAlive = intArrayOf(25,25,25,25,28,28,27,27)
        val day8LSpanAlive = intArrayOf(25,25,25,25,26,26,27,27)
        val day9LSpanAlive = intArrayOf(25,25,25,25,26,26,27,27)
        val day12LSpanAlive = intArrayOf(20,21,20,21,22,23,22,22)
        val day13LSpanAlive = intArrayOf(20,21,20,21,i,i,i,i)
        val day14LSpanAlive = intArrayOf(19,20,19,20,21,23,20,22)
        val day15LSpanAlive = intArrayOf(17,18,17,18,19,21,18,20)
        val day17LSpanAlive = intArrayOf(15,15,15,15,17,17,17,18)
        val day18LSpanAlive = intArrayOf(14,15,14,15,17,17,17,18)
        val day20LSpanAlive = intArrayOf(13,14,13,14,16,16,16,16)
        val day22LSpanAlive = intArrayOf(7,7,8,8,9,9,9,8)
        val day23LSpanAlive = intArrayOf(6,5,5,5,9,9,9,8)
        val day26LSpanAlive = intArrayOf(2,2,2,2,6,7,7,6)
        val day28LSpanAlive = intArrayOf(0,0,0,0,4,5,5,4)
        val day30LSpanAlive = intArrayOf(i,i,i,i,3,3,3,3)
        val day31LSpanAlive = intArrayOf(i,i,i,i,2,2,1,1)

        val day1LSpanDead = intArrayOf(i,i,i,i,0,0,0,0)
        val day8LSpanDead = intArrayOf(0,0,0,0,2,2,0,0)
        val day9LSpanDead = intArrayOf(0,0,0,0,0,0,0,0)
        val day12LSpanDead = intArrayOf(0,0,0,0,1,1,1,2)
        val day13LSpanDead = intArrayOf(0,0,0,0,i,i,i,i)
        val day14LSpanDead = intArrayOf(1,1,1,1,1,0,1,0)
        val day15LSpanDead = intArrayOf(2,2,2,2,1,2,2,1)
        val day17LSpanDead = intArrayOf(2,3,2,3,2,2,1,2)
        val day18LSpanDead = intArrayOf(1,0,1,0,0,0,0,0)
        val day20LSpanDead = intArrayOf(1,1,1,1,1,1,1,2)
        val day22LSpanDead = intArrayOf(3,4,3,3,6,7,7,6)
        val day23LSpanDead = intArrayOf(1,2,3,3,0,0,0,0)
        val day26LSpanDead = intArrayOf(4,3,3,3,3,2,2,2)
        val day28LSpanDead = intArrayOf(2,2,2,2,2,2,2,2)
        val day30LSpanDead = intArrayOf(i,i,i,i,1,2,2,1)
        val day31LSpanDead = intArrayOf(i,i,i,i,0,1,1,1)

        val day1LSpanCensored = intArrayOf(i,i,i,i,i,i,i,i)
        val day8LSpanCensored = intArrayOf(i,i,i,i,i,i,i,i)
        val day9LSpanCensored = intArrayOf(i,i,i,i,i,i,i,i)
        val day12LSpanCensored = intArrayOf(i,i,i,i,i,i,i,i)
        val day13LSpanCensored = intArrayOf(i,i,i,i,i,i,i,i)
        val day14LSpanCensored = intArrayOf(i,i,i,i,i,i,1,i)
        val day15LSpanCensored = intArrayOf(i,i,i,i,1,0,0,1)
        val day17LSpanCensored = intArrayOf(i,i,i,i,i,i,i,i)
        val day18LSpanCensored = intArrayOf(i,i,i,i,i,i,i,i)
        val day20LSpanCensored = intArrayOf(i,i,i,i,i,i,i,i)
        val day22LSpanCensored = intArrayOf(i,i,i,i,1,0,0,2)
        val day23LSpanCensored = intArrayOf(i,i,i,i,i,i,i,i)
        val day26LSpanCensored = intArrayOf(i,i,i,i,i,i,i,i)
        val day28LSpanCensored = intArrayOf(i,i,i,i,i,i,i,i)
        val day30LSpanCensored = intArrayOf(i,i,i,i,i,i,i,i)
        val day31LSpanCensored = intArrayOf(i,i,i,i,i,i,i,i)

        val day1LSpan = ArrayList<ByteArray>() ; day1LSpan.add(MyUtility.intArray2ByteArrayConverter(day1LSpanAlive))
        val day8LSpan = ArrayList<ByteArray>() ; day8LSpan.add(MyUtility.intArray2ByteArrayConverter(day8LSpanAlive))
        val day9LSpan = ArrayList<ByteArray>() ; day9LSpan.add(MyUtility.intArray2ByteArrayConverter(day9LSpanAlive))
        val day12LSpan = ArrayList<ByteArray>() ; day12LSpan.add(MyUtility.intArray2ByteArrayConverter(day12LSpanAlive))
        val day13LSpan = ArrayList<ByteArray>() ; day13LSpan.add(MyUtility.intArray2ByteArrayConverter(day13LSpanAlive))
        val day14LSpan = ArrayList<ByteArray>() ; day14LSpan.add(MyUtility.intArray2ByteArrayConverter(day14LSpanAlive))
        val day15LSpan = ArrayList<ByteArray>() ; day15LSpan.add(MyUtility.intArray2ByteArrayConverter(day15LSpanAlive))
        val day17LSpan = ArrayList<ByteArray>() ; day17LSpan.add(MyUtility.intArray2ByteArrayConverter(day17LSpanAlive))
        val day18LSpan = ArrayList<ByteArray>() ; day18LSpan.add(MyUtility.intArray2ByteArrayConverter(day18LSpanAlive))
        val day20LSpan = ArrayList<ByteArray>() ; day20LSpan.add(MyUtility.intArray2ByteArrayConverter(day20LSpanAlive))
        val day22LSpan = ArrayList<ByteArray>() ; day22LSpan.add(MyUtility.intArray2ByteArrayConverter(day22LSpanAlive))
        val day23LSpan = ArrayList<ByteArray>() ; day23LSpan.add(MyUtility.intArray2ByteArrayConverter(day23LSpanAlive))
        val day26LSpan = ArrayList<ByteArray>() ; day26LSpan.add(MyUtility.intArray2ByteArrayConverter(day26LSpanAlive))
        val day28LSpan = ArrayList<ByteArray>() ; day28LSpan.add(MyUtility.intArray2ByteArrayConverter(day28LSpanAlive))
        val day30LSpan = ArrayList<ByteArray>() ; day30LSpan.add(MyUtility.intArray2ByteArrayConverter(day30LSpanAlive))
        val day31LSpan = ArrayList<ByteArray>() ; day31LSpan.add(MyUtility.intArray2ByteArrayConverter(day31LSpanAlive))

        day1LSpan.add(MyUtility.intArray2ByteArrayConverter(day1LSpanDead))
        day8LSpan.add(MyUtility.intArray2ByteArrayConverter(day8LSpanDead))
        day9LSpan.add(MyUtility.intArray2ByteArrayConverter(day9LSpanDead))
        day12LSpan.add(MyUtility.intArray2ByteArrayConverter(day12LSpanDead))
        day13LSpan.add(MyUtility.intArray2ByteArrayConverter(day13LSpanDead))
        day14LSpan.add(MyUtility.intArray2ByteArrayConverter(day14LSpanDead))
        day15LSpan.add(MyUtility.intArray2ByteArrayConverter(day15LSpanDead))
        day17LSpan.add(MyUtility.intArray2ByteArrayConverter(day17LSpanDead))
        day18LSpan.add(MyUtility.intArray2ByteArrayConverter(day18LSpanDead))
        day20LSpan.add(MyUtility.intArray2ByteArrayConverter(day20LSpanDead))
        day22LSpan.add(MyUtility.intArray2ByteArrayConverter(day22LSpanDead))
        day23LSpan.add(MyUtility.intArray2ByteArrayConverter(day23LSpanDead))
        day26LSpan.add(MyUtility.intArray2ByteArrayConverter(day26LSpanDead))
        day28LSpan.add(MyUtility.intArray2ByteArrayConverter(day28LSpanDead))
        day30LSpan.add(MyUtility.intArray2ByteArrayConverter(day30LSpanDead))
        day31LSpan.add(MyUtility.intArray2ByteArrayConverter(day31LSpanDead))

        day1LSpan.add(MyUtility.intArray2ByteArrayConverter(day1LSpanCensored))
        day8LSpan.add(MyUtility.intArray2ByteArrayConverter(day8LSpanCensored))
        day9LSpan.add(MyUtility.intArray2ByteArrayConverter(day9LSpanCensored))
        day12LSpan.add(MyUtility.intArray2ByteArrayConverter(day12LSpanCensored))
        day13LSpan.add(MyUtility.intArray2ByteArrayConverter(day13LSpanCensored))
        day14LSpan.add(MyUtility.intArray2ByteArrayConverter(day14LSpanCensored))
        day15LSpan.add(MyUtility.intArray2ByteArrayConverter(day15LSpanCensored))
        day17LSpan.add(MyUtility.intArray2ByteArrayConverter(day17LSpanCensored))
        day18LSpan.add(MyUtility.intArray2ByteArrayConverter(day18LSpanCensored))
        day20LSpan.add(MyUtility.intArray2ByteArrayConverter(day20LSpanCensored))
        day22LSpan.add(MyUtility.intArray2ByteArrayConverter(day22LSpanCensored))
        day23LSpan.add(MyUtility.intArray2ByteArrayConverter(day23LSpanCensored))
        day26LSpan.add(MyUtility.intArray2ByteArrayConverter(day26LSpanCensored))
        day28LSpan.add(MyUtility.intArray2ByteArrayConverter(day28LSpanCensored))
        day30LSpan.add(MyUtility.intArray2ByteArrayConverter(day30LSpanCensored))
        day31LSpan.add(MyUtility.intArray2ByteArrayConverter(day31LSpanCensored))
        //----------------------------------------------------
        myDatabaseHandler.updateByteArrayAtColumns (expInformation.id!!, 1, day1LSpan)
        myDatabaseHandler.updateByteArrayAtColumns (expInformation.id!!, 8, day8LSpan)
        myDatabaseHandler.updateByteArrayAtColumns (expInformation.id!!, 9, day9LSpan)
        myDatabaseHandler.updateByteArrayAtColumns (expInformation.id!!, 12, day12LSpan)
        myDatabaseHandler.updateByteArrayAtColumns (expInformation.id!!, 13, day13LSpan)
        myDatabaseHandler.updateByteArrayAtColumns (expInformation.id!!, 14, day14LSpan)
        myDatabaseHandler.updateByteArrayAtColumns (expInformation.id!!, 15, day15LSpan)
        myDatabaseHandler.updateByteArrayAtColumns (expInformation.id!!, 17, day17LSpan)
        myDatabaseHandler.updateByteArrayAtColumns (expInformation.id!!, 18, day18LSpan)
        myDatabaseHandler.updateByteArrayAtColumns (expInformation.id!!, 20, day20LSpan)
        myDatabaseHandler.updateByteArrayAtColumns (expInformation.id!!, 22, day22LSpan)
        myDatabaseHandler.updateByteArrayAtColumns (expInformation.id!!, 23, day23LSpan)
        myDatabaseHandler.updateByteArrayAtColumns (expInformation.id!!, 26, day26LSpan)
        myDatabaseHandler.updateByteArrayAtColumns (expInformation.id!!, 28, day28LSpan)
        myDatabaseHandler.updateByteArrayAtColumns (expInformation.id!!, 30, day30LSpan)
        myDatabaseHandler.updateByteArrayAtColumns (expInformation.id!!, 31, day31LSpan)
        //------------------------------------------------
        return listOfExpItems
    }
    //----------------------------------------------------------------------------------------------
    fun templateExpForLifeSpanAssay2 (listOfExpItems:ArrayList<Experiment>, mContext: Context, myDatabaseHandler:ExpDatabaseHandler, myAdapter:ExpListAdapter):ArrayList<Experiment> {

        val expInformation = Experiment()
        if (listOfExpItems.isNotEmpty()) {
            val previousExp = listOfExpItems.last()
            expInformation.id = previousExp.id?.plus(1)
        } else {expInformation.id = 1}
        expInformation.name = "LS cer1 Incomplete"
        expInformation.startDate ="2020-09-05"
        expInformation.dayPointer = 1
        expInformation.numberingStyle = 0
        expInformation.testConditionName.add("Control(RNAi)")
        expInformation.testConditionName.add("cer1(RNAi)")
        expInformation.testConditionRange.add(4)
        expInformation.testConditionRange.add(8)
        expInformation.type = mContext.getString(R.string.LS_assay)
        myDatabaseHandler.createExpInfo(expInformation)
        listOfExpItems.add(expInformation)
        myAdapter.notifyItemInserted(listOfExpItems.size-1)
        //-----------------------------------------------
        val i:Int = MyUtility.byte2Int(NoInputGray)

        val day1LSpanAlive = intArrayOf(25,25,25,25,28,28,27,27)
        val day8LSpanAlive = intArrayOf(25,25,25,25,26,26,27,27)
        val day9LSpanAlive = intArrayOf(25,25,25,25,26,26,27,27)
        val day12LSpanAlive = intArrayOf(20,21,20,21,22,23,22,22)
        val day13LSpanAlive = intArrayOf(20,21,20,21,i,i,i,i)
        val day14LSpanAlive = intArrayOf(19,20,19,20,21,23,20,22)
        val day15LSpanAlive = intArrayOf(17,18,17,18,19,21,18,20)
        val day17LSpanAlive = intArrayOf(15,15,15,15,17,17,17,18)
        val day18LSpanAlive = intArrayOf(14,15,14,15,17,17,17,18)

        val day1LSpanDead = intArrayOf(i,i,i,i,0,0,0,0)
        val day8LSpanDead = intArrayOf(0,0,0,0,2,2,0,0)
        val day9LSpanDead = intArrayOf(0,0,0,0,0,0,0,0)
        val day12LSpanDead = intArrayOf(0,0,0,0,1,1,1,2)
        val day13LSpanDead = intArrayOf(0,0,0,0,i,i,i,i)
        val day14LSpanDead = intArrayOf(1,1,1,1,1,0,1,0)
        val day15LSpanDead = intArrayOf(2,2,2,2,1,2,2,1)
        val day17LSpanDead = intArrayOf(2,3,2,3,2,2,1,2)
        val day18LSpanDead = intArrayOf(1,0,1,0,0,0,0,0)

        val day1LSpanCensored = intArrayOf(i,i,i,i,i,i,i,i)
        val day8LSpanCensored = intArrayOf(i,i,i,i,i,i,i,i)
        val day9LSpanCensored = intArrayOf(i,i,i,i,i,i,i,i)
        val day12LSpanCensored = intArrayOf(i,i,i,i,i,i,i,i)
        val day13LSpanCensored = intArrayOf(i,i,i,i,i,i,i,i)
        val day14LSpanCensored = intArrayOf(i,i,i,i,i,i,1,i)
        val day15LSpanCensored = intArrayOf(i,i,i,i,1,0,0,1)
        val day17LSpanCensored = intArrayOf(i,i,i,i,i,i,i,i)
        val day18LSpanCensored = intArrayOf(i,i,i,i,i,i,i,i)

        val day1LSpan = ArrayList<ByteArray>() ; day1LSpan.add(MyUtility.intArray2ByteArrayConverter(day1LSpanAlive))
        val day8LSpan = ArrayList<ByteArray>() ; day8LSpan.add(MyUtility.intArray2ByteArrayConverter(day8LSpanAlive))
        val day9LSpan = ArrayList<ByteArray>() ; day9LSpan.add(MyUtility.intArray2ByteArrayConverter(day9LSpanAlive))
        val day12LSpan = ArrayList<ByteArray>() ; day12LSpan.add(MyUtility.intArray2ByteArrayConverter(day12LSpanAlive))
        val day13LSpan = ArrayList<ByteArray>() ; day13LSpan.add(MyUtility.intArray2ByteArrayConverter(day13LSpanAlive))
        val day14LSpan = ArrayList<ByteArray>() ; day14LSpan.add(MyUtility.intArray2ByteArrayConverter(day14LSpanAlive))
        val day15LSpan = ArrayList<ByteArray>() ; day15LSpan.add(MyUtility.intArray2ByteArrayConverter(day15LSpanAlive))
        val day17LSpan = ArrayList<ByteArray>() ; day17LSpan.add(MyUtility.intArray2ByteArrayConverter(day17LSpanAlive))
        val day18LSpan = ArrayList<ByteArray>() ; day18LSpan.add(MyUtility.intArray2ByteArrayConverter(day18LSpanAlive))

        day1LSpan.add(MyUtility.intArray2ByteArrayConverter(day1LSpanDead))
        day8LSpan.add(MyUtility.intArray2ByteArrayConverter(day8LSpanDead))
        day9LSpan.add(MyUtility.intArray2ByteArrayConverter(day9LSpanDead))
        day12LSpan.add(MyUtility.intArray2ByteArrayConverter(day12LSpanDead))
        day13LSpan.add(MyUtility.intArray2ByteArrayConverter(day13LSpanDead))
        day14LSpan.add(MyUtility.intArray2ByteArrayConverter(day14LSpanDead))
        day15LSpan.add(MyUtility.intArray2ByteArrayConverter(day15LSpanDead))
        day17LSpan.add(MyUtility.intArray2ByteArrayConverter(day17LSpanDead))
        day18LSpan.add(MyUtility.intArray2ByteArrayConverter(day18LSpanDead))

        day1LSpan.add(MyUtility.intArray2ByteArrayConverter(day1LSpanCensored))
        day8LSpan.add(MyUtility.intArray2ByteArrayConverter(day8LSpanCensored))
        day9LSpan.add(MyUtility.intArray2ByteArrayConverter(day9LSpanCensored))
        day12LSpan.add(MyUtility.intArray2ByteArrayConverter(day12LSpanCensored))
        day13LSpan.add(MyUtility.intArray2ByteArrayConverter(day13LSpanCensored))
        day14LSpan.add(MyUtility.intArray2ByteArrayConverter(day14LSpanCensored))
        day15LSpan.add(MyUtility.intArray2ByteArrayConverter(day15LSpanCensored))
        day17LSpan.add(MyUtility.intArray2ByteArrayConverter(day17LSpanCensored))
        day18LSpan.add(MyUtility.intArray2ByteArrayConverter(day18LSpanCensored))
        //----------------------------------------------------
        myDatabaseHandler.updateByteArrayAtColumns (expInformation.id!!, 1, day1LSpan)
        myDatabaseHandler.updateByteArrayAtColumns (expInformation.id!!, 8, day8LSpan)
        myDatabaseHandler.updateByteArrayAtColumns (expInformation.id!!, 9, day9LSpan)
        myDatabaseHandler.updateByteArrayAtColumns (expInformation.id!!, 12, day12LSpan)
        myDatabaseHandler.updateByteArrayAtColumns (expInformation.id!!, 13, day13LSpan)
        myDatabaseHandler.updateByteArrayAtColumns (expInformation.id!!, 14, day14LSpan)
        myDatabaseHandler.updateByteArrayAtColumns (expInformation.id!!, 15, day15LSpan)
        myDatabaseHandler.updateByteArrayAtColumns (expInformation.id!!, 17, day17LSpan)
        myDatabaseHandler.updateByteArrayAtColumns (expInformation.id!!, 18, day18LSpan)
        //------------------------------------------------
        return listOfExpItems
    }
    //----------------------------------------------------------------------------------------------
    fun templateExpForReproductiveSpanAssay (listOfExpItems:ArrayList<Experiment>, mContext: Context, myDatabaseHandler:ExpDatabaseHandler, myAdapter:ExpListAdapter):ArrayList<Experiment> {
        val p:Byte = ProgenyGreen
        val n:Byte = NoProgenyBlue
        val c:Byte = CensorRed
        val cB:Byte = CensorBagged
        val cD:Byte = CensorDeadReproductive
        val cL:Byte = CensorLost
        val cE:Byte = CensorExploded
        val i:Byte = NoInputGray

        val px:Byte = MyUtility.int2Byte(MyUtility.byte2Int(ProgenyGreen)-MyUtility.byte2Int(HintNoMaleReproductive))
        val nx:Byte = MyUtility.int2Byte(MyUtility.byte2Int(NoProgenyBlue)-MyUtility.byte2Int(HintNoMaleReproductive))
        val cx:Byte = MyUtility.int2Byte(MyUtility.byte2Int(CensorRed)-MyUtility.byte2Int(HintNoMaleReproductive))
        val cBx:Byte = MyUtility.int2Byte(MyUtility.byte2Int(CensorBagged)-MyUtility.byte2Int(HintNoMaleReproductive))
        val cDx:Byte = MyUtility.int2Byte(MyUtility.byte2Int(CensorDeadReproductive)-MyUtility.byte2Int(HintNoMaleReproductive))
        val cLx:Byte = MyUtility.int2Byte(MyUtility.byte2Int(CensorLost)-MyUtility.byte2Int(HintNoMaleReproductive))
        val cEx:Byte = MyUtility.int2Byte(MyUtility.byte2Int(CensorExploded)-MyUtility.byte2Int(HintNoMaleReproductive))

        val pxy:Byte = MyUtility.int2Byte(MyUtility.byte2Int(ProgenyGreen)-MyUtility.byte2Int(HintFewMaleReproductive))
        val nxy:Byte = MyUtility.int2Byte(MyUtility.byte2Int(NoProgenyBlue)-MyUtility.byte2Int(HintFewMaleReproductive))
        val cxy:Byte = MyUtility.int2Byte(MyUtility.byte2Int(CensorRed)-MyUtility.byte2Int(HintFewMaleReproductive))
        val cBxy:Byte = MyUtility.int2Byte(MyUtility.byte2Int(CensorBagged)-MyUtility.byte2Int(HintNoMaleReproductive))
        val cDxy:Byte = MyUtility.int2Byte(MyUtility.byte2Int(CensorDeadReproductive)-MyUtility.byte2Int(HintNoMaleReproductive))
        val cLxy:Byte = MyUtility.int2Byte(MyUtility.byte2Int(CensorLost)-MyUtility.byte2Int(HintNoMaleReproductive))
        val cExy:Byte = MyUtility.int2Byte(MyUtility.byte2Int(CensorExploded)-MyUtility.byte2Int(HintNoMaleReproductive))
        //----------------------------------------------------
        val expInformation = Experiment()
        if (listOfExpItems.isNotEmpty()) {
            val previousExp = listOfExpItems.last()
            expInformation.id = previousExp.id?.plus(1)
        } else {expInformation.id = 1}
        expInformation.name = "N2-eat2 RS"
        expInformation.startDate ="2021-03-09"
        expInformation.dayPointer = 1
        expInformation.numberingStyle = 0
        expInformation.testConditionName.add("N2")
        expInformation.testConditionName.add("eat2")
        expInformation.testConditionRange.add(66)
        expInformation.testConditionRange.add(133)
        expInformation.type = mContext.getString(R.string.RS_assay)
        myDatabaseHandler.createExpInfo(expInformation)
        listOfExpItems.add(expInformation)
        myAdapter.notifyItemInserted(listOfExpItems.size-1)

        val dayInfo = Array(MyUtility.findNumberOfColumns(mContext, expInformation.type!!)!!) { ByteArray(133) }
        //-----------------------------------------------
        dayInfo[0]  = byteArrayOf(i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i)
        dayInfo[1]  = byteArrayOf(i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i)
        dayInfo[2]  = byteArrayOf(p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,p,p,p,p,p,p,p,p,p,c,p,c,p,p,p,cB,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i)
        dayInfo[3]  = byteArrayOf(p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,n,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,n,p,n,p,p,p,cB,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,n,p,p,p)
        dayInfo[4]  = byteArrayOf(p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,cB,p,p,p,cB,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,cB,p,p,n,p,cB,p,p,p,p,c,p,p,n,p,p,p,p,p,p,p,n,p,p,p,p,p,p,p,p,p,p,p,p,p,n,p,n,p,p,p,cB,p,n,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p)
        dayInfo[5]  = byteArrayOf(n,c,p,p,p,n,p,p,p,p,p,p,n,n,n,cB,n,cB,n,n,p,cB,n,n,p,p,p,p,p,p,p,n,cB,cE,cB,p,n,p,p,n,cB,n,p,n,p,cB,p,p,cB,p,c,p,n,cE,n,p,n,n,p,n,n,n,p,p,n,cD,p,p,p,p,p,p,p,p,p,n,p,n,p,p,p,cB,p,n,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,cB,n,p,p,c)
        dayInfo[6]  = byteArrayOf(n,c,n,p,n,n,p,n,n,p,p,p,p,n,n,cB,n,cB,n,p,c,cB,n,n,n,n,n,p,n,n,n,n,cB,cE,cB,n,cB,n,n,p,cB,n,p,n,p,cB,n,p,cB,n,c,c,n,cE,p,n,n,n,p,n,p,n,n,p,n,c,cB,cB,p,n,p,p,p,p,p,n,p,n,n,p,p,cB,p,n,p,p,n,p,p,p,cB,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,cD,p,p,p,p,p,p,n,p,p,p,p,p,p,p,p,p,p,n,p,p,cD,n,p,p,c)
        dayInfo[7]  = byteArrayOf(n,c,n,cE,n,n,n,p,n,n,p,n,n,n,n,cB,n,cB,n,n,c,cB,n,n,n,c,n,n,n,n,n,n,cB,cE,cB,n,cB,n,p,n,cB,n,n,n,p,cB,p,p,cB,c,c,c,n,cE,p,p,n,n,n,n,n,n,n,c,n,c,cB,cB,p,n,p,p,p,cB,p,n,p,n,n,p,p,cB,p,n,p,p,p,p,p,n,cB,p,p,n,n,n,n,p,n,p,p,p,p,p,p,p,p,cD,n,p,p,p,p,p,n,p,p,p,p,p,p,p,p,p,n,n,p,p,cD,n,cB,p,c)
        dayInfo[8]  = byteArrayOf(cD,c,n,cE,n,cD,n,n,n,n,cD,n,n,n,n,cB,n,cB,n,n,n,cB,n,n,n,c,n,n,n,n,n,n,cB,cE,cB,n,cB,n,n,n,cB,cB,n,n,n,cB,n,p,cB,c,c,c,n,cE,n,n,n,n,n,n,cB,n,n,c,n,c,cB,cB,n,n,p,n,p,cB,n,n,p,n,n,p,p,cB,n,n,n,p,n,p,p,p,cB,n,n,n,n,p,n,n,n,n,p,p,n,p,n,p,p,cD,n,n,n,p,p,n,n,p,n,n,n,cB,n,p,n,p,n,n,p,n,cD,n,cB,p,c)
        dayInfo[9]  = byteArrayOf(cD,c,n,cE,n,cD,n,n,n,n,cD,n,n,n,n,cB,n,cB,n,n,n,cB,n,n,n,c,n,n,n,n,n,n,cB,cE,cB,n,cB,n,n,c,cB,cB,n,n,n,cB,n,n,cB,n,c,c,n,cE,n,n,n,n,n,n,cB,n,cE,c,n,c,cB,cB,n,n,n,n,n,cB,n,n,p,n,n,n,n,cB,n,n,n,n,n,n,p,n,cB,n,n,n,n,n,n,n,n,n,n,p,n,n,p,p,n,cD,n,n,p,p,n,n,n,p,n,n,n,cB,n,p,n,p,n,n,cD,p,cD,n,cB,p,c)
        dayInfo[10] = byteArrayOf(cD,c,n,cE,n,cD,n,n,n,n,cD,n,n,n,n,cB,n,cB,n,n,n,cB,n,n,cD,c,n,n,n,n,n,n,cB,cE,cB,n,cB,n,n,c,cB,cB,n,n,n,cB,n,n,cB,p,c,c,n,cE,n,n,n,n,n,n,cB,n,cE,c,n,c,cB,cB,n,n,n,n,n,cB,n,cD,n,n,cE,n,n,cB,n,n,n,p,n,n,p,n,cB,n,n,n,n,n,p,n,n,n,n,p,n,n,n,n,n,cD,cE,n,n,p,n,n,n,n,n,n,n,cB,n,n,n,n,cD,n,cD,n,cD,n,cB,n,c)
        dayInfo[11] = byteArrayOf(cD,c,n,cE,n,cD,n,n,n,n,cD,cE,n,n,c,cB,n,cB,n,n,n,cB,n,n,cD,c,n,n,n,n,n,n,cB,cE,cB,n,cB,n,n,c,cB,cB,n,n,n,cB,cD,n,cB,n,c,c,n,cE,n,n,n,n,n,n,cB,cE,cE,c,n,c,cB,cB,n,n,n,n,n,cB,n,cD,n,n,cE,n,n,cB,n,n,n,n,n,n,n,n,cB,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,cD,cE,n,n,n,n,cE,n,p,n,n,n,cB,n,n,n,n,n,n,cD,n,cD,n,cB,n,c)

        for (ii in 1..12) {
            myDatabaseHandler.updateByteArrayAtOneColumn(expInformation.id!!, ii, dayInfo[ii-1] )
        }
        //------------------------------------------------
        return listOfExpItems
    }
    //----------------------------------------------------------------------------------------------
    fun templateExpForReproductiveSpanAssay2 (listOfExpItems:ArrayList<Experiment>, mContext: Context, myDatabaseHandler:ExpDatabaseHandler, myAdapter:ExpListAdapter):ArrayList<Experiment> {
        val p:Byte = ProgenyGreen
        val n:Byte = NoProgenyBlue
        val c:Byte = CensorRed
        val cB:Byte = CensorBagged
        val cD:Byte = CensorDeadReproductive
        val cL:Byte = CensorLost
        val cE:Byte = CensorExploded
        val i:Byte = NoInputGray

        val px:Byte = MyUtility.int2Byte(MyUtility.byte2Int(ProgenyGreen)-MyUtility.byte2Int(HintNoMaleReproductive))
        val nx:Byte = MyUtility.int2Byte(MyUtility.byte2Int(NoProgenyBlue)-MyUtility.byte2Int(HintNoMaleReproductive))
        val cx:Byte = MyUtility.int2Byte(MyUtility.byte2Int(CensorRed)-MyUtility.byte2Int(HintNoMaleReproductive))
        val cBx:Byte = MyUtility.int2Byte(MyUtility.byte2Int(CensorBagged)-MyUtility.byte2Int(HintNoMaleReproductive))
        val cDx:Byte = MyUtility.int2Byte(MyUtility.byte2Int(CensorDeadReproductive)-MyUtility.byte2Int(HintNoMaleReproductive))
        val cLx:Byte = MyUtility.int2Byte(MyUtility.byte2Int(CensorLost)-MyUtility.byte2Int(HintNoMaleReproductive))
        val cEx:Byte = MyUtility.int2Byte(MyUtility.byte2Int(CensorExploded)-MyUtility.byte2Int(HintNoMaleReproductive))

        val pxy:Byte = MyUtility.int2Byte(MyUtility.byte2Int(ProgenyGreen)-MyUtility.byte2Int(HintFewMaleReproductive))
        val nxy:Byte = MyUtility.int2Byte(MyUtility.byte2Int(NoProgenyBlue)-MyUtility.byte2Int(HintFewMaleReproductive))
        val cxy:Byte = MyUtility.int2Byte(MyUtility.byte2Int(CensorRed)-MyUtility.byte2Int(HintFewMaleReproductive))
        val cBxy:Byte = MyUtility.int2Byte(MyUtility.byte2Int(CensorBagged)-MyUtility.byte2Int(HintNoMaleReproductive))
        val cDxy:Byte = MyUtility.int2Byte(MyUtility.byte2Int(CensorDeadReproductive)-MyUtility.byte2Int(HintNoMaleReproductive))
        val cLxy:Byte = MyUtility.int2Byte(MyUtility.byte2Int(CensorLost)-MyUtility.byte2Int(HintNoMaleReproductive))
        val cExy:Byte = MyUtility.int2Byte(MyUtility.byte2Int(CensorExploded)-MyUtility.byte2Int(HintNoMaleReproductive))
        //----------------------------------------------------
        val expInformation = Experiment()
        if (listOfExpItems.isNotEmpty()) {
            val previousExp = listOfExpItems.last()
            expInformation.id = previousExp.id?.plus(1)
        } else {expInformation.id = 1}
        expInformation.name = "N2-eat2 incomplete"
        expInformation.startDate ="2021-02-12"
        expInformation.dayPointer = 1
        expInformation.numberingStyle =0
        expInformation.testConditionName.add("N2")
        expInformation.testConditionName.add("eat2")
        expInformation.testConditionRange.add(66)
        expInformation.testConditionRange.add(133)
        expInformation.type = mContext.getString(R.string.RS_assay)
        myDatabaseHandler.createExpInfo(expInformation)
        listOfExpItems.add(expInformation)
        myAdapter.notifyItemInserted(listOfExpItems.size-1)

        val dayInfo = Array(MyUtility.findNumberOfColumns(mContext, expInformation.type!!)!!) { ByteArray(133) }
        //-----------------------------------------------
        dayInfo[0]  = byteArrayOf(i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i)
        dayInfo[1]  = byteArrayOf(i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i)
        dayInfo[2]  = byteArrayOf(p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,p,p,p,p,p,p,p,p,p,c,p,c,p,p,p,cB,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i)
        dayInfo[3]  = byteArrayOf(p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,n,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,n,p,n,p,p,p,cB,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,n,p,p,p)
        dayInfo[4]  = byteArrayOf(p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,cB,p,p,p,cB,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,cB,p,p,n,p,cB,p,p,p,p,c,p,p,n,p,p,p,p,p,p,p,n,p,p,p,p,p,p,p,p,p,p,p,p,p,n,p,n,p,p,p,cB,p,n,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p)
        dayInfo[5]  = byteArrayOf(n,c,p,p,p,n,p,p,p,p,p,p,n,n,n,cB,n,cB,n,n,p,cB,n,n,p,p,p,p,p,p,p,n,cB,cE,cB,p,n,p,p,n,cB,n,p,n,p,cB,p,p,cB,p,c,p,n,cE,n,p,n,n,p,n,n,n,p,p,n,cD,p,p,p,p,p,p,p,p,p,n,p,n,p,p,p,cB,p,n,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,cB,n,p,p,c)
        dayInfo[6]  = byteArrayOf(n,c,n,p,n,n,p,n,n,p,p,p,p,n,n,cB,n,cB,n,p,c,cB,n,n,n,n,n,p,n,n,n,n,cB,cE,cB,n,cB,n,n,p,cB,n,p,n,p,cB,n,p,cB,n,c,c,n,cE,p,n,n,n,p,n,p,n,n,p,n,c,cB,cB,p,n,p,p,p,p,p,n,p,n,n,p,p,cB,p,n,p,p,n,p,p,p,cB,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,cD,p,p,p,p,p,p,n,p,p,p,p,p,p,p,p,p,p,n,p,p,cD,n,p,p,c)
        dayInfo[7]  = byteArrayOf(i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i)
        dayInfo[8]  = byteArrayOf(i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i)
        dayInfo[9]  = byteArrayOf(i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i)
        dayInfo[10] = byteArrayOf(i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i)
        dayInfo[11] = byteArrayOf(i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i)

        for (ii in 1..12) {
            myDatabaseHandler.updateByteArrayAtOneColumn(expInformation.id!!, ii, dayInfo[ii-1] )
        }
        //------------------------------------------------
        return listOfExpItems
    }
    //----------------------------------------------------------------------------------------------
}