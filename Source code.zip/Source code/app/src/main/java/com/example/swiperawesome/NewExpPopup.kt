package com.example.swiperawesome

import android.app.AlertDialog
import android.content.Context
import android.graphics.Typeface
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.text.format.DateFormat
import android.view.Gravity
import android.view.View
import android.widget.*
import android.widget.LinearLayout
import kotlinx.android.synthetic.main.popup_add_exp.view.*
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.*
import kotlin.collections.ArrayList


object NewExpPopup {
    var myDialogBuilder:AlertDialog.Builder? = null
    var myDialog:AlertDialog? = null
    var myDatabaseHandler:ExpDatabaseHandler? = null

    //----------------------------------------------------------------------------------------------
    fun runningPopup(
        ifEdit: Boolean,
        myAdapterPosition: Int,
        myView: View,
        listOfExpItems: ArrayList<Experiment>?,
        mContext: Context,
        myAdapter: ExpListAdapter
    ): ArrayList<Experiment>? {

        val myConditionBoxArray = ArrayList<ConditionRowBox>()
        val sally1 = ConditionRowBox(); sally1.parent=myView.ConditionRow1; sally1.name=myView.conditionNameID1
            sally1.num=myView.ConditionNumChamberID1; sally1.start=myView.startConditionID1; sally1.end=myView.EndConditionID1
        myConditionBoxArray.add(sally1)
        val sally2 = ConditionRowBox(); sally2.parent=myView.ConditionRow2 ;sally2.name=myView.conditionNameID2
            sally2.num=myView.ConditionNumChamberID2; sally2.start=myView.startConditionID2; sally2.end=myView.EndConditionID2
        myConditionBoxArray.add(sally2)
        //------------------------------------------
        myDialogBuilder = AlertDialog.Builder(mContext).setView(myView)
        myDialog = myDialogBuilder!!.create()
        myDialog?.show()
        //----------------------------------------------------
        myView.popupAddConditionID.setOnClickListener {

            if (myConditionBoxArray.size < TOTAL_NUM_CONDITIONS) {

                val nextRow = LinearLayout(mContext)
                val txtAdd0 = EditText(mContext)
                val txtAdd1 = EditText(mContext)
                val txtAdd2 = TextView(mContext)
                val txtAdd3 = TextView(mContext)
                //---------------------------------
                myView.conditionRowsBoxID.addView(nextRow)
                nextRow.layoutParams.width = LinearLayout.LayoutParams.MATCH_PARENT
                nextRow.layoutParams.height = LinearLayout.LayoutParams.WRAP_CONTENT
                nextRow.orientation = LinearLayout.HORIZONTAL
                nextRow.addView(txtAdd0)
                nextRow.addView(txtAdd1)
                nextRow.addView(txtAdd2)
                nextRow.addView(txtAdd3)
                txtAdd0.hint = "condition-${myConditionBoxArray.size + 1}"
                //txtAdd1.hint = "Num${myConditionBoxArray.size + 1}"
                txtAdd1.hint = "#${myConditionBoxArray.size + 1}"
                txtAdd1.inputType = InputType.TYPE_CLASS_NUMBER
                //-------------------------------------------------
                txtAdd0.textSize = 16f
                txtAdd1.textSize = 16f
                txtAdd2.textSize = 18f
                txtAdd3.textSize = 18f
                val myLayoutHeight = myConditionBoxArray[0].name!!.layoutParams.height
                val lp0 = LinearLayout.LayoutParams(0, myLayoutHeight); lp0.weight =4F; txtAdd0.layoutParams=lp0
                val lp1 = LinearLayout.LayoutParams(0, myLayoutHeight); lp1.weight =1F; txtAdd1.layoutParams=lp1
                val lp2 = LinearLayout.LayoutParams(0, myLayoutHeight); lp2.weight =1F; txtAdd2.layoutParams=lp2
                val lp3 = LinearLayout.LayoutParams(0, myLayoutHeight); lp3.weight =1F; txtAdd3.layoutParams=lp3
                txtAdd2.setTypeface(null, Typeface.BOLD)
                txtAdd3.setTypeface(null, Typeface.BOLD)
                txtAdd2.gravity = Gravity.CENTER or Gravity.END
                txtAdd3.gravity = Gravity.CENTER or Gravity.START
                txtAdd2.text = "-?-"
                txtAdd3.text = "-?-"
                //-------------------------------------------------
                val sally = ConditionRowBox(); sally.parent=nextRow;sally.name=txtAdd0; sally.num=txtAdd1; sally.start=txtAdd2; sally.end=txtAdd3
                myConditionBoxArray.add(sally)
                //-------------------------------------------------
                txtAdd1.addTextChangedListener(object : TextWatcher {
                    override fun onTextChanged(
                        s: CharSequence,
                        start: Int,
                        before: Int,
                        count: Int
                    ) {
                        MyUtility.updateStartEndRange(myConditionBoxArray)
                    }

                    override fun beforeTextChanged(
                        s: CharSequence,
                        start: Int,
                        count: Int,
                        after: Int
                    ) {
                    }

                    override fun afterTextChanged(s: Editable) {}
                })
                //-------------------------------------------------
            }
        }
        //-----------------------------------------------------
        myView.popupRemoveConditionID.setOnClickListener {

            if (myConditionBoxArray.size>1) {
                myView.conditionRowsBoxID.removeView(myConditionBoxArray.last().parent)
                myConditionBoxArray.removeAt(myConditionBoxArray.size - 1)
            }
        }
        //----------------------------------------------------
        for (ii in 0..1) {
            myConditionBoxArray[ii].num!!.addTextChangedListener(object : TextWatcher {
                override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                    MyUtility.updateStartEndRange(myConditionBoxArray)
                }

                override fun beforeTextChanged(
                    s: CharSequence,
                    start: Int,
                    count: Int,
                    after: Int
                ) {
                }

                override fun afterTextChanged(s: Editable) {}
            })
        }
        //------------------------------------------
        if (ifEdit) {
            myDatabaseHandler = ExpDatabaseHandler(mContext)
            val thisExperiment = myDatabaseHandler!!.readOneExpInfo(listOfExpItems!![myAdapterPosition].id!!)
            populateExperimentData(myView, thisExperiment, myConditionBoxArray)
        } else {
            val mDateTime = LocalDateTime.now()
            val myFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")
            val dateFormatted = mDateTime.format(myFormatter)
            val mDateParts = dateFormatted!!.split("-")

            myView.popupStartDay.setText(mDateParts[2])
            myView.popupStartMonth.setText(mDateParts[1])
            myView.popupStartYear.setText(mDateParts[0])
        }
        //------------------------------------------
        myView.popupSaveButton.setOnClickListener {

            val nName = myView.popupEnterExp.text.toString().trim()
            val dDateDay = myView.popupStartDay.text.toString().trim()
            val dDateMonth = myView.popupStartMonth.text.toString().trim()
            val dDateYear = myView.popupStartYear.text.toString().trim()
            val tConditionName: MutableList<String> = ArrayList()
            val tConditionEndRange: MutableList<String> = ArrayList()
            //----------------------------------------------------
            for (XX in 1..myConditionBoxArray.size) {
                tConditionName.add(XX - 1, myConditionBoxArray[XX - 1].name?.text.toString().trim())
                tConditionEndRange.add(
                    XX - 1,
                    myConditionBoxArray[XX - 1].end?.text.toString().trim()
                )
                if (myConditionBoxArray[XX - 1].end?.text.toString().trim()=="-?-") tConditionEndRange[XX - 1] = ""
            }
            //----------------------------------------------------
            if (!TextUtils.isEmpty(nName) && !TextUtils.isEmpty(dDateDay) && !TextUtils.isEmpty(dDateMonth) &&
                !TextUtils.isEmpty(dDateYear) && !MyUtility.isEmptyMyArrayString(tConditionName) &&
                !MyUtility.isEmptyMyArrayString(tConditionEndRange) && myView.radExpTypeID.checkedRadioButtonId!=-1 &&
                dDateDay.toInt()>0 && dDateDay.toInt()<33 && dDateMonth.toInt()>0 && dDateMonth.toInt()<13 &&
                dDateYear.toInt()>1990 && dDateYear.toInt()<2500 ) {

                val expInformation = Experiment()
                expInformation.name = nName
                expInformation.startDate = "$dDateYear-$dDateMonth-$dDateDay"
                expInformation.dayPointer = 1
                expInformation.numberingStyle = 0
                expInformation.testConditionName = tConditionName
                expInformation.testConditionRange = tConditionEndRange.map{it.toInt()}.toMutableList()
                //------------------------------------------
                val selectedRadioExpType = myView.findViewById<RadioButton>(myView.radExpTypeID.checkedRadioButtonId)
                expInformation.type = selectedRadioExpType.text.toString()
                //------------------------------------------
                myDialog!!.dismiss()
                myDatabaseHandler = ExpDatabaseHandler(mContext)
                //------------------------------------------
                when(ifEdit) {
                    true -> {
                        expInformation.id = listOfExpItems!![myAdapterPosition].id
                        myDatabaseHandler!!.updateExpInfo(expInformation)
                        listOfExpItems[myAdapterPosition] = expInformation
                        myAdapter.notifyDataSetChanged()
                    }

                    false -> {
                        if (!listOfExpItems?.isEmpty()!!) expInformation.id =
                            listOfExpItems.last().id?.plus(1)
                        else expInformation.id = 1
                        myDatabaseHandler!!.createExpInfo(expInformation)
                        listOfExpItems.add(expInformation)
                        myAdapter.notifyItemInserted(listOfExpItems.size - 1)
                    }
                }

            } else {
                Toast.makeText(mContext, "Incorrect inputs", Toast.LENGTH_SHORT).show()
            }
        }
        return listOfExpItems
    }
    //----------------------------------------------------------------------------------------------
    //----------------------------------------------------------------------------------------------
    private fun populateExperimentData(
        myView: View,
        thisExperiment: Experiment,
        myConditionBoxArray: ArrayList<ConditionRowBox>
    ) {

        myView.popupEnterExp.setText(thisExperiment.name)
        val mStringStartDate = thisExperiment.startDate
        val mDateParts = mStringStartDate!!.split("-")

        myView.popupStartYear.setText(mDateParts[0])
        myView.popupStartMonth.setText(mDateParts[1])
        myView.popupStartDay.setText(mDateParts[2])

        if (thisExperiment.testConditionName.size==1) {
            myView.popupRemoveConditionID.performClick()
        } else if (thisExperiment.testConditionName.size>2) {
            for (XX in 3..thisExperiment.testConditionName.size) {
                myView.popupAddConditionID.performClick()
            }
        }
        for (mm in 1..myConditionBoxArray.size) {
            myConditionBoxArray[mm - 1].name!!.setText(thisExperiment.testConditionName[mm - 1])
            myConditionBoxArray[mm - 1].end!!.text = thisExperiment.testConditionRange[mm - 1].toString()
        }
        myConditionBoxArray[0].num!!.setText(thisExperiment.testConditionRange[0].toString())
        for (mm in 2..myConditionBoxArray.size) {
            myConditionBoxArray[mm - 1].start!!.text = (thisExperiment.testConditionRange[mm - 2]+1).toString() + "-"
            myConditionBoxArray[mm - 1].num!!.setText((thisExperiment.testConditionRange[mm - 1] - thisExperiment.testConditionRange[mm - 2]).toString())
        }
        //-----------------------------------------
        val myGroupRadioButtons = myView.radExpTypeID
        for (i in 0 until myGroupRadioButtons.childCount) {
            var myTableRow: TableRow? = null
            myTableRow = myView.radExpTypeID.getChildAt(i) as TableRow?

            for (j in 0 until myTableRow!!.childCount) {
                var myRadioButton:RadioButton? = null
                myRadioButton = myTableRow.getChildAt(j) as RadioButton
                if (myRadioButton.text.toString()== thisExperiment.type) {
                    myView.radExpTypeID.onClick(myRadioButton)
                }
            }
        }
        //----------------------------------------------
    }
    //----------------------------------------------------------------------------------------------


}