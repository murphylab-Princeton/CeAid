package com.example.swiperawesome

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Menu
import android.view.View
import android.widget.Switch
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.android.synthetic.main.activity_life_span_feeder.*
import kotlinx.android.synthetic.main.switch_item.view.*
import java.util.*
import kotlin.collections.ArrayList

class ActivityLifeSpanFeeder : AppCompatActivity() {

    //----------------------------------------------------------------------------------------------
    private var mTts: TextToSpeech? = null
    var sr: SpeechRecognizer? = null
    private var myExpClass:Experiment? = null
    var thisExpID:Int? = null
    var columnID:Int? = null
    var chamberID:Int? = null
    var idArrayList:Int? = null
    var idArrayListFuture:Int? = null
    private var myTestDataHandler:ExpDatabaseHandler? = null
    private var totNumChambers:Int? = null
    private var foundExperimentDayNum:Int? = null
    var myToasterObject: Toast? = null
    private var myShapeOfChambersArray:Array<Int?>? = null
    private var textArrayOfConditionName:Array<String?>? = null
    private var maxValueOfSeekBars:Int?=null
    //----------------------------------------------------------------------------------------------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_life_span_feeder)
        //------------------------------------------------------------------------------------------
        val checkIntent = Intent()
        checkIntent.action = TextToSpeech.Engine.ACTION_CHECK_TTS_DATA
        startActivityForResult(checkIntent, MY_DATA_CHECK_CODE)
        //------------------------------------------------------------------------------------------
        this.thisExpID = intent.extras?.get("KeyForExpID") as Int
        this.chamberID = intent.extras?.get("KeyForChamberID") as Int
        myTestDataHandler = ExpDatabaseHandler(this)
        myExpClass = myTestDataHandler!!.readOneExpInfo(thisExpID!!)
        this.columnID = myExpClass!!.dayPointer
        this.totNumChambers = myExpClass!!.testConditionRange.last().toInt()
        this.foundExperimentDayNum = MyUtility.findNumberOfColumns(this, myExpClass!!.type!!)
        myShapeOfChambersArray = MyUtility.shapeOfChamberIdentifier(myExpClass!!)
        textArrayOfConditionName = MyUtility.textOfConditionIdentifier(myExpClass!!)
        //------------------------------------------------------------------------------------------
        showAutomaticInterface ()
        listenerInitialization()
        initialStatusDetermination()
        //------------------------------------------------------------------------------------------
        seekBarLeft.setOnProgressChangeListener { progressValue -> updateAliveInfoBox(progressValue)}
        seekBarLeft.setOnReleaseListener { progressValue ->
            idArrayList=1; idArrayListFuture=1; userInput(progressValue)
            speakUp("$progressValue alive")
        }
        seekBarMiddle.setOnProgressChangeListener { progressValue -> updateDeadInfoBox(progressValue) }
        seekBarMiddle.setOnReleaseListener { progressValue ->
            idArrayList=2; idArrayListFuture=2; userInput(progressValue)
            speakUp("$progressValue dead")
        }
        seekBarRight.setOnProgressChangeListener { progressValue -> updateCensoredInfoBox(progressValue) }
        seekBarRight.setOnReleaseListener { progressValue ->
            idArrayList=3; idArrayListFuture=3; userInput(progressValue)
            speakUp("$progressValue censored")
        }
        //------------------------------------------------------------------------------------------
        myGoToPreviousChamberID.setOnClickListener { goToPreviousChamber(); idArrayList=1; idArrayListFuture=1 }
        myGoToNextChamberID.setOnClickListener { gotoNextChamber(); idArrayList=1; idArrayListFuture=1 }
        myGoToPreviousDayID.setOnClickListener { goToPreviousColumn(); idArrayList=1; idArrayListFuture=1 }
        myGoToNextDayID.setOnClickListener { goToNextColumn(); idArrayList=1; idArrayListFuture=1 }
        //------------------------------------------------------------------------------------------
        viewForLifeSpanFeeder.setOnTouchListener(object : OnSwipeTouchListener(this@ActivityLifeSpanFeeder) {
            //---------------------------------------------
            override fun onSwipeDown() {goToPreviousChamber(); idArrayList=1; idArrayListFuture=1}
            override fun onSwipeUp() {gotoNextChamber(); idArrayList=1; idArrayListFuture=1}
            override fun onSwipeLeft() {goToNextColumn(); idArrayList=1; idArrayListFuture=1}
            override fun onSwipeRight() {goToPreviousColumn(); idArrayList=1; idArrayListFuture=1}
            override fun onDoubleTouch() {idArrayList=idArrayListFuture; sr!!.startListening(intent)}
            override fun onLongTouch() {}
            override fun onSingleTouch() {}
            //---------------------------------------------
        })
    }
    //----------------------------------------------------------------------------------------------
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_lifespan_activity, menu)
        val myAccessibleSwitch = menu!!.findItem(R.id.myAppSwitchLifeSpan).actionView.sallySwitchBox as Switch
        myAccessibleSwitch.setOnCheckedChangeListener { _, _ ->
            if (myAccessibleSwitch.isChecked) { showManualInterface(); toastMe("Switched To Manual"); speakUp("switched to manual") }
            else { showAutomaticInterface(); toastMe("Switched To VoiceCommand"); speakUp("switched to voice command")}
        }
        return true
    }
    //----------------------------------------------------------------------------------------------
    private fun initialStatusDetermination() {
        val myTestDataHandler = ExpDatabaseHandler(this)
        reportDayConditionChamber(textArrayOfConditionName!![chamberID!!-1]!!)
        getSeekBarsProgressMaxValues()
        updateDayChamberActionButtons()
        val arrayListData = myTestDataHandler.readByteArrayAtColumns(thisExpID!!,columnID!!)
        val alive = MyUtility.byte2Int(arrayListData!![0][chamberID!!-1])
        val dead = MyUtility.byte2Int(arrayListData[1][chamberID!!-1])
        val censored = MyUtility.byte2Int(arrayListData[2][chamberID!!-1])
        initMyPage()
        if (alive< MyUtility.byte2Int(MaxOfAvailableIntInByteArray)) {idArrayList = 1; idArrayListFuture = 1; userInput(alive)}
        if (dead< MyUtility.byte2Int(MaxOfAvailableIntInByteArray)) {idArrayList = 2; idArrayListFuture = 2; userInput(dead)}
        if (censored< MyUtility.byte2Int(MaxOfAvailableIntInByteArray)) {idArrayList = 3; idArrayListFuture = 3; userInput(censored)}
        //-------------------------------------------
        MyUtility.backGroundIconFinder(topListenerTextView, myShapeOfChambersArray!![chamberID!!-1]!!)
        MyUtility.backGroundIconFinder(middleListenerTextView, myShapeOfChambersArray!![chamberID!!-1]!!)
        MyUtility.backGroundIconFinder(bottomListenerTextView, myShapeOfChambersArray!![chamberID!!-1]!!)
        //-------------------------------------------
        idArrayList=1; idArrayListFuture=1
    }
    //----------------------------------------------------------------------------------------------
    inner class TextListener: RecognitionListener {

        override fun onReadyForSpeech(params: Bundle) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray) {}
        override fun onEndOfSpeech() {}
        override fun onError(error: Int) {}
        override fun onPartialResults(partialResults: Bundle) {}
        override fun onEvent(eventType: Int, params: Bundle) {}
        //--------------------------------------------
        override fun onResults(results: Bundle) {
            val data: ArrayList<String>? = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)

            var foundNum:String? = null
            outer@ for (myString in data!!.iterator()) {
                if (myString.length<4) {
                    for (i in myString.indices) {
                        if (!myString[i].isDigit()) break
                        if (i==myString.length-1){
                            foundNum = myString
                            break@outer
                        }
                    }
                }
            }
            if (foundNum!=null) {userInput(foundNum.toInt())
                when (idArrayList) {
                    1 -> {speakUp("$foundNum alive")}
                    2 -> {speakUp("$foundNum dead")}
                    3 -> {speakUp("$foundNum censored")}
                }
            }
            else { speakUp("Try again")
                    toastMe("Try again or use slider bars")}
        }
        //--------------------------------------------
    }
    //----------------------------------------------------------------------------------------------
    private fun updateStatus (dataByte:Byte) {myTestDataHandler!!.updateOneCellAtColumns(thisExpID!!, columnID!!, chamberID!!, dataByte, idArrayList!!)}
    fun speakUp (sayThis:String) {if (!myBooleanMute) {mTts!!.speak(sayThis, TextToSpeech.QUEUE_FLUSH, null, null)} }

    private fun toastMe(useThis:String) {   myToasterObject?.cancel()
                                            myToasterObject = Toast.makeText(this@ActivityLifeSpanFeeder, useThis, Toast.LENGTH_SHORT)
                                            myToasterObject?.show() }

    fun userInput(inputValue:Int) {
        when (idArrayList) {
            1 -> {  MyUtility.makeBoxGreen(topListenerTextView,applicationContext)
                    MyUtility.makeBoxGreen(myLeftInfoBox, applicationContext)
                    reportTopListenerTextBox(inputValue)
                    updateAliveInfoBox(inputValue)
                    seekBarLeft.progress = inputValue }
            2 -> {  MyUtility.makeBoxBlue(middleListenerTextView,applicationContext)
                    MyUtility.makeBoxBlue(myMiddleInfoBox,applicationContext)
                    reportMiddleListenerTextBox(inputValue)
                    updateDeadInfoBox(inputValue)
                    seekBarMiddle.progress = inputValue}
            3 -> {  MyUtility.makeBoxRed(bottomListenerTextView,applicationContext)
                    MyUtility.makeBoxRed(myRightInfoBox,applicationContext)
                    reportBottomListenerTextBox(inputValue)
                    updateCensoredInfoBox(inputValue)
                    seekBarRight.progress = inputValue}
        }
        updateStatus(MyUtility.int2Byte(inputValue))
        idArrayListFuture = if (idArrayList==3) 1; else idArrayList?.plus(1)
        reportMyMissingWorms()
    }
    fun gotoNextChamber() {
        if (chamberID!!<totNumChambers!!) {
            chamberID = chamberID!!.plus(1)
            initialStatusDetermination()
            val updatedChamberID = MyUtility.findProperNumberUsingProperNumberingStyle(this, thisExpID!!, chamberID!!)
            speakUp("plate $updatedChamberID at day $columnID")
        } else {
            toastMe("Next Chamber Not available!")
            speakUp("last plate")
        }
    }
    fun goToPreviousChamber() {
        if (chamberID!!>1){
            chamberID = chamberID!!.minus(1)
            initialStatusDetermination()
            val updatedChamberID = MyUtility.findProperNumberUsingProperNumberingStyle(this, thisExpID!!, chamberID!!)
            speakUp("plate $updatedChamberID at day $columnID")
        } else {
            toastMe("Previous Plate Not available!")
            speakUp("first plate")
        }
    }
    fun goToPreviousColumn() {
        if (columnID!!>1){
            columnID = columnID!!.minus(1)
            initialStatusDetermination()
            val updatedChamberID = MyUtility.findProperNumberUsingProperNumberingStyle(this, thisExpID!!, chamberID!!)
            speakUp("plate $updatedChamberID at day $columnID")
        } else {
            toastMe("Previous Day Not available!")
            speakUp("Previous day is not available")
        }
    }
    fun goToNextColumn() {
        if (columnID!!<foundExperimentDayNum!!){
            columnID = columnID!!.plus(1)
            initialStatusDetermination()
            val updatedChamberID = MyUtility.findProperNumberUsingProperNumberingStyle(this, thisExpID!!, chamberID!!)
            speakUp("plate $updatedChamberID at day $columnID")
        } else {
            toastMe("Next Day Not available!")
            speakUp("Next day is not available")
        }
    }
    private fun updateAliveInfoBox(value:Int) {
        myLeftInfoBox.text = "$value Alive"
    }
    private fun updateDeadInfoBox(value:Int) {
        myMiddleInfoBox.text = "$value Dead!"
    }
    private fun updateCensoredInfoBox(value: Int) {
        myRightInfoBox.text = "$value Censored"
    }
    private fun reportTopListenerTextBox(value:Int) {
        topListenerTextView.text = "$value\nAlive"
    }
    private fun reportMiddleListenerTextBox(value: Int) {
        middleListenerTextView.text = "$value\nDead"
    }
    private fun reportBottomListenerTextBox(value: Int) {
        bottomListenerTextView.text = "$value\nCensored"
    }
    private fun reportDayConditionChamber(conditionName: String) {
        val updatedChamberID = MyUtility.findProperNumberUsingProperNumberingStyle(this, thisExpID!!, chamberID!!)
        dayConditionChamberReporter.text = "d$columnID - $conditionName"
        myChamberNumberReporter.text = "#$updatedChamberID"
    }
    private fun initMyPage() {
        seekBarLeft.progress=0
        seekBarMiddle.progress=0
        seekBarRight.progress=0

        myLeftInfoBox.text = "-?- Alive"
        myMiddleInfoBox.text = "-?- Dead"
        myRightInfoBox.text = "-?- Censored"
        topListenerTextView.text = "-?-\nAlive"
        middleListenerTextView.text = "-?-\nDead"
        bottomListenerTextView.text = "-?-\nCensored"
        reportMissingWormLS.text = "0 -> Lost"
        MyUtility.makeBoxGray(myLeftInfoBox, applicationContext)
        MyUtility.makeBoxGray(myMiddleInfoBox,applicationContext)
        MyUtility.makeBoxGray(myRightInfoBox,applicationContext)
        MyUtility.makeBoxGray(topListenerTextView,applicationContext)
        MyUtility.makeBoxGray(middleListenerTextView,applicationContext)
        MyUtility.makeBoxGray(bottomListenerTextView,applicationContext)
    }
    private fun updateDayChamberActionButtons() {
        myGoToPreviousDayID.text = "Previous Day"
        myGoToNextDayID.text = "Next Day"
        val updatedChamberID = MyUtility.findProperNumberUsingProperNumberingStyle(this, thisExpID!!, chamberID!!)
        myGoToPreviousChamberID.text = "Previous Plate"
        myGoToNextChamberID.text = "Next Plate"
    }
    //---------------------------------------------
    private fun listenerInitialization() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)!= PackageManager.PERMISSION_GRANTED) {
            if (!ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.RECORD_AUDIO)) {
                ActivityCompat.requestPermissions(this, arrayOf<String>(Manifest.permission.RECORD_AUDIO),527)
            }
        }
        sr = SpeechRecognizer.createSpeechRecognizer(this)
        sr?.setRecognitionListener(TextListener())
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        intent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, "voice.recognition.test")
        intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 50)
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
    }
    //----------------------------------------------------------------------------------------------
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == MY_DATA_CHECK_CODE) {
            if (resultCode == TextToSpeech.Engine.CHECK_VOICE_DATA_PASS) {
                mTts = TextToSpeech(this@ActivityLifeSpanFeeder, TextToSpeech.OnInitListener { })
                mTts!!.language = Locale.US
                mTts!!.setSpeechRate(TextToSpeechSpeedValue)
            } else {
                toastMe("Missing Text to Speech Package")
                val installIntent = Intent()
                installIntent.action = TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA
                startActivity(installIntent)
            }
        }
    }
    //----------------------------------------------------------------------------------------------
    override fun onDestroy() {
        mTts!!.stop()
        mTts!!.shutdown()
        if (sr!=null) sr!!.destroy()
        super.onDestroy()
    }
    //----------------------------------------------------------------------------------------------
    private fun showManualInterface () {
        initialStatusDetermination()
        imageDividerTop.visibility = View.GONE
        imageDividerBottom.visibility = View.GONE
        topListenerTextView.visibility = View.GONE
        middleListenerTextView.visibility = View.GONE
        bottomListenerTextView.visibility = View.GONE
        viewForLifeSpanFeeder.visibility = View.GONE

        myRightInfoBox.visibility = View.VISIBLE
        myMiddleInfoBox.visibility = View.VISIBLE
        myLeftInfoBox.visibility = View.VISIBLE
        seekBarLeft.visibility = View.VISIBLE
        seekBarMiddle.visibility = View.VISIBLE
        seekBarRight.visibility = View.VISIBLE
        myLeftLinearLayout.visibility = View.VISIBLE
        myRightLinearLayout.visibility = View.VISIBLE
    }
    //----------------------------------------------------------------------------------------------
    private fun showAutomaticInterface () {
        initialStatusDetermination()
        myRightInfoBox.visibility = View.GONE
        myMiddleInfoBox.visibility = View.GONE
        myLeftInfoBox.visibility = View.GONE
        seekBarLeft.visibility = View.GONE
        seekBarMiddle.visibility = View.GONE
        seekBarRight.visibility = View.GONE
        myLeftLinearLayout.visibility = View.GONE
        myRightLinearLayout.visibility = View.GONE

        imageDividerTop.visibility = View.VISIBLE
        imageDividerBottom.visibility = View.VISIBLE
        topListenerTextView.visibility = View.VISIBLE
        middleListenerTextView.visibility = View.VISIBLE
        bottomListenerTextView.visibility = View.VISIBLE
        viewForLifeSpanFeeder.visibility = View.VISIBLE
    }
    //----------------------------------------------------------------------------------------------
    private fun getSeekBarsProgressMaxValues() {

        val myNameStringArray = myExpClass!!.name!!.split(",", ignoreCase = true, limit = 0)
        maxValueOfSeekBars = if (myNameStringArray.size>1) { myNameStringArray.last().toInt() }
        else {NUM_WORMS_PER_LS_PLATE}
        seekBarLeft.maxValue = maxValueOfSeekBars!!
        seekBarMiddle.maxValue = maxValueOfSeekBars!!
        seekBarRight.maxValue = maxValueOfSeekBars!!
    }
    //----------------------------------------------------------------------------------------------
    private fun reportMyMissingWorms() {
        if(columnID!!>1){
            var yesterdayAlive: Int
            var arrayListData:ArrayList<ByteArray>? = null
            var yesterdayDayNum = columnID
            do {
                yesterdayDayNum=yesterdayDayNum!!-1
                arrayListData= myTestDataHandler?. readByteArrayAtColumns(thisExpID!!,yesterdayDayNum)
                yesterdayAlive = MyUtility.byte2Int(arrayListData!![0][chamberID!!-1])
            } while ((yesterdayAlive>MaxOfAvailableIntInByteArray) && yesterdayDayNum!!>1)
            if (yesterdayAlive>MaxOfAvailableIntInByteArray) {yesterdayAlive=0}
            val mMissing = yesterdayAlive-seekBarLeft.progress-seekBarMiddle.progress-seekBarRight.progress
            reportMissingWormLS.text = "$mMissing -> Lost"
        }
    }
    //----------------------------------------------------------------------------------------------
}
