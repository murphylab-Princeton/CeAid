package com.example.swiperawesome

import android.content.Context
import android.util.Log


class DataProcessor {

    fun readAndCreateConditionClassInfo (expID: Int, mContext:Context) : ArrayList<Condition> {

        val myPlotDataHandler = ExpDatabaseHandler(mContext)
        val expClassInfo = myPlotDataHandler.readOneExpInfo(expID)
        val myConditionsList: ArrayList<Condition> = ArrayList()
        val expNumOfDaysTotal = MyUtility.findNumberOfColumns(mContext, expClassInfo.type!!)

        for (numCondition in 1..expClassInfo.testConditionName.size) {

            val eachCondition = Condition()
            var lowerEnd:Int = 0
            lowerEnd = if (numCondition==1) {1} else {expClassInfo.testConditionRange[numCondition-2]+1}
            val myTotalC = expClassInfo.testConditionRange[numCondition-1]-lowerEnd+1
            //----------------------------------------------------------------
            val numberDimMatrixData = 3
            val matrixData = Array(myTotalC) {IntArray(expNumOfDaysTotal!!)}
            val matrixData3dim = Array(numberDimMatrixData) {Array(expNumOfDaysTotal!!) {IntArray(myTotalC)}}
            //----------------------------------------------------------------
            when(expClassInfo.type) {
                mContext.getString(R.string.RS_assay), mContext.getString(R.string.ChoiceAssay), mContext.getString(R.string.LS_assayXX) -> {
                    for (dayInt in 1..expNumOfDaysTotal!!) {
                        val specificDayIntArray = MyUtility.byteArray2IntArrayConverter(myPlotDataHandler.readByteArrayAtOneColumn(expID,dayInt)!!)
                        var kCounter = 0
                        for (ii in 1..specificDayIntArray.size) {
                            if (ii >= lowerEnd && ii <= expClassInfo.testConditionRange[numCondition - 1]) {
                                matrixData[kCounter][dayInt - 1] = (specificDayIntArray[ii - 1])
                                kCounter++
                            }
                        }
                    }
                }
                mContext.getString(R.string.ProgenyAssay), mContext.getString(R.string.LS_assay) -> {
                    for (dayInt in 1..expNumOfDaysTotal!!) {

                        val arrayListOfByteArray = myPlotDataHandler.readByteArrayAtColumns(expID,dayInt)!!
                        for (mItem in 1..numberDimMatrixData) {
                            val specificDayIntArray = MyUtility.byteArray2IntArrayConverter(arrayListOfByteArray[mItem-1])
                            var kCounter = 0
                            for (ii in 1..specificDayIntArray.size) {
                                if (ii >= lowerEnd && ii <= expClassInfo.testConditionRange[numCondition - 1]) {
                                    matrixData3dim[mItem-1][dayInt - 1][kCounter] = (specificDayIntArray[ii - 1])
                                    kCounter++
                                }
                            }
                        }
                    }
                }

            }
            //----------------------------------------------------------------
            eachCondition.startRange = lowerEnd
            eachCondition.endRange = expClassInfo.testConditionRange[numCondition-1].toInt()
            eachCondition.totalC = myTotalC
            eachCondition.name = expClassInfo.testConditionName[numCondition-1]
            eachCondition.type = expClassInfo.type
            eachCondition.numColumnTotal = expNumOfDaysTotal
            eachCondition.dataMatrix = matrixData
            eachCondition.dataMatrix3dim = matrixData3dim
            eachCondition.numDimMatrixData = numberDimMatrixData
            myConditionsList.add(eachCondition)
        }
        return myConditionsList
    }
    //----------------------------------------------------------------------------------------------
    //----------------------------------------------------------------------------------------------
    fun reproductiveSpanCalculator (mCondtn:Condition): Condition {

        val rSpanIndicatorDay = arrayOfNulls<Int>(mCondtn.totalC!!)
        val rSpanBooleanValue = arrayOfNulls<Boolean>(mCondtn.totalC!!)

        for (well in 1..mCondtn.totalC!!) {

            val ifCensored = IntArray(mCondtn.numColumnTotal!!) {mCondtn.numColumnTotal!!+1}
            val ifProgeny = IntArray(mCondtn.numColumnTotal!!) {0}
            val ifNoProgeny = IntArray(mCondtn.numColumnTotal!!) {mCondtn.numColumnTotal!!+1}
            val ifNoInput = IntArray(mCondtn.numColumnTotal!!) {0}
            var censoredVal = 0
            var progenyVal = 0
            var noProgenyVal = 0
            //------------------------
            for (dayID in 1..mCondtn.numColumnTotal!!) {
                when(mCondtn.dataMatrix!! [well-1] [dayID-1]) {
                    MyUtility.byte2Int(CensorRed), MyUtility.byte2Int(CensorLost), MyUtility.byte2Int(CensorExploded),
                    MyUtility.byte2Int(CensorBagged), MyUtility.byte2Int(CensorDeadReproductive)-> {ifCensored[dayID-1]=dayID}
                    MyUtility.byte2Int(ProgenyGreen), MyUtility.byte2Int(ProgenyGreen)-MyUtility.byte2Int(HintNoMaleReproductive),
                    MyUtility.byte2Int(ProgenyGreen)-MyUtility.byte2Int(HintFewMaleReproductive)-> {ifProgeny[dayID-1]=dayID}
                    MyUtility.byte2Int(NoProgenyBlue), MyUtility.byte2Int(NoProgenyBlue)-MyUtility.byte2Int(HintNoMaleReproductive),
                    MyUtility.byte2Int(NoProgenyBlue)-MyUtility.byte2Int(HintFewMaleReproductive) -> {ifNoProgeny[dayID-1]=dayID}
                    MyUtility.byte2Int(NoInputGray) -> {ifNoInput[dayID-1]=dayID}
                }
            }
            //----------------------- The whole logic for analyzing data
            censoredVal = ifCensored.min()!!
            progenyVal = ifProgeny.max()!!
            noProgenyVal = ifNoProgeny.min()!!

            if (censoredVal<=mCondtn.numColumnTotal!! && censoredVal<noProgenyVal) {
                rSpanIndicatorDay[well - 1]  = censoredVal
                rSpanBooleanValue[well - 1] = false
            } else if (noProgenyVal==mCondtn.numColumnTotal!!+1 && censoredVal==mCondtn.numColumnTotal!!+1) {
                rSpanIndicatorDay[well - 1] = progenyVal+1
                rSpanBooleanValue[well - 1] = false
            } else if (noProgenyVal>progenyVal) {
                rSpanIndicatorDay[well - 1] = noProgenyVal-1
                rSpanBooleanValue[well - 1] = true
            } else if (progenyVal-2==noProgenyVal) {
                rSpanIndicatorDay[well - 1] = progenyVal
                rSpanBooleanValue[well - 1] = true
            } else if (progenyVal-1==noProgenyVal) {
                rSpanIndicatorDay[well - 1] = progenyVal
                rSpanBooleanValue[well - 1] = true
            } else {
                rSpanIndicatorDay[well - 1] = noProgenyVal-1
                rSpanBooleanValue[well - 1] = true
            }
            //----------------------------------------------------------
        }
        mCondtn.dayStop = rSpanIndicatorDay
        mCondtn.censorB = rSpanBooleanValue
        Log.d("salam ${mCondtn.name}", mCondtn.dayStop!!.map { it.toString() }.toString())
        Log.d("salam ${mCondtn.name}", mCondtn.censorB!!.map { it.toString() }.toString())
        return mCondtn
    }
    //----------------------------------------------------------------------------------------------
    //----------------------------------------------------------------------------------------------
    fun lifeSpanCalculatorXX (mCondtn:Condition): Condition {

        val lifeSpanIndicatorDay = arrayOfNulls<Int>(mCondtn.totalC!!)
        val lifeSpanBooleanValue = arrayOfNulls<Boolean>(mCondtn.totalC!!)

        for (well in 1..mCondtn.totalC!!) {
            val ifCensored = IntArray(mCondtn.numColumnTotal!!) {mCondtn.numColumnTotal!!+1}
            val ifAlive = IntArray(mCondtn.numColumnTotal!!) {0}
            val ifDead = IntArray(mCondtn.numColumnTotal!!) {mCondtn.numColumnTotal!!+1}
            val ifNoInput = IntArray(mCondtn.numColumnTotal!!) {0}
            var censoredVal = 0
            var aliveVal = 0
            var deadVal = 0
            //------------------------
            for (dayID in 1..mCondtn.numColumnTotal!!) {
                when(mCondtn.dataMatrix!! [well-1] [dayID-1]) {
                    MyUtility.byte2Int(CensorRed), MyUtility.byte2Int(CensorUnidentified), MyUtility.byte2Int(CensorLost),
                    MyUtility.byte2Int(CensorExploded), MyUtility.byte2Int(CensorDried), MyUtility.byte2Int(CensorBagged) -> {ifCensored[dayID-1]=dayID}
                    MyUtility.byte2Int(AliveGreen) -> {ifAlive[dayID-1]=dayID}
                    MyUtility.byte2Int(DeadBlue) -> {ifDead[dayID-1]=dayID}
                    MyUtility.byte2Int(NoInputGray) -> {ifNoInput[dayID-1]=dayID}
                }
            }
            //----------------------- The whole logic for analyzing data
            censoredVal = ifCensored.min()!!
            aliveVal = ifAlive.max()!!
            deadVal = ifDead.min()!!

            if (censoredVal<=mCondtn.numColumnTotal!! && censoredVal<deadVal && censoredVal>aliveVal) {
                lifeSpanIndicatorDay[well - 1]  = censoredVal
                lifeSpanBooleanValue[well - 1] = false
            } else if ((censoredVal==mCondtn.numColumnTotal!!+1 || censoredVal<aliveVal) && (deadVal==mCondtn.numColumnTotal!!+1)) {
                lifeSpanIndicatorDay[well - 1] = aliveVal+1
                lifeSpanBooleanValue[well - 1] = false
            } else {
                lifeSpanIndicatorDay[well - 1] = aliveVal
                lifeSpanBooleanValue[well - 1] = true
            }
            //----------------------------------------------------------
        }
        mCondtn.dayStop = lifeSpanIndicatorDay
        mCondtn.censorB = lifeSpanBooleanValue
        Log.d("salam ${mCondtn.name}", mCondtn.dayStop!!.map { it.toString() }.toString())
        Log.d("salam ${mCondtn.name}", mCondtn.censorB!!.map { it.toString() }.toString())
        return mCondtn
    }
    //----------------------------------------------------------------------------------------------
    //----------------------------------------------------------------------------------------------
    fun lifeSpanCalculator (mCondtn: Condition): Condition {
        //-----------------------------------------------------
        val myAlivePerDay = IntArray(mCondtn.numColumnTotal!!)
        val myDeadPerDay = IntArray(mCondtn.numColumnTotal!!)
        val myCensorPerDay = IntArray(mCondtn.numColumnTotal!!)
        var flagForIncomplete = 0
        for (mItem in 1..mCondtn.numDimMatrixData!!) {
            for (dayInt in 1..mCondtn.numColumnTotal!!) {
                var tmpSum:Int = 0
                for (replicate in 1..mCondtn.totalC!!) {
                     if (mCondtn.dataMatrix3dim!![mItem-1][dayInt-1][replicate-1]< MyUtility.byte2Int(MaxOfAvailableIntInByteArray)){
                         tmpSum += mCondtn.dataMatrix3dim!![mItem-1][dayInt-1][replicate-1]
                         if (flagForIncomplete<dayInt) {flagForIncomplete = dayInt}
                     }
                }
                when(mItem) {
                    1 -> {myAlivePerDay[dayInt-1] = tmpSum}
                    2 -> {myDeadPerDay[dayInt-1] = tmpSum}
                    3 -> {myCensorPerDay[dayInt-1] = tmpSum}
                }
            }
        }
        for (dayInt in 1..mCondtn.numColumnTotal!!) {
            if (dayInt>1 && myAlivePerDay[dayInt-1]==0) {myAlivePerDay[dayInt-1]=myAlivePerDay[dayInt-2]-myDeadPerDay[dayInt-1]-myCensorPerDay[dayInt-1]}
            if (dayInt>flagForIncomplete) {myAlivePerDay[dayInt-1]=-1}
        }

        Log.d("myLS", myAlivePerDay.contentToString())
        Log.d("myLS", myDeadPerDay.contentToString())
        Log.d("myLS", myCensorPerDay.contentToString())
        mCondtn.alivePerDay = myAlivePerDay
        mCondtn.deadPerDay = myDeadPerDay
        mCondtn.censorPerDay = myCensorPerDay
        //Log.d("this is ${mCondtn.name}", mCondtn.choiceIndex!!.map { it.toString() }.toString())
        return mCondtn
    }
    //----------------------------------------------------------------------------------------------
    //----------------------------------------------------------------------------------------------
    fun survivalAxisCalculator(mCondtn:Condition): Condition {

        val hazardRate = arrayOfNulls<Float>(mCondtn.numColumnTotal!!)
        val mySurvivalXAxisXX = mutableListOf<Float>()
        val percentSurvival = mutableListOf<Float>()
        for (dCount in 1..mCondtn.numColumnTotal!!) {
            if (mCondtn.alivePerDay!![dCount-1]+mCondtn.deadPerDay!![dCount-1]+mCondtn.censorPerDay!![dCount-1]==0) {
                hazardRate[dCount - 1] = 8f
            } else {
                hazardRate[dCount-1] = mCondtn.deadPerDay!![dCount-1].toFloat()/(mCondtn.alivePerDay!![dCount-1]+mCondtn.deadPerDay!![dCount-1]+mCondtn.censorPerDay!![dCount-1])
            }
        }
        mySurvivalXAxisXX.add(0f)
        percentSurvival.add(100f)
        var mCounter:Int = 0
        if (hazardRate[0]!=8f) {
            mySurvivalXAxisXX.add(1f)
            percentSurvival.add(percentSurvival[mCounter]*(1-hazardRate[0]!!))
            mCounter++
        }
        for (sDay in 3..mCondtn.numColumnTotal!!+1) {
            if (hazardRate[sDay-2]!=8f && mCondtn.censorPerDay!![sDay-2]!=mCondtn.alivePerDay!![sDay-3] && mCondtn.alivePerDay!![sDay-2]!=-1) {
                mySurvivalXAxisXX.add(sDay.toFloat()-1)
                percentSurvival.add(percentSurvival[mCounter]*(1-hazardRate[sDay-2]!!))
                mCounter++
            }
        }
        Log.d("hello ${mCondtn.name}", mySurvivalXAxisXX.map { it.toString() }.toString())
        Log.d("hello ${mCondtn.name}", percentSurvival.map { it.toString() }.toString())
        mCondtn.survivalXAxis = mySurvivalXAxisXX.toTypedArray()
        mCondtn.survivalYAxis = percentSurvival.toTypedArray()
        return mCondtn
    }
    //----------------------------------------------------------------------------------------------
    //----------------------------------------------------------------------------------------------
    fun aliveDeadCensorCalculator(mCondtn:Condition):Condition {

        val myAlivePerDay = IntArray(mCondtn.numColumnTotal!!)
        val myDeadPerDay = IntArray(mCondtn.numColumnTotal!!)
        val myCensorPerDay = IntArray(mCondtn.numColumnTotal!!)
        var tmpAlive = mCondtn.totalC!!
        var tmpDead = 0
        var tmpCensor = 0

        for (dayInt in 1..mCondtn.numColumnTotal!!) {
            tmpDead = 0
            tmpCensor = 0
            for (replicate in 1..mCondtn.totalC!!) {
                if (mCondtn.dayStop!![replicate-1]==dayInt) {
                    when(mCondtn.censorB!![replicate-1]) {
                        true -> {tmpAlive -=1; tmpDead +=1}
                        false -> {tmpAlive -=1; tmpCensor +=1}
                    }
                }
            }
            myAlivePerDay[dayInt-1] = tmpAlive
            myDeadPerDay[dayInt-1] = tmpDead
            myCensorPerDay[dayInt-1] = tmpCensor
        }
        Log.d("salt", myAlivePerDay.contentToString())
        Log.d("salt", myDeadPerDay.contentToString())
        Log.d("salt", myCensorPerDay.contentToString())
        mCondtn.alivePerDay = myAlivePerDay
        mCondtn.deadPerDay = myDeadPerDay
        mCondtn.censorPerDay = myCensorPerDay
        //Log.d("this is ${mCondtn.name}", mCondtn.choiceIndex!!.map { it.toString() }.toString())
        return mCondtn
    }
    //----------------------------------------------------------------------------------------------
    //----------------------------------------------------------------------------------------------
    fun choiceAssayCalculator (mCondtn:Condition): Condition {
        val myChoiceIndex = ArrayList<Float>()

        for (cID in 1..mCondtn.totalC!!) {
            if (mCondtn.dataMatrix!![cID-1][0]<MyUtility.byte2Int(MaxOfAvailableIntInByteArray) && mCondtn.dataMatrix!![cID-1][1]<MyUtility.byte2Int(MaxOfAvailableIntInByteArray)) {
                myChoiceIndex.add((mCondtn.dataMatrix!![cID-1][0].toFloat()-mCondtn.dataMatrix!![cID-1][1].toFloat())/(mCondtn.dataMatrix!![cID-1][0].toFloat()+mCondtn.dataMatrix!![cID-1][1].toFloat()))
            } else {
                myChoiceIndex.add(0f)
            }
        }
        mCondtn.choiceIndex = myChoiceIndex.toFloatArray()
        return mCondtn
    }
    //----------------------------------------------------------------------------------------------
    //----------------------------------------------------------------------------------------------
    fun broodSizeCalculator (mCondtn:Condition): Condition {

        val myBroodSizePerDay = FloatArray(mCondtn.numColumnTotal!!)
        val myUnhatchedEggs = FloatArray(mCondtn.numColumnTotal!!)
        val myUnfertilizedOocytes = FloatArray(mCondtn.numColumnTotal!!)

        for (mItem in 1..mCondtn.numDimMatrixData!!) {
            for (dayInt in 1..mCondtn.numColumnTotal!!) {
                var tmpSum = 0
                var countOnesWithValue = 0
                var mAverageValue = 0f
                //Log.d("$mItem Num @day$dayInt", mCondtn.dataMatrix3dim!![mItem-1][dayInt-1].contentToString())
                for (replicate in 1..mCondtn.totalC!!) {
                    if (mCondtn.dataMatrix3dim!![mItem-1][dayInt-1][replicate-1]< MyUtility.byte2Int(MaxOfAvailableIntInByteArray)){
                        tmpSum += mCondtn.dataMatrix3dim!![mItem-1][dayInt-1][replicate-1]
                        countOnesWithValue+=1
                    }
                }
                if (countOnesWithValue>0){mAverageValue = tmpSum.toFloat() / countOnesWithValue}
                when(mItem) {
                    1 -> {myBroodSizePerDay[dayInt-1] = mAverageValue}
                    2 -> {myUnhatchedEggs[dayInt-1] = mAverageValue}
                    3 -> {myUnfertilizedOocytes[dayInt-1] = mAverageValue}
                }
            }
        }
        //Log.d("mBroodii", myBroodSizePerDay.contentToString())
        mCondtn.broodSizePerDay = myBroodSizePerDay
        mCondtn.unhatchedEggs = myUnhatchedEggs
        mCondtn.unfertilizedOocytes = myUnfertilizedOocytes
        //Log.d("this is ${mCondtn.name}", mCondtn.choiceIndex!!.map { it.toString() }.toString())
        return mCondtn
    }
    //----------------------------------------------------------------------------------------------
    //----------------------------------------------------------------------------------------------
    fun candleStickCalculator (mCondtn: Condition):Condition {

        val sortedChoiceAssay = mCondtn.choiceIndex!!.sortedArray()
        mCondtn.candleStickHighY = medianFinder(arraySplitter(sortedChoiceAssay)!!)
        mCondtn.candleStickLowY = medianFinder(arraySplitter(sortedChoiceAssay.reversedArray())!!)
        mCondtn.candleStickErrorH = mCondtn.choiceIndex!!.max()
        mCondtn.candleStickErrorL = mCondtn.choiceIndex!!.min()
        Log.d("this is ${mCondtn.name}", mCondtn.choiceIndex!!.map { it.toString() }.toString())
        return mCondtn
    }
    //--------------------------------
    private fun arraySplitter(myArray: FloatArray): FloatArray? {
        var targetArray:FloatArray? = null
        val medianID:Int = myArray.size/2
        when(myArray.size%2) {
            0 -> {targetArray = myArray.copyOf(medianID-1)}
            1 -> {targetArray = myArray.copyOf(medianID)}
        }
        return targetArray
    }
    private fun medianFinder (myArray: FloatArray): Float? {
        var targetFloat:Float? = null
        val medianID:Int = myArray.size/2
        when(myArray.size%2) {
            0 -> {targetFloat = (myArray[medianID-1]+myArray[medianID])/2}
            1 -> {targetFloat = myArray[medianID]}
        }
        return targetFloat
    }
    //----------------------------------------------------------------------------------------------
    //----------------------------------------------------------------------------------------------
}